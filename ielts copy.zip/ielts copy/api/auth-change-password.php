<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();

$currentPassword = (string) ($input['currentPassword'] ?? '');
$newPassword = (string) ($input['newPassword'] ?? '');

if (!password_verify($currentPassword, (string) ($user['passwordHash'] ?? ''))) {
    ieltslab_fail('The current password is incorrect.', 400);
}

if (strlen($newPassword) < 8) {
    ieltslab_fail('The new password must be at least 8 characters.', 400);
}

$user['passwordHash'] = password_hash($newPassword, PASSWORD_DEFAULT);
$user = ieltslab_save_user($user);
ieltslab_record_event('auth.change_password', [], $user);

ieltslab_json_response(['success' => true, 'message' => 'Password updated.']);