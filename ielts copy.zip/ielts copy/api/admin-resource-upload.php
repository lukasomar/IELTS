<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$admin = ieltslab_require_admin();

$section = trim((string) ($_POST['section'] ?? 'listening'));
if (!isset($_FILES['resource']) || !is_array($_FILES['resource'])) {
    ieltslab_fail('Resource upload is required.', 400);
}

$upload = ieltslab_save_uploaded_resource($_FILES['resource'], $section);
$meta = ieltslab_content_metadata();
$meta[$upload['path']] = [
    'section' => $section,
    'title' => trim((string) ($_POST['title'] ?? $upload['name'])),
    'description' => trim((string) ($_POST['description'] ?? '')),
    'notes' => trim((string) ($_POST['notes'] ?? '')),
    'premium' => isset($_POST['premium']) ? (bool) $_POST['premium'] : false,
    'hidden' => false,
    'uploadedAt' => time(),
];
ieltslab_save_content_metadata($meta);
ieltslab_record_event('admin.resource_upload', ['path' => $upload['path']], $admin);

ieltslab_json_response(['success' => true, 'resource' => ['path' => $upload['path'], 'meta' => $meta[$upload['path']]]], 201);