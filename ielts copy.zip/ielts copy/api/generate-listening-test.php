<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$input = ieltslab_read_json_request();

$targetBand = (string) ($input['targetBand'] ?? '6.0');
$questionCount = max(8, min(12, (int) ($input['questionCount'] ?? 10)));
$accentMix = trim((string) ($input['accentMix'] ?? 'mixed'));
$theme = trim((string) ($input['theme'] ?? ''));
$notes = trim((string) ($input['notes'] ?? ''));
$sessionId = ieltslab_generate_session_id();

$model = ieltslab_setting('GEMINI_MODEL', 'gemini-2.5-flash') ?? 'gemini-2.5-flash';
$ttsModel = ieltslab_setting('GEMINI_TTS_MODEL', 'gemini-2.5-flash-preview-tts') ?? 'gemini-2.5-flash-preview-tts';
$ttsVoice = ieltslab_setting('GEMINI_TTS_VOICE', 'Kore') ?? 'Kore';

$systemPrompt = <<<PROMPT
You generate IELTS Listening practice tests as strict JSON.
Return only valid JSON.
Build a realistic mini IELTS Listening test with 4 sections and objective questions only.
Allowed question types: short_answer, form_completion, multiple_choice.
Every question must include acceptedAnswers with all acceptable normalized variants.
Make the transcript and the answer key consistent.
Keep the generated transcript short enough for a lightweight web demo on shared hosting.
PROMPT;

$responseSchema = [
  'type' => 'object',
  'properties' => [
    'testTitle' => ['type' => 'string'],
    'instructions' => ['type' => 'string'],
    'transcript' => ['type' => 'string'],
    'sections' => [
      'type' => 'array',
      'items' => [
        'type' => 'object',
        'properties' => [
          'sectionNumber' => ['type' => 'integer'],
          'title' => ['type' => 'string'],
          'summary' => ['type' => 'string'],
          'questionStart' => ['type' => 'integer'],
          'questionEnd' => ['type' => 'integer'],
        ],
        'required' => ['sectionNumber', 'title', 'summary', 'questionStart', 'questionEnd'],
      ],
    ],
    'questions' => [
      'type' => 'array',
      'items' => [
        'type' => 'object',
        'properties' => [
          'number' => ['type' => 'integer'],
          'sectionNumber' => ['type' => 'integer'],
          'type' => ['type' => 'string'],
          'typeLabel' => ['type' => 'string'],
          'prompt' => ['type' => 'string'],
          'options' => ['type' => 'array', 'items' => ['type' => 'string']],
          'acceptedAnswers' => ['type' => 'array', 'items' => ['type' => 'string'], 'minItems' => 1],
          'canonicalAnswer' => ['type' => 'string'],
          'explanation' => ['type' => 'string'],
        ],
        'required' => ['number', 'sectionNumber', 'type', 'typeLabel', 'prompt', 'options', 'acceptedAnswers', 'canonicalAnswer', 'explanation'],
      ],
      'minItems' => $questionCount,
    ],
  ],
  'required' => ['testTitle', 'instructions', 'transcript', 'sections', 'questions'],
];

$userPrompt = <<<PROMPT
Generate an IELTS Listening practice test with these constraints:
- target band: {$targetBand}
- total questions: {$questionCount}
- accent mix: {$accentMix}
- theme preference: {$theme}
- extra notes: {$notes}

Return JSON with exactly this shape:
{
  "testTitle": "string",
  "instructions": "string",
  "transcript": "string",
  "sections": [
    {
      "sectionNumber": 1,
      "title": "string",
      "summary": "string",
      "questionStart": 1,
      "questionEnd": 3
    }
  ],
  "questions": [
    {
      "number": 1,
      "sectionNumber": 1,
      "type": "short_answer",
      "typeLabel": "Short answer",
      "prompt": "string",
      "options": [],
      "acceptedAnswers": ["string"],
      "canonicalAnswer": "string",
      "explanation": "string"
    }
  ]
}

Rules:
- Keep the transcript realistic and exam-like.
- Keep the transcript short for web playback, ideally about 160 to 260 words total.
- Spread questions across all 4 sections.
- Multiple choice questions must include 3 or 4 options.
- Do not include markdown fences.
- Do not include any commentary outside JSON.
PROMPT;

$response = ieltslab_gemini_request($model, [
  'systemInstruction' => [
    'parts' => [
      ['text' => $systemPrompt],
    ],
    ],
  'contents' => [
    [
      'role' => 'user',
      'parts' => [
        ['text' => $userPrompt],
      ],
    ],
  ],
  'generationConfig' => [
    'responseMimeType' => 'application/json',
    'responseJsonSchema' => $responseSchema,
    'temperature' => 0.9,
    'maxOutputTokens' => 4096,
  ],
]);

$content = ieltslab_gemini_text($response);
if (!is_string($content) || trim($content) === '') {
    ieltslab_fail('The AI model returned an empty listening test.', 502);
}

$generated = json_decode($content, true);
if (!is_array($generated)) {
    ieltslab_fail('The AI model returned invalid listening JSON.', 502, ['providerBody' => $content]);
}

$test = ieltslab_validate_generated_test($generated);
$test['sessionId'] = $sessionId;
$test['targetBand'] = $targetBand;
$test['accentMix'] = $accentMix;
$test['theme'] = $theme !== '' ? $theme : 'General IELTS';
$test['createdAt'] = time();
$test['model'] = $model;
$test['audioUrl'] = '';
$test['audioReady'] = false;

ieltslab_save_test_session($sessionId, $test);

ieltslab_json_response([
    'success' => true,
    'session' => [
        'sessionId' => $test['sessionId'],
        'testTitle' => $test['testTitle'],
        'instructions' => $test['instructions'],
        'questionCount' => $test['questionCount'],
        'targetBand' => $test['targetBand'],
        'accentMix' => $test['accentMix'],
        'theme' => $test['theme'],
        'audioUrl' => $test['audioUrl'],
        'audioReady' => $test['audioReady'],
        'sections' => $test['sections'],
        'questions' => $test['questions'],
    ],
]);
