<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_json_response([
    'success' => true,
    'plans' => array_values(array_filter(ieltslab_load_plan_definitions(), static function (array $plan): bool {
        return (bool) ($plan['enabled'] ?? true);
    })),
]);
