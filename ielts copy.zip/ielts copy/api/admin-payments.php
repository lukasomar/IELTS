<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();

$historyPath = ieltslab_data_path('billing', 'history.json');
$history = ieltslab_read_json_file($historyPath, []);
if (!is_array($history)) {
    $history = [];
}

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    ieltslab_json_response([
        'success' => true,
        'plans' => ieltslab_load_plan_definitions(),
        'payments' => array_reverse($history),
        'users' => ieltslab_list_users_public(),
    ]);
}

ieltslab_require_post();
$input = ieltslab_read_json_request();
$action = trim((string) ($input['action'] ?? 'savePlan'));

if ($action === 'savePlan') {
    $plans = ieltslab_load_plan_definitions();
    $planId = trim((string) ($input['id'] ?? ieltslab_generate_session_id()));
    if ($planId === '') {
        $planId = ieltslab_generate_session_id();
    }
    $updated = false;
    foreach ($plans as &$plan) {
        if ((string) ($plan['id'] ?? '') !== $planId) {
            continue;
        }

        $plan = [
            'id' => $planId,
            'name' => trim((string) ($input['name'] ?? ($plan['name'] ?? 'Untitled Plan'))),
            'price' => max(0, (float) ($input['price'] ?? ($plan['price'] ?? 0))),
            'interval' => trim((string) ($input['interval'] ?? ($plan['interval'] ?? 'month'))),
            'enabled' => (bool) ($input['enabled'] ?? ($plan['enabled'] ?? true)),
            'features' => array_values(array_filter(array_map('trim', is_array($input['features'] ?? null) ? $input['features'] : explode("\n", (string) ($input['featuresText'] ?? ''))))),
            'updatedAt' => time(),
        ];
        $updated = true;
        break;
    }
    unset($plan);

    if (!$updated) {
        $plans[] = [
            'id' => $planId,
            'name' => trim((string) ($input['name'] ?? 'Untitled Plan')),
            'price' => max(0, (float) ($input['price'] ?? 0)),
            'interval' => trim((string) ($input['interval'] ?? 'month')),
            'enabled' => (bool) ($input['enabled'] ?? true),
            'features' => array_values(array_filter(array_map('trim', is_array($input['features'] ?? null) ? $input['features'] : explode("\n", (string) ($input['featuresText'] ?? ''))))),
            'updatedAt' => time(),
        ];
    }

    $plans = ieltslab_save_plan_definitions($plans);
    ieltslab_record_event('admin.plan_save', ['planId' => $planId], $admin);
    ieltslab_json_response(['success' => true, 'plans' => $plans]);
}

if ($action === 'deletePlan') {
    $planId = trim((string) ($input['id'] ?? ''));
    $plans = array_values(array_filter(ieltslab_load_plan_definitions(), static function (array $plan) use ($planId): bool {
        return (string) ($plan['id'] ?? '') !== $planId;
    }));
    $plans = ieltslab_save_plan_definitions($plans);
    ieltslab_record_event('admin.plan_delete', ['planId' => $planId], $admin);
    ieltslab_json_response(['success' => true, 'plans' => $plans]);
}

ieltslab_fail('Unsupported payment action.', 400);
