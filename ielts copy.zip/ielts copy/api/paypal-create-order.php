<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$user = ieltslab_require_auth();
ieltslab_require_post();

$input     = ieltslab_read_json_request();
$planId    = trim((string) ($input['planId'] ?? ''));
$method    = trim((string) ($input['method'] ?? 'paypal'));
$method    = in_array($method, ['paypal', 'card'], true) ? $method : 'paypal';

if ($planId === '') {
    ieltslab_fail('planId is required.', 400);
}

// Load plan definition
$plans = ieltslab_load_plan_definitions();
$plan  = null;
foreach ($plans as $p) {
    if ((string) ($p['id'] ?? '') === $planId) {
        $plan = $p;
        break;
    }
}
if (!$plan) {
    ieltslab_fail('Plan not found.', 404);
}

$price = (float) ($plan['price'] ?? 0);
if ($price <= 0) {
    ieltslab_fail('This plan is free and does not require payment.', 400);
}

// Load PayPal credentials
$settings  = ieltslab_load_platform_settings();
$paypal    = is_array($settings['integrations']['paypal'] ?? null)
    ? $settings['integrations']['paypal']
    : [];
$clientId  = trim((string) ($paypal['clientId'] ?? ''));
$secret    = trim((string) ($paypal['secretKey'] ?? ''));
$mode      = trim((string) ($paypal['mode'] ?? 'sandbox'));

if ($clientId === '' || $secret === '') {
    ieltslab_fail('PayPal is not configured. Contact your administrator.', 503);
}

$baseUrl = $mode === 'live'
    ? 'https://api-m.paypal.com'
    : 'https://api-m.sandbox.paypal.com';

// Get access token
$authResponse = ieltslab_http_post(
    $baseUrl . '/v1/oauth2/token',
    'grant_type=client_credentials',
    ['Content-Type: application/x-www-form-urlencoded'],
    $clientId . ':' . $secret
);

if (!isset($authResponse['access_token'])) {
    ieltslab_fail('PayPal authentication failed. Check your credentials.', 502);
}

$accessToken = (string) $authResponse['access_token'];
$referencePlan = preg_replace('/[^A-Za-z0-9._-]+/', '-', $planId);
if (!is_string($referencePlan) || $referencePlan === '') {
    $referencePlan = 'plan';
}
$referenceId = $referencePlan . '_' . (string) ($user['id'] ?? 'user');

// Create order
$orderPayload = json_encode([
    'intent'         => 'CAPTURE',
    'purchase_units' => [[
        'reference_id' => $referenceId,
        'description'  => $plan['name'] . ' Plan — ' . ($plan['interval'] ?? 'month'),
        'amount'       => [
            'currency_code' => 'USD',
            'value'         => number_format($price, 2, '.', ''),
        ],
    ]],
    'application_context' => [
        'brand_name'          => $settings['platformName'] ?? 'IELTSLab',
        'landing_page'        => $method === 'card' ? 'BILLING' : 'LOGIN',
        'user_action'         => 'PAY_NOW',
        'return_url'          => 'https://example.com/paypal-return',
        'cancel_url'          => 'https://example.com/paypal-cancel',
    ],
], JSON_UNESCAPED_SLASHES);

$orderResponse = ieltslab_http_post(
    $baseUrl . '/v2/checkout/orders',
    $orderPayload,
    [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken,
    ]
);

if (!isset($orderResponse['id'])) {
    ieltslab_fail('Failed to create PayPal order.', 502);
}

ieltslab_json_response([
    'success'     => true,
    'orderId'     => $orderResponse['id'],
    'status'      => $orderResponse['status'] ?? 'CREATED',
]);
