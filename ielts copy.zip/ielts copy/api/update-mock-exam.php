<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();

$sessionId = trim((string) ($input['sessionId'] ?? ''));
$action = trim((string) ($input['action'] ?? 'save'));
$sectionKey = trim((string) ($input['section'] ?? ''));
$session = ieltslab_read_json_file(ieltslab_data_path('exams', $sessionId . '.json'), null);
if (!is_array($session) || (string) ($session['userId'] ?? '') !== (string) $user['id']) {
    ieltslab_fail('Mock exam session not found.', 404);
}

foreach ($session['sections'] as $index => $section) {
    if (($section['key'] ?? '') !== $sectionKey) {
        continue;
    }

    if ($action === 'save') {
        $session['sections'][$index]['answers'] = is_array($input['answers'] ?? null) ? $input['answers'] : [];
        $session['sections'][$index]['status'] = 'in_progress';
    }

    if ($action === 'complete') {
        $session['sections'][$index]['status'] = 'completed';
        if (isset($session['sections'][$index + 1])) {
            $session['sections'][$index + 1]['status'] = 'ready';
        } else {
            $session['status'] = 'completed';
        }
    }
}

ieltslab_write_json_file(ieltslab_data_path('exams', $sessionId . '.json'), $session);
ieltslab_record_event('exam.update', ['sessionId' => $sessionId, 'action' => $action, 'section' => $sectionKey], $user);

ieltslab_json_response(['success' => true, 'session' => $session]);