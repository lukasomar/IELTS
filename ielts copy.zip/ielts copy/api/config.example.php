<?php

declare(strict_types=1);

// Copy this file to api/config.php on the server and fill in real values.
// Keep api/config.php out of version control.

define('GEMINI_API_KEY', 'replace-with-your-google-ai-studio-key');
define('GEMINI_MODEL', 'gemini-2.5-flash');
define('GEMINI_TTS_MODEL', 'gemini-2.5-flash-preview-tts');
define('GEMINI_TTS_VOICE', 'Kore');
define('GEMINI_SPEAKING_MODEL', 'gemini-2.5-flash');
