<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    ieltslab_json_response([
        'success' => true,
        'settings' => ieltslab_load_platform_settings(),
    ]);
}

ieltslab_require_post();

$contentType = (string) ($_SERVER['CONTENT_TYPE'] ?? '');
if (stripos($contentType, 'multipart/form-data') !== false) {
    $settings = ieltslab_load_platform_settings();
    $settings['platformName'] = trim((string) ($_POST['platformName'] ?? $settings['platformName'] ?? 'IELTSLab'));
    $settings['supportEmail'] = trim((string) ($_POST['supportEmail'] ?? $settings['supportEmail'] ?? ''));
    $settings['brand']['primaryColor'] = trim((string) ($_POST['primaryColor'] ?? ($settings['brand']['primaryColor'] ?? '#00bfa6')));
    $settings['brand']['accentColor'] = trim((string) ($_POST['accentColor'] ?? ($settings['brand']['accentColor'] ?? '#47d9cd')));
    $settings['integrations']['aiServiceKey'] = trim((string) ($_POST['aiServiceKey'] ?? ($settings['integrations']['aiServiceKey'] ?? '')));
    $settings['integrations']['paymentPublicKey'] = trim((string) ($_POST['paymentPublicKey'] ?? ($settings['integrations']['paymentPublicKey'] ?? '')));
    $settings['integrations']['paymentSecretKey'] = trim((string) ($_POST['paymentSecretKey'] ?? ($settings['integrations']['paymentSecretKey'] ?? '')));

    if (isset($_POST['paypalClientId']) || isset($_POST['paypalSecretKey']) || isset($_POST['paypalMode'])) {
        if (!is_array($settings['integrations']['paypal'] ?? null)) {
            $settings['integrations']['paypal'] = ['clientId' => '', 'secretKey' => '', 'mode' => 'sandbox'];
        }
        if (isset($_POST['paypalClientId'])) {
            $settings['integrations']['paypal']['clientId'] = trim((string) $_POST['paypalClientId']);
        }
        if (isset($_POST['paypalSecretKey'])) {
            $settings['integrations']['paypal']['secretKey'] = trim((string) $_POST['paypalSecretKey']);
        }
        if (isset($_POST['paypalMode'])) {
            $mode = trim((string) $_POST['paypalMode']);
            $settings['integrations']['paypal']['mode'] = in_array($mode, ['sandbox', 'live'], true) ? $mode : 'sandbox';
        }
    }

    foreach (['hero', 'listening', 'reading', 'writing', 'speaking'] as $slot) {
        $settings['landingMedia'][$slot]['mode'] = trim((string) ($_POST['landingMode_' . $slot] ?? ($settings['landingMedia'][$slot]['mode'] ?? 'image')));
        $settings['landingMedia'][$slot]['alt'] = trim((string) ($_POST['landingAlt_' . $slot] ?? ($settings['landingMedia'][$slot]['alt'] ?? '')));

        $lightSrcInput = trim((string) ($_POST['landingLightSrc_' . $slot] ?? ''));
        if ($lightSrcInput !== '') {
            $settings['landingMedia'][$slot]['lightSrc'] = $lightSrcInput;
        }

        $darkSrcInput = trim((string) ($_POST['landingDarkSrc_' . $slot] ?? ''));
        if ($darkSrcInput !== '') {
            $settings['landingMedia'][$slot]['darkSrc'] = $darkSrcInput;
        }

        $srcInput = trim((string) ($_POST['landingSrc_' . $slot] ?? ''));
        if ($srcInput !== '') {
            $settings['landingMedia'][$slot]['src'] = $srcInput;
        }

        $posterInput = trim((string) ($_POST['landingPoster_' . $slot] ?? ''));
        if ($posterInput !== '') {
            $settings['landingMedia'][$slot]['poster'] = $posterInput;
        }

        $fileKey = 'landingFile_' . $slot;
        if (isset($_FILES[$fileKey]) && is_array($_FILES[$fileKey]) && (int) ($_FILES[$fileKey]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $settings['landingMedia'][$slot]['src'] = ieltslab_save_landing_media_asset($_FILES[$fileKey], $slot, 'media');
        }

        $lightFileKey = 'landingLightFile_' . $slot;
        if (isset($_FILES[$lightFileKey]) && is_array($_FILES[$lightFileKey]) && (int) ($_FILES[$lightFileKey]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $settings['landingMedia'][$slot]['lightSrc'] = ieltslab_save_landing_media_asset($_FILES[$lightFileKey], $slot, 'light');
        }

        $darkFileKey = 'landingDarkFile_' . $slot;
        if (isset($_FILES[$darkFileKey]) && is_array($_FILES[$darkFileKey]) && (int) ($_FILES[$darkFileKey]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $settings['landingMedia'][$slot]['darkSrc'] = ieltslab_save_landing_media_asset($_FILES[$darkFileKey], $slot, 'dark');
        }

        $posterFileKey = 'landingPosterFile_' . $slot;
        if (isset($_FILES[$posterFileKey]) && is_array($_FILES[$posterFileKey]) && (int) ($_FILES[$posterFileKey]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            $settings['landingMedia'][$slot]['poster'] = ieltslab_save_landing_media_asset($_FILES[$posterFileKey], $slot, 'poster');
        }
    }

    if (isset($_FILES['logo']) && is_array($_FILES['logo']) && (int) ($_FILES['logo']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
        $settings['logoUrl'] = ieltslab_save_brand_asset($_FILES['logo']);
    }

    $settings = ieltslab_save_platform_settings($settings);
    ieltslab_record_event('admin.settings_save', ['mode' => 'multipart'], $admin);
    ieltslab_json_response(['success' => true, 'settings' => $settings]);
}

$input = ieltslab_read_json_request();
$settings = ieltslab_save_platform_settings([
    'platformName' => $input['platformName'] ?? 'IELTSLab',
    'supportEmail' => $input['supportEmail'] ?? '',
    'logoUrl' => $input['logoUrl'] ?? '',
    'landingMedia' => is_array($input['landingMedia'] ?? null) ? $input['landingMedia'] : [],
    'brand' => is_array($input['brand'] ?? null) ? $input['brand'] : [],
    'integrations' => is_array($input['integrations'] ?? null) ? $input['integrations'] : [],
]);

ieltslab_record_event('admin.settings_save', ['mode' => 'json'], $admin);
ieltslab_json_response(['success' => true, 'settings' => $settings]);
