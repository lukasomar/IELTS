<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $token = trim((string) ($_GET['token'] ?? ''));
    if ($token === '') {
        ieltslab_fail('Reset token is required.', 400);
    }

    $path = ieltslab_data_path('password-resets', $token . '.json');
    $record = ieltslab_read_json_file($path, null);
    if (!is_array($record) || (int) ($record['expiresAt'] ?? 0) < time()) {
        ieltslab_fail('Invalid or expired reset token.', 400);
    }

    ieltslab_json_response(['success' => true, 'valid' => true]);
}

ieltslab_require_post();
$input = ieltslab_read_json_request();
$token = trim((string) ($input['token'] ?? ''));
$newPassword = (string) ($input['newPassword'] ?? '');

if ($token === '' || strlen($newPassword) < 8) {
    ieltslab_fail('Token and a password of at least 8 characters are required.', 400);
}

$record = ieltslab_consume_token('password-resets', $token);
$user = ieltslab_load_user_by_id((string) ($record['userId'] ?? ''));
if (!$user) {
    ieltslab_fail('User not found for reset token.', 404);
}

$user['passwordHash'] = password_hash($newPassword, PASSWORD_DEFAULT);
$user = ieltslab_save_user($user);
ieltslab_record_event('auth.reset_password', [], $user);

ieltslab_json_response(['success' => true, 'message' => 'Password reset successfully.']);