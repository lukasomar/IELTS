<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_json_response(array_merge(['success' => true], ieltslab_catalog_payload()));