<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_json_response([
    'success' => true,
    'settings' => ieltslab_public_platform_settings(),
]);
