<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_current_user();
$input = ieltslab_read_json_request();
$type = trim((string) ($input['type'] ?? 'ui.event'));
$payload = is_array($input['payload'] ?? null) ? $input['payload'] : [];

ieltslab_record_event($type, $payload, $user);
ieltslab_json_response(['success' => true]);