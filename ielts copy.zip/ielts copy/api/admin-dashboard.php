<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();
ieltslab_record_event('admin.dashboard', [], $admin);

ieltslab_json_response([
    'success' => true,
    'summary' => ieltslab_analytics_summary(),
    'users' => array_slice(ieltslab_list_users_public(), 0, 20),
    'resources' => array_slice(ieltslab_admin_resources(), 0, 50),
    'outbox' => ieltslab_list_outbox(),
]);