# Shared Hosting IELTSLab Backend

This folder contains the shared-hosting-safe PHP backend for the IELTSLab frontend shell.

## What it uses

- Static frontend files from the main site
- PHP endpoints in `api/`
- File-based storage in `api/storage/`
- Cookie-based sessions for auth
- Google AI Studio / Gemini API for generation, speech, and evaluation

## Setup

1. Copy `.env.example` to `.env` in the project root.
2. Fill in your real app URL, admin credentials, and Gemini API key.
3. Make sure the hosting account has:
   - PHP with cURL enabled
   - permission to write inside `api/storage/`
   - permission to write inside `user-content/` if admin uploads are enabled
4. Upload the whole site to your shared hosting account.

## Platform Endpoints

- `POST api/auth-signup.php`
- `POST api/auth-login.php`
- `POST api/auth-logout.php`
- `GET api/auth-me.php`
- `POST api/auth-update-profile.php`
- `GET admin/`
- `GET api/admin-dashboard.php`
- `GET|POST api/admin-users.php`
- `GET|POST api/admin-resources.php`
- `GET|POST api/admin-tests.php`
- `GET|POST api/admin-submissions.php`
- `GET|POST api/admin-payments.php`
- `GET|POST api/admin-settings.php`
- `GET api/admin-analytics.php`
- `POST api/analytics-track.php`

## AI Endpoints

- `POST api/generate-listening-test.php`
- `POST api/generate-listening-audio.php`
- `POST api/score-listening-test.php`
- `POST api/evaluate-speaking.php`
- `POST api/evaluate-writing.php`
- `POST api/generate-reading-test.php`
- `POST api/score-reading-test.php`
- `POST api/start-mock-exam.php`
- `POST api/update-mock-exam.php`
- `GET api/listening-audio.php?sessionId=...`

## Notes

- This implementation is built to avoid a dedicated Node server.
- Auth, users, sessions, analytics, and generated content are stored as JSON files under `api/storage/`.
- The admin experience is now a separate route under `admin/`; the main app should link to `/admin/` instead of rendering admin panels inside the student SPA.
- Generated audio is stored as WAV files and streamed through PHP.
- Listening test JSON and listening audio are generated as separate steps so the UI can return the question set before TTS completes.
- Speaking evaluation uploads audio with multipart form data, sends it to Gemini as inline audio, and returns a transcript plus IELTS-style feedback in one response.
- The frontend now expects to be served through PHP or a web server, not opened directly as a file, because auth uses real API calls and session cookies.
- If your host allows it, keep `.env` outside the public web root and load it from server environment variables instead.

## Local Validation

1. Start the project through PHP, for example `C:\php\php.exe -S 127.0.0.1:8001` from the project root.
2. Open the student app at `/` and the admin portal at `/admin/`.
3. Run `npm test` to syntax-check the key frontend and admin files and lint the important PHP entry points.
4. Run `npm run smoke` to execute isolated auth/profile/mock-exam flow tests against a temporary storage root.
5. In PowerShell, set `$env:SMOKE_AI='1'` before `npm run smoke` if you also want provider-backed reading and writing smoke checks.
6. Follow the smoke checklist in `docs/admin-smoke-test.md` before deployment.
