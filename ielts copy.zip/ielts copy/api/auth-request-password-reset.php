<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$input = ieltslab_read_json_request();
$email = ieltslab_normalize_email((string) ($input['email'] ?? ''));

$user = $email !== '' ? ieltslab_find_user_by_email($email) : null;
$response = [
    'success' => true,
    'message' => 'If the account exists, a reset link has been prepared.',
];

if ($user) {
    $record = ieltslab_issue_token('password-resets', $user, 3600, ['type' => 'reset']);
    ieltslab_outbox_message('reset', $user, $record);
    ieltslab_record_event('auth.request_password_reset', [], $user);
    if ((ieltslab_setting('APP_ENV', 'production') ?? 'production') !== 'production') {
        $response['resetToken'] = $record['token'];
    }
}

ieltslab_json_response($response);