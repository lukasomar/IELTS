<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();

$planId = trim((string) ($input['planId'] ?? ''));
$planName = trim((string) ($input['plan'] ?? ''));
$planAmount = 0.0;
$planCurrency = 'USD';

if ($planId !== '') {
    $plans = ieltslab_load_plan_definitions();
    $selectedPlan = null;
    foreach ($plans as $plan) {
        if ((string) ($plan['id'] ?? '') !== $planId) {
            continue;
        }
        $selectedPlan = $plan;
        break;
    }

    if (!$selectedPlan) {
        ieltslab_fail('Selected plan was not found.', 404);
    }

    if (!((bool) ($selectedPlan['enabled'] ?? true))) {
        ieltslab_fail('Selected plan is not available.', 400);
    }

    $planName = trim((string) ($selectedPlan['name'] ?? 'Pro'));
    $planAmount = max(0, (float) ($selectedPlan['price'] ?? 0));
} else {
    // Backward compatibility with old clients that only send plan name.
    $planName = $planName !== '' ? $planName : 'Pro';
    if (!in_array($planName, ['Free', 'Pro'], true)) {
        ieltslab_fail('Invalid plan selected.', 400);
    }
    $planAmount = $planName === 'Pro' ? 19.0 : 0.0;
}

$record = [
    'id' => ieltslab_generate_session_id(),
    'userId' => $user['id'],
    'planId' => $planId !== '' ? $planId : strtolower($planName),
    'plan' => $planName,
    'planName' => $planName,
    'provider' => 'manual',
    'status' => 'completed',
    'amount' => $planAmount,
    'currency' => $planCurrency,
    'createdAt' => time(),
];

$historyPath = ieltslab_data_path('billing', 'history.json');
$history = ieltslab_read_json_file($historyPath, []);
if (!is_array($history)) {
    $history = [];
}
$history[] = $record;
ieltslab_write_json_file($historyPath, $history);

$user['plan'] = $planName;
$user['subscription'] = [
    'status' => 'active',
    'provider' => 'manual',
        'planId' => $record['planId'],
        'planName' => $planName,
    'startedAt' => time(),
    'renewsAt' => time() + 2592000,
  ];
$user = ieltslab_save_user($user);
ieltslab_record_event('billing.checkout', ['plan' => $planName, 'planId' => $record['planId'], 'amount' => $planAmount], $user);

ieltslab_json_response([
    'success' => true,
    'mode' => 'manual',
    'user' => ieltslab_public_user($user),
    'record' => $record,
]);