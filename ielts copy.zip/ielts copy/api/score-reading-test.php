<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();
$sessionId = trim((string) ($input['sessionId'] ?? ''));
$answers = is_array($input['answers'] ?? null) ? $input['answers'] : [];

$session = ieltslab_read_json_file(ieltslab_data_path('reading', $sessionId . '.json'), null);
if (!is_array($session)) {
    ieltslab_fail('Reading session not found.', 404);
}

$results = [];
$correct = 0;
foreach (($session['questions'] ?? []) as $question) {
    $number = (string) ($question['number'] ?? '');
    $userAnswer = ieltslab_normalize_answer((string) ($answers[$number] ?? ''));
    $accepted = array_map('ieltslab_normalize_answer', array_map('strval', $question['acceptedAnswers'] ?? []));
    $isCorrect = $userAnswer !== '' && in_array($userAnswer, $accepted, true);
    if ($isCorrect) {
        $correct++;
    }
    $results[] = [
        'number' => (int) $number,
        'prompt' => (string) ($question['prompt'] ?? ''),
        'userAnswer' => $answers[$number] ?? '',
        'canonicalAnswer' => (string) ($question['canonicalAnswer'] ?? ''),
        'isCorrect' => $isCorrect,
        'explanation' => (string) ($question['explanation'] ?? ''),
    ];
}

$band = ieltslab_listening_band_from_raw($correct);
$user['progress']['skills']['reading']['status'] = 'In progress';
$user['progress']['skills']['reading']['band'] = $band;
$user['progress']['overallBand'] = $band;
$user = ieltslab_save_user($user);
ieltslab_record_event('reading.score', ['sessionId' => $sessionId, 'rawScore' => $correct], $user);

ieltslab_json_response([
    'success' => true,
    'result' => [
        'rawScore' => $correct,
        'totalQuestions' => count($session['questions'] ?? []),
        'correctCount' => $correct,
        'incorrectCount' => max(0, count($session['questions'] ?? []) - $correct),
        'bandScore' => $band,
        'questionResults' => $results,
    ],
]);