<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();

$taskType = trim((string) ($input['taskType'] ?? 'Task 2'));
$prompt = trim((string) ($input['prompt'] ?? ''));
$essay = trim((string) ($input['essay'] ?? ''));
$targetBand = trim((string) ($input['targetBand'] ?? '7.0'));

if ($essay === '') {
    ieltslab_fail('Essay text is required.', 400);
}

$model = ieltslab_setting('GEMINI_MODEL', 'gemini-2.5-flash') ?? 'gemini-2.5-flash';
$responseSchema = [
    'type' => 'object',
    'properties' => [
        'overallBand' => ['type' => 'number'],
        'breakdown' => [
            'type' => 'object',
            'properties' => [
                'taskResponse' => ['type' => 'number'],
                'coherence' => ['type' => 'number'],
                'lexicalResource' => ['type' => 'number'],
                'grammar' => ['type' => 'number'],
            ],
            'required' => ['taskResponse', 'coherence', 'lexicalResource', 'grammar'],
        ],
        'summary' => ['type' => 'string'],
        'improvements' => ['type' => 'array', 'items' => ['type' => 'string'], 'minItems' => 3, 'maxItems' => 5],
        'correctedSample' => ['type' => 'string'],
    ],
    'required' => ['overallBand', 'breakdown', 'summary', 'improvements', 'correctedSample'],
];

$promptText = <<<PROMPT
You are an IELTS writing examiner.
Return only valid JSON.
Evaluate this {$taskType} essay for target band {$targetBand}.

Prompt: {$prompt}

Essay:
{$essay}
PROMPT;

$response = ieltslab_gemini_request($model, [
    'contents' => [[
        'role' => 'user',
        'parts' => [['text' => $promptText]],
    ]],
    'generationConfig' => [
        'responseMimeType' => 'application/json',
        'responseJsonSchema' => $responseSchema,
        'temperature' => 0.4,
        'maxOutputTokens' => 2048,
    ],
]);

$content = ieltslab_gemini_text($response);
$decoded = json_decode($content, true);
if (!is_array($decoded)) {
    ieltslab_fail('The writing analysis response was invalid JSON.', 502, ['providerBody' => $content]);
}

$result = [
    'attemptId' => ieltslab_generate_session_id(),
    'taskType' => $taskType,
    'targetBand' => $targetBand,
    'overallBand' => (float) ($decoded['overallBand'] ?? 0),
    'breakdown' => [
        'taskResponse' => (float) ($decoded['breakdown']['taskResponse'] ?? 0),
        'coherence' => (float) ($decoded['breakdown']['coherence'] ?? 0),
        'lexicalResource' => (float) ($decoded['breakdown']['lexicalResource'] ?? 0),
        'grammar' => (float) ($decoded['breakdown']['grammar'] ?? 0),
    ],
    'summary' => (string) ($decoded['summary'] ?? ''),
    'improvements' => array_values(array_filter(array_map('strval', $decoded['improvements'] ?? []))),
    'correctedSample' => (string) ($decoded['correctedSample'] ?? ''),
    'createdAt' => time(),
    'prompt' => $prompt,
];

ieltslab_write_json_file(ieltslab_data_path('writing', $result['attemptId'] . '.json'), $result + ['essay' => $essay, 'userId' => $user['id']]);
$submission = ieltslab_save_submission([
    'id' => 'writing-' . $result['attemptId'],
    'type' => 'writing',
    'userId' => $user['id'],
    'userName' => $user['name'] ?? '',
    'status' => 'reviewed',
    'prompt' => $prompt,
    'taskType' => $taskType,
    'essay' => $essay,
    'assignedReviewerId' => null,
    'reviewBand' => $result['overallBand'],
    'reviewFeedback' => $result['summary'],
    'result' => $result,
]);
$user['progress']['skills']['writing']['status'] = 'In progress';
$user['progress']['skills']['writing']['band'] = $result['overallBand'];
$user['progress']['overallBand'] = $result['overallBand'];
$user = ieltslab_save_user($user);
ieltslab_record_event('writing.evaluate', ['attemptId' => $result['attemptId']], $user);

ieltslab_json_response(['success' => true, 'result' => $result, 'submission' => $submission]);