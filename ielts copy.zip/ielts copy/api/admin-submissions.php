<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $reviewers = array_values(array_filter(ieltslab_list_users_public(), static function (array $user): bool {
        return in_array((string) ($user['role'] ?? 'student'), ['instructor', 'admin'], true);
    }));

    ieltslab_json_response([
        'success' => true,
        'submissions' => ieltslab_list_submissions(),
        'reviewers' => $reviewers,
    ]);
}

ieltslab_require_post();
$input = ieltslab_read_json_request();
$submissionId = trim((string) ($input['id'] ?? ''));
if ($submissionId === '') {
    ieltslab_fail('Submission id is required.', 400);
}

$current = ieltslab_read_json_file(ieltslab_submission_path($submissionId), null);
if (!is_array($current)) {
    ieltslab_fail('Submission not found.', 404);
}

$current['assignedReviewerId'] = $input['assignedReviewerId'] ?? ($current['assignedReviewerId'] ?? null);
$current['status'] = trim((string) ($input['status'] ?? ($current['status'] ?? 'pending_review')));
$current['reviewBand'] = isset($input['reviewBand']) ? (float) $input['reviewBand'] : ($current['reviewBand'] ?? null);
$current['reviewFeedback'] = trim((string) ($input['reviewFeedback'] ?? ($current['reviewFeedback'] ?? '')));

$updated = ieltslab_save_submission($current);
ieltslab_record_event('admin.submission_update', ['submissionId' => $submissionId], $admin);

ieltslab_json_response(['success' => true, 'submission' => $updated]);
