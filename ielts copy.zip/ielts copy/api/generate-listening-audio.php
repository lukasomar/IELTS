<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$input = ieltslab_read_json_request();
$sessionId = trim((string) ($input['sessionId'] ?? ''));

if ($sessionId === '') {
    ieltslab_fail('sessionId is required.', 400);
}

$session = ieltslab_load_test_session($sessionId);

if (ieltslab_audio_exists($sessionId)) {
    ieltslab_json_response([
        'success' => true,
        'audioUrl' => ieltslab_audio_public_url($sessionId),
        'audioReady' => true,
        'cached' => true,
    ]);
}

$ttsModel = ieltslab_setting('GEMINI_TTS_MODEL', 'gemini-2.5-flash-preview-tts') ?? 'gemini-2.5-flash-preview-tts';
$ttsVoice = ieltslab_setting('GEMINI_TTS_VOICE', 'Kore') ?? 'Kore';
$accentMix = trim((string) ($session['accentMix'] ?? 'mixed'));
$spokenTranscript = ieltslab_prepare_tts_transcript((string) ($session['transcript'] ?? ''));

if ($spokenTranscript === '') {
    ieltslab_fail('The saved listening transcript is empty.', 500);
}

$accentDirection = match ($accentMix) {
    'british' => 'Use a clear contemporary British English accent.',
    'australian' => 'Use a clear Australian English accent.',
    'north-american' => 'Use a clear North American English accent.',
    default => 'Use a neutral exam-style English accent that sounds natural for IELTS listening practice.',
};

$audioResponse = ieltslab_gemini_request($ttsModel, [
    'systemInstruction' => [
        'parts' => [
            ['text' => "Speak exactly the provided transcript. Do not add introductions, labels, or explanations. {$accentDirection}"],
        ],
    ],
    'contents' => [
        [
            'role' => 'user',
            'parts' => [
                ['text' => $spokenTranscript],
            ],
        ],
    ],
    'generationConfig' => [
        'responseModalities' => ['AUDIO'],
        'speechConfig' => [
            'voiceConfig' => [
                'prebuiltVoiceConfig' => [
                    'voiceName' => $ttsVoice,
                ],
            ],
            'languageCode' => 'en-GB',
        ],
    ],
], 360, 3);

$audioPart = ieltslab_gemini_inline_data($audioResponse);
$audioPcm = isset($audioPart['data']) ? base64_decode((string) $audioPart['data'], true) : false;

if (!is_string($audioPcm) || $audioPcm === '') {
    ieltslab_fail('The Gemini text-to-speech response did not include audio data.', 502, ['providerBody' => ieltslab_safe_provider_body(json_encode($audioResponse, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) ?: '')]);
}

$audioBinary = ieltslab_pcm_to_wav($audioPcm);
ieltslab_save_audio_file($sessionId, $audioBinary, 'wav');

$session['audioUrl'] = ieltslab_audio_public_url($sessionId);
$session['audioReady'] = true;
ieltslab_save_test_session($sessionId, $session);

ieltslab_json_response([
    'success' => true,
    'audioUrl' => $session['audioUrl'],
    'audioReady' => true,
    'cached' => false,
]);