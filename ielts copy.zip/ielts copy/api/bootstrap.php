<?php

declare(strict_types=1);

error_reporting(E_ALL);
ini_set('display_errors', '0');

function ieltslab_load_env_file(string $path): void
{
    if (!is_file($path) || !is_readable($path)) {
        return;
    }

    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    if (!is_array($lines)) {
        return;
    }

    foreach ($lines as $line) {
        $line = trim((string) $line);
        if ($line === '' || str_starts_with($line, '#')) {
            continue;
        }

        $separator = strpos($line, '=');
        if ($separator === false) {
            continue;
        }

        $key = trim(substr($line, 0, $separator));
        $value = trim(substr($line, $separator + 1));
        if ($key === '') {
            continue;
        }

        if ((str_starts_with($value, '"') && str_ends_with($value, '"')) || (str_starts_with($value, "'") && str_ends_with($value, "'"))) {
            $value = substr($value, 1, -1);
        }

        putenv($key . '=' . $value);
        $_ENV[$key] = $value;
        $_SERVER[$key] = $value;
    }
}

ieltslab_load_env_file(dirname(__DIR__) . '/.env');
ieltslab_load_env_file(__DIR__ . '/.env');

$localConfig = __DIR__ . '/config.php';
if (is_file($localConfig)) {
    require_once $localConfig;
}

set_exception_handler(static function ($exception): void {
    $message = $exception instanceof Throwable ? $exception->getMessage() : 'Unhandled server exception.';
    ieltslab_json_response(['success' => false, 'error' => $message], 500);
});

set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if (!(error_reporting() & $severity)) {
        return false;
    }

    throw new ErrorException($message, 0, $severity, $file, $line);
});

register_shutdown_function(static function (): void {
    $error = error_get_last();
    if (!$error) {
        return;
    }

    $fatalTypes = [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR];
    if (!in_array($error['type'], $fatalTypes, true)) {
        return;
    }

    if (!headers_sent()) {
        http_response_code(500);
        header('Content-Type: application/json; charset=utf-8');
    }

    echo json_encode([
        'success' => false,
        'error' => 'Server error: ' . $error['message'],
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
});

function ieltslab_json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function ieltslab_fail(string $message, int $status = 400, array $extra = []): void
{
    ieltslab_json_response(array_merge(['success' => false, 'error' => $message], $extra), $status);
}

function ieltslab_require_post(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
        ieltslab_fail('Method not allowed.', 405);
    }
}

function ieltslab_read_json_request(): array
{
    $raw = file_get_contents('php://input') ?: '';
    if ($raw === '') {
        return [];
    }

    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        ieltslab_fail('Invalid JSON request body.', 400);
    }

    return $decoded;
}

function ieltslab_setting(string $key, ?string $default = null): ?string
{
    if (defined($key)) {
        $value = constant($key);
        return $value === null ? $default : (string) $value;
    }

    $env = getenv($key);
    if ($env !== false && $env !== '') {
        return (string) $env;
    }

    if (isset($_ENV[$key]) && $_ENV[$key] !== '') {
        return (string) $_ENV[$key];
    }

    return $default;
}

function ieltslab_storage_path(string $type, string $fileName = ''): string
{
    $storageRoot = ieltslab_setting('IELTSLAB_STORAGE_DIR', ieltslab_setting('STORAGE_DIR', __DIR__ . '/storage'));
    $base = rtrim((string) $storageRoot, '/\\') . '/' . trim($type, '/');
    if ($fileName === '') {
        return $base;
    }

    return $base . '/' . ltrim($fileName, '/');
}

function ieltslab_ensure_storage(): void
{
    foreach (['tests', 'audio'] as $folder) {
        $path = ieltslab_storage_path($folder);
        if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
            ieltslab_fail('Failed to prepare writable storage at ' . $path . '.', 500);
        }
    }
}

function ieltslab_gemini_api_key(): string
{
    $apiKey = ieltslab_setting('GEMINI_API_KEY');
    if (!$apiKey) {
        ieltslab_fail('GEMINI_API_KEY is not configured. Create api/config.php from api/config.example.php or set the environment variable on your host.', 503);
    }

    return $apiKey;
}

function ieltslab_gemini_request(string $model, array $payload, int $timeoutSeconds = 240, int $maxAttempts = 1): array
{
    if (!function_exists('curl_init')) {
        ieltslab_fail('The cURL extension is required on the hosting account.', 500);
    }

    $url = 'https://generativelanguage.googleapis.com/v1beta/models/' . rawurlencode($model) . ':generateContent';

    $attempt = 0;
    $lastBody = '';
    $lastError = '';
    $lastStatus = 0;

    while ($attempt < max(1, $maxAttempts)) {
        $attempt++;

        $curl = curl_init($url);
        curl_setopt_array($curl, [
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'x-goog-api-key: ' . ieltslab_gemini_api_key(),
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => $timeoutSeconds,
        ]);

        $body = curl_exec($curl);
        $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
        $error = curl_error($curl);
        curl_close($curl);

        $lastBody = is_string($body) ? $body : '';
        $lastError = (string) $error;
        $lastStatus = $status;

        $shouldRetry = false;
        if ($body === false || $error !== '') {
            $shouldRetry = $attempt < $maxAttempts;
            if (!$shouldRetry) {
                ieltslab_fail('Gemini request failed: ' . $error, 502);
            }
        } elseif ($status >= 500) {
            $shouldRetry = $attempt < $maxAttempts;
            if (!$shouldRetry) {
                $providerMessage = ieltslab_extract_provider_error($lastBody);
                $message = $providerMessage !== ''
                    ? 'Gemini error: ' . $providerMessage
                    : 'Gemini request failed with status ' . $status . '.';
                ieltslab_fail($message, 502, ['providerBody' => ieltslab_safe_provider_body($lastBody)]);
            }
        } elseif ($status >= 400) {
            $providerMessage = ieltslab_extract_provider_error($lastBody);
            $message = $providerMessage !== ''
                ? 'Gemini error: ' . $providerMessage
                : 'Gemini request failed with status ' . $status . '.';
            ieltslab_fail($message, 502, ['providerBody' => ieltslab_safe_provider_body($lastBody)]);
        } else {
            $decoded = json_decode($lastBody, true);
            if (!is_array($decoded)) {
                ieltslab_fail('Gemini returned invalid JSON.', 502, ['providerBody' => ieltslab_safe_provider_body($lastBody)]);
            }

            return $decoded;
        }

        if ($shouldRetry) {
            usleep(1000000 * $attempt);
        }
    }

    $providerMessage = ieltslab_extract_provider_error($lastBody);
    $message = $lastError !== ''
        ? 'Gemini request failed: ' . $lastError
        : ($providerMessage !== '' ? 'Gemini error: ' . $providerMessage : 'Gemini request failed with status ' . $lastStatus . '.');
    ieltslab_fail($message, 502, ['providerBody' => ieltslab_safe_provider_body($lastBody)]);
}

function ieltslab_gemini_text(array $response): string
{
    $parts = $response['candidates'][0]['content']['parts'] ?? null;
    if (!is_array($parts)) {
        return '';
    }

    $text = '';
    foreach ($parts as $part) {
        if (is_array($part) && isset($part['text']) && is_string($part['text'])) {
            $text .= $part['text'];
        }
    }

    return trim($text);
}

function ieltslab_gemini_inline_data(array $response): array
{
    $parts = $response['candidates'][0]['content']['parts'] ?? null;
    if (!is_array($parts)) {
        return [];
    }

    foreach ($parts as $part) {
        if (!is_array($part)) {
            continue;
        }

        $inline = $part['inlineData'] ?? $part['inline_data'] ?? null;
        if (!is_array($inline)) {
            continue;
        }

        $data = $inline['data'] ?? null;
        if (!is_string($data) || $data === '') {
            continue;
        }

        return [
            'data' => $data,
            'mimeType' => (string) ($inline['mimeType'] ?? $inline['mime_type'] ?? 'application/octet-stream'),
        ];
    }

    return [];
}

function ieltslab_pcm_to_wav(string $pcm, int $sampleRate = 24000, int $channels = 1, int $bitsPerSample = 16): string
{
    $byteRate = $sampleRate * $channels * (int) ($bitsPerSample / 8);
    $blockAlign = $channels * (int) ($bitsPerSample / 8);
    $dataLength = strlen($pcm);
    $chunkSize = 36 + $dataLength;

    return 'RIFF'
        . pack('V', $chunkSize)
        . 'WAVE'
        . 'fmt '
        . pack('V', 16)
        . pack('v', 1)
        . pack('v', $channels)
        . pack('V', $sampleRate)
        . pack('V', $byteRate)
        . pack('v', $blockAlign)
        . pack('v', $bitsPerSample)
        . 'data'
        . pack('V', $dataLength)
        . $pcm;
}

function ieltslab_safe_provider_body(string $body): string
{
    if ($body === '') {
        return '';
    }

    if (preg_match('//u', $body)) {
        return $body;
    }

    return '[non-utf8 provider body omitted]';
}

function ieltslab_extract_provider_error(string $body): string
{
    $decoded = json_decode($body, true);
    if (!is_array($decoded) || !isset($decoded['error'])) {
        return '';
    }

    $error = $decoded['error'];
    if (is_array($error) && isset($error['message']) && is_string($error['message'])) {
        return trim($error['message']);
    }

    if (is_string($error)) {
        return trim($error);
    }

    return '';
}

function ieltslab_generate_session_id(): string
{
    return bin2hex(random_bytes(8));
}

function ieltslab_save_test_session(string $sessionId, array $payload): void
{
    ieltslab_ensure_storage();
    $path = ieltslab_storage_path('tests', $sessionId . '.json');
    file_put_contents($path, json_encode($payload, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
}

function ieltslab_load_test_session(string $sessionId): array
{
    $path = ieltslab_storage_path('tests', $sessionId . '.json');
    if (!is_file($path)) {
        ieltslab_fail('Listening session not found. Generate a new test first.', 404);
    }

    $decoded = json_decode((string) file_get_contents($path), true);
    if (!is_array($decoded)) {
        ieltslab_fail('Stored listening session is invalid.', 500);
    }

    return $decoded;
}

function ieltslab_save_audio_file(string $sessionId, string $audioBinary, string $extension = 'mp3'): string
{
    ieltslab_ensure_storage();
    $path = ieltslab_storage_path('audio', $sessionId . '.' . ltrim($extension, '.'));
    file_put_contents($path, $audioBinary);
    return $path;
}

function ieltslab_audio_public_url(string $sessionId): string
{
    return 'api/listening-audio.php?sessionId=' . rawurlencode($sessionId);
}

function ieltslab_audio_exists(string $sessionId): bool
{
    return is_file(ieltslab_storage_path('audio', $sessionId . '.wav'))
        || is_file(ieltslab_storage_path('audio', $sessionId . '.mp3'));
}

function ieltslab_prepare_tts_transcript(string $transcript): string
{
    $cleaned = preg_replace('/\([^\)]*\)/u', ' ', $transcript) ?? $transcript;
    $cleaned = preg_replace('/\b[A-Za-z][A-Za-z ]{0,30}:\s*/u', '', $cleaned) ?? $cleaned;
    $cleaned = preg_replace('/\s+/u', ' ', $cleaned) ?? $cleaned;

    return trim($cleaned);
}

function ieltslab_normalize_answer(string $value): string
{
    $value = trim(mb_strtolower($value, 'UTF-8'));
    $value = preg_replace('/[[:punct:]]+/u', ' ', $value) ?? $value;
    $value = preg_replace('/\s+/u', ' ', $value) ?? $value;
    return trim($value);
}

function ieltslab_listening_band_from_raw(int $rawScore): float
{
    $map = [
        39 => 9.0,
        37 => 8.5,
        35 => 8.0,
        32 => 7.5,
        30 => 7.0,
        26 => 6.5,
        23 => 6.0,
        18 => 5.5,
        16 => 5.0,
        13 => 4.5,
        10 => 4.0,
        8 => 3.5,
        6 => 3.0,
        4 => 2.5,
        2 => 2.0,
        1 => 1.0,
    ];

    foreach ($map as $threshold => $band) {
        if ($rawScore >= $threshold) {
            return $band;
        }
    }

    return 0.0;
}

function ieltslab_validate_generated_test(array $data): array
{
    if (!isset($data['testTitle'], $data['instructions'], $data['transcript'], $data['sections'], $data['questions'])) {
        ieltslab_fail('The AI response was missing required fields.', 502);
    }

    if (!is_array($data['sections']) || !is_array($data['questions']) || !$data['questions']) {
        ieltslab_fail('The AI response did not include a valid question set.', 502);
    }

    $questions = [];
    foreach ($data['questions'] as $index => $question) {
        if (!is_array($question)) {
            ieltslab_fail('Question #' . ($index + 1) . ' is invalid.', 502);
        }

        $number = isset($question['number']) ? (int) $question['number'] : $index + 1;
        $accepted = $question['acceptedAnswers'] ?? [];
        if (!isset($question['prompt']) || !is_array($accepted) || !$accepted) {
            ieltslab_fail('Question #' . $number . ' is missing prompt or accepted answers.', 502);
        }

        $question['number'] = $number;
        $question['type'] = isset($question['type']) ? (string) $question['type'] : 'short_answer';
        $question['typeLabel'] = isset($question['typeLabel']) ? (string) $question['typeLabel'] : ucwords(str_replace('_', ' ', $question['type']));
        $question['acceptedAnswers'] = array_values(array_filter(array_map('strval', $accepted)));
        $question['canonicalAnswer'] = isset($question['canonicalAnswer']) ? (string) $question['canonicalAnswer'] : $question['acceptedAnswers'][0];
        $question['sectionNumber'] = isset($question['sectionNumber']) ? (int) $question['sectionNumber'] : 1;
        $question['options'] = isset($question['options']) && is_array($question['options']) ? array_values($question['options']) : [];
        $question['explanation'] = isset($question['explanation']) ? (string) $question['explanation'] : 'The answer is supported by the generated transcript.';
        $questions[] = $question;
    }

    usort($questions, static function (array $left, array $right): int {
        return $left['number'] <=> $right['number'];
    });

    $data['questions'] = $questions;
    $data['questionCount'] = count($questions);
    return $data;
}

require_once __DIR__ . '/platform.php';
