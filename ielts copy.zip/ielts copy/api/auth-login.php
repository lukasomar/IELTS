<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$input = ieltslab_read_json_request();

$email = ieltslab_normalize_email((string) ($input['email'] ?? ''));
$password = (string) ($input['password'] ?? '');

$user = ieltslab_find_user_by_email($email);
if (!$user || !password_verify($password, (string) ($user['passwordHash'] ?? ''))) {
    ieltslab_fail('Invalid email or password.', 401);
}

$user['lastLoginAt'] = time();
$user = ieltslab_save_user($user);
ieltslab_create_session($user);
ieltslab_record_event('auth.login', [], $user);

ieltslab_json_response([
    'success' => true,
    'user' => ieltslab_public_user($user),
]);