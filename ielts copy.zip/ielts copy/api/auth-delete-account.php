<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();
$password = (string) ($input['password'] ?? '');

if (!password_verify($password, (string) ($user['passwordHash'] ?? ''))) {
    ieltslab_fail('Password confirmation failed.', 400);
}

ieltslab_record_event('auth.delete_account', [], $user);
ieltslab_destroy_current_session();
ieltslab_delete_user((string) $user['id']);

ieltslab_json_response(['success' => true]);