<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();

$targetBand = (string) ($input['targetBand'] ?? '6.5');
$sessionId = ieltslab_generate_session_id();
$startedAt = time();
$session = [
    'sessionId' => $sessionId,
    'userId' => $user['id'],
    'targetBand' => $targetBand,
    'status' => 'active',
    'createdAt' => $startedAt,
    'sections' => [
        ['key' => 'listening', 'status' => 'ready', 'durationMinutes' => 30, 'answers' => []],
        ['key' => 'reading', 'status' => 'locked', 'durationMinutes' => 60, 'answers' => []],
        ['key' => 'writing', 'status' => 'locked', 'durationMinutes' => 60, 'answers' => []],
        ['key' => 'speaking', 'status' => 'locked', 'durationMinutes' => 15, 'answers' => []],
    ],
];

ieltslab_write_json_file(ieltslab_data_path('exams', $sessionId . '.json'), $session);
$user['progress']['sessions'] = (int) ($user['progress']['sessions'] ?? 0) + 1;
$user = ieltslab_save_user($user);
ieltslab_record_event('exam.start', ['sessionId' => $sessionId], $user);

ieltslab_json_response(['success' => true, 'session' => $session]);