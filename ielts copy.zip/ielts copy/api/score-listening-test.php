<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$input = ieltslab_read_json_request();
$sessionId = trim((string) ($input['sessionId'] ?? ''));
$answers = isset($input['answers']) && is_array($input['answers']) ? $input['answers'] : [];

if ($sessionId === '') {
    ieltslab_fail('sessionId is required.', 400);
}

$session = ieltslab_load_test_session($sessionId);
$questionResults = [];
$rawScore = 0;
$correctBySection = [];
$wrongByType = [];

foreach ($session['questions'] as $question) {
    $number = (string) $question['number'];
    $userAnswer = trim((string) ($answers[$number] ?? ''));
    $normalizedUser = ieltslab_normalize_answer($userAnswer);
    $accepted = array_map('ieltslab_normalize_answer', $question['acceptedAnswers']);
    $isCorrect = $normalizedUser !== '' && in_array($normalizedUser, $accepted, true);

    if ($isCorrect) {
        $rawScore++;
        $sectionKey = (string) $question['sectionNumber'];
        $correctBySection[$sectionKey] = ($correctBySection[$sectionKey] ?? 0) + 1;
    } else {
        $typeKey = (string) $question['type'];
        $wrongByType[$typeKey] = ($wrongByType[$typeKey] ?? 0) + 1;
    }

    $questionResults[] = [
        'number' => $question['number'],
        'prompt' => $question['prompt'],
        'userAnswer' => $userAnswer,
        'isCorrect' => $isCorrect,
        'canonicalAnswer' => $question['canonicalAnswer'],
        'explanation' => $question['explanation'],
    ];
}

arsort($correctBySection);
arsort($wrongByType);

$band = ieltslab_listening_band_from_raw($rawScore);
$totalQuestions = (int) ($session['questionCount'] ?? count($session['questions']));

ieltslab_json_response([
    'success' => true,
    'result' => [
        'rawScore' => $rawScore,
        'totalQuestions' => $totalQuestions,
        'correctCount' => $rawScore,
        'incorrectCount' => max(0, $totalQuestions - $rawScore),
        'bandScore' => $band,
        'strongestSection' => key($correctBySection) ?: null,
        'weakestQuestionType' => key($wrongByType) ?: null,
        'questionResults' => $questionResults,
    ],
]);
