<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    ieltslab_json_response(['success' => true, 'tests' => ieltslab_list_managed_tests()]);
}

ieltslab_require_post();
$input = ieltslab_read_json_request();
$action = trim((string) ($input['action'] ?? 'save'));

if ($action === 'delete') {
    $testId = trim((string) ($input['id'] ?? ''));
    if ($testId === '') {
        ieltslab_fail('Test id is required.', 400);
    }

    ieltslab_delete_managed_test($testId);
    ieltslab_record_event('admin.test_delete', ['testId' => $testId], $admin);
    ieltslab_json_response(['success' => true]);
}

$test = ieltslab_save_managed_test([
    'id' => $input['id'] ?? null,
    'title' => $input['title'] ?? '',
    'section' => $input['section'] ?? 'reading',
    'description' => $input['description'] ?? '',
    'durationMinutes' => $input['durationMinutes'] ?? 60,
    'attemptLimit' => $input['attemptLimit'] ?? 3,
    'premium' => $input['premium'] ?? false,
    'status' => $input['status'] ?? 'draft',
    'questions' => is_array($input['questions'] ?? null) ? $input['questions'] : [],
    'createdAt' => $input['createdAt'] ?? time(),
]);

ieltslab_record_event('admin.test_save', ['testId' => $test['id']], $admin);
ieltslab_json_response(['success' => true, 'test' => $test]);
