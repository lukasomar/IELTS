<?php

declare(strict_types=1);

function ieltslab_root_path(string $path = ''): string
{
    $root = dirname(__DIR__);
    return $path === '' ? $root : $root . '/' . ltrim($path, '/');
}

function ieltslab_public_upload_dir(): string
{
    return ieltslab_setting('UPLOADS_PUBLIC_DIR', 'user-content') ?? 'user-content';
}

function ieltslab_data_path(string $type, string $fileName = ''): string
{
    $base = ieltslab_storage_path($type);
    return $fileName === '' ? $base : $base . '/' . ltrim($fileName, '/');
}

function ieltslab_ensure_platform_storage(): void
{
    ieltslab_ensure_storage();
    foreach (['users', 'users/index', 'sessions', 'password-resets', 'email-verifications', 'outbox', 'analytics', 'writing', 'reading', 'exams', 'billing', 'content', 'managed-tests', 'submissions', 'settings'] as $folder) {
        $path = ieltslab_data_path($folder);
        if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
            ieltslab_fail('Failed to prepare storage at ' . $path . '.', 500);
        }
    }

    $uploadPath = ieltslab_root_path(ieltslab_public_upload_dir());
    if (!is_dir($uploadPath) && !mkdir($uploadPath, 0775, true) && !is_dir($uploadPath)) {
        ieltslab_fail('Failed to prepare uploads folder at ' . $uploadPath . '.', 500);
    }
}

function ieltslab_read_json_file(string $path, $default = [])
{
    if (!is_file($path)) {
        return $default;
    }

    $decoded = json_decode((string) file_get_contents($path), true);
    return $decoded === null ? $default : $decoded;
}

function ieltslab_write_json_file(string $path, $data): void
{
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        ieltslab_fail('Failed to prepare directory ' . $dir . '.', 500);
    }

    $temp = $path . '.tmp';
    file_put_contents($temp, json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    rename($temp, $path);
}

function ieltslab_append_line(string $path, array $data): void
{
    $dir = dirname($path);
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        ieltslab_fail('Failed to prepare directory ' . $dir . '.', 500);
    }

    file_put_contents($path, json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . PHP_EOL, FILE_APPEND);
}

function ieltslab_generate_token(int $bytes = 24): string
{
    return bin2hex(random_bytes($bytes));
}

function ieltslab_default_progress(): array
{
    return [
        'overallBand' => null,
        'sessions' => 0,
        'minutesToday' => 0,
        'streak' => 0,
        'skills' => [
            'writing' => ['band' => null, 'status' => 'Not started'],
            'reading' => ['band' => null, 'status' => 'Not started'],
            'listening' => ['band' => null, 'status' => 'Not started'],
            'speaking' => ['band' => null, 'status' => 'Not started'],
        ],
    ];
}

function ieltslab_default_settings(): array
{
    return [
        'focusSound' => 'Rain',
        'theme' => 'light',
        'dailyReminder' => true,
        'timezone' => 'UTC',
    ];
}

function ieltslab_user_index_path(): string
{
    return ieltslab_data_path('users/index', 'emails.json');
}

function ieltslab_user_path(string $userId): string
{
    return ieltslab_data_path('users', $userId . '.json');
}

function ieltslab_normalize_email(string $email): string
{
    return mb_strtolower(trim($email), 'UTF-8');
}

function ieltslab_list_user_ids(): array
{
    ieltslab_ensure_platform_storage();
    $index = ieltslab_read_json_file(ieltslab_user_index_path(), []);
    return is_array($index) ? array_values(array_unique(array_filter(array_map('strval', $index)))) : [];
}

function ieltslab_load_user_by_id(string $userId): ?array
{
    $user = ieltslab_read_json_file(ieltslab_user_path($userId), null);
    return is_array($user) ? $user : null;
}

function ieltslab_find_user_by_email(string $email): ?array
{
    ieltslab_ensure_platform_storage();
    $index = ieltslab_read_json_file(ieltslab_user_index_path(), []);
    $email = ieltslab_normalize_email($email);
    if (!is_array($index) || !isset($index[$email])) {
        return null;
    }

    return ieltslab_load_user_by_id((string) $index[$email]);
}

function ieltslab_public_user(array $user): array
{
    return [
        'id' => (string) ($user['id'] ?? ''),
        'name' => (string) ($user['name'] ?? ''),
        'email' => (string) ($user['email'] ?? ''),
        'role' => (string) ($user['role'] ?? 'student'),
        'plan' => (string) ($user['plan'] ?? 'Free'),
        'goalBand' => (float) ($user['goalBand'] ?? 7),
        'studyGoalMinutes' => (int) ($user['studyGoalMinutes'] ?? 30),
        'joinedAt' => (int) ($user['joinedAt'] ?? time()),
        'emailVerified' => (bool) ($user['emailVerified'] ?? false),
        'avatarUrl' => (string) ($user['avatarUrl'] ?? ''),
        'settings' => array_merge(ieltslab_default_settings(), is_array($user['settings'] ?? null) ? $user['settings'] : []),
        'progress' => array_merge(ieltslab_default_progress(), is_array($user['progress'] ?? null) ? $user['progress'] : []),
        'subscription' => is_array($user['subscription'] ?? null) ? $user['subscription'] : [
            'status' => 'active',
            'provider' => 'manual',
            'startedAt' => (int) ($user['joinedAt'] ?? time()),
        ],
    ];
}

function ieltslab_allowed_roles(): array
{
    return ['student', 'instructor', 'admin'];
}

function ieltslab_save_user(array $user): array
{
    ieltslab_ensure_platform_storage();
    $user['id'] = (string) ($user['id'] ?? ieltslab_generate_session_id());
    $user['email'] = ieltslab_normalize_email((string) ($user['email'] ?? ''));
    $user['settings'] = array_merge(ieltslab_default_settings(), is_array($user['settings'] ?? null) ? $user['settings'] : []);
    $user['progress'] = array_replace_recursive(ieltslab_default_progress(), is_array($user['progress'] ?? null) ? $user['progress'] : []);
    $user['role'] = (string) ($user['role'] ?? 'student');
    $user['plan'] = (string) ($user['plan'] ?? 'Free');
    $user['goalBand'] = (float) ($user['goalBand'] ?? 7);
    $user['studyGoalMinutes'] = (int) ($user['studyGoalMinutes'] ?? 30);
    $user['joinedAt'] = (int) ($user['joinedAt'] ?? time());
    $user['subscription'] = is_array($user['subscription'] ?? null) ? $user['subscription'] : [
        'status' => 'active',
        'provider' => 'manual',
        'startedAt' => $user['joinedAt'],
    ];

    ieltslab_write_json_file(ieltslab_user_path($user['id']), $user);

    $index = ieltslab_read_json_file(ieltslab_user_index_path(), []);
    if (!is_array($index)) {
        $index = [];
    }
    $index[$user['email']] = $user['id'];
    ieltslab_write_json_file(ieltslab_user_index_path(), $index);

    return $user;
}

function ieltslab_delete_user(string $userId): void
{
    $user = ieltslab_load_user_by_id($userId);
    if (!$user) {
        return;
    }

    $index = ieltslab_read_json_file(ieltslab_user_index_path(), []);
    if (is_array($index)) {
        unset($index[(string) ($user['email'] ?? '')]);
        ieltslab_write_json_file(ieltslab_user_index_path(), $index);
    }

    $path = ieltslab_user_path($userId);
    if (is_file($path)) {
        unlink($path);
    }
}

function ieltslab_seed_admin_if_needed(): void
{
    ieltslab_ensure_platform_storage();
    $adminEmail = ieltslab_normalize_email((string) (ieltslab_setting('ADMIN_EMAIL', 'admin@ieltslab.local') ?? 'admin@ieltslab.local'));
    $adminPassword = (string) (ieltslab_setting('ADMIN_PASSWORD', 'ChangeMe123!') ?? 'ChangeMe123!');
    $existing = ieltslab_find_user_by_email($adminEmail);
    if ($existing) {
        return;
    }

    $userIds = ieltslab_list_user_ids();
    if (count($userIds) > 0 && ieltslab_setting('SEED_DEFAULT_ADMIN', '1') !== '1') {
        return;
    }

    ieltslab_save_user([
        'name' => (string) (ieltslab_setting('ADMIN_NAME', 'IELTSLab Admin') ?? 'IELTSLab Admin'),
        'email' => $adminEmail,
        'passwordHash' => password_hash($adminPassword, PASSWORD_DEFAULT),
        'role' => 'admin',
        'plan' => 'Pro',
        'goalBand' => 8,
        'studyGoalMinutes' => 45,
        'joinedAt' => time(),
        'emailVerified' => true,
        'settings' => ieltslab_default_settings(),
        'progress' => ieltslab_default_progress(),
        'subscription' => [
            'status' => 'active',
            'provider' => 'manual',
            'startedAt' => time(),
        ],
    ]);
}

function ieltslab_session_cookie_name(): string
{
    return ieltslab_setting('SESSION_COOKIE_NAME', 'ieltslab_session') ?? 'ieltslab_session';
}

function ieltslab_cookie_is_secure(): bool
{
    if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') {
        return true;
    }
    return (ieltslab_setting('COOKIE_SECURE', '0') ?? '0') === '1';
}

function ieltslab_session_path(string $token): string
{
    return ieltslab_data_path('sessions', $token . '.json');
}

function ieltslab_set_session_cookie(string $token, int $expiresAt): void
{
    setcookie(ieltslab_session_cookie_name(), $token, [
        'expires' => $expiresAt,
        'path' => '/',
        'httponly' => true,
        'secure' => ieltslab_cookie_is_secure(),
        'samesite' => 'Lax',
    ]);
}

function ieltslab_create_session(array $user): string
{
    ieltslab_ensure_platform_storage();
    $token = ieltslab_generate_token(24);
    $ttlDays = max(1, (int) (ieltslab_setting('SESSION_TTL_DAYS', '30') ?? '30'));
    $expiresAt = time() + ($ttlDays * 86400);
    ieltslab_write_json_file(ieltslab_session_path($token), [
        'token' => $token,
        'userId' => (string) $user['id'],
        'createdAt' => time(),
        'expiresAt' => $expiresAt,
    ]);
    ieltslab_set_session_cookie($token, $expiresAt);
    return $token;
}

function ieltslab_destroy_current_session(): void
{
    $token = (string) ($_COOKIE[ieltslab_session_cookie_name()] ?? '');
    if ($token !== '') {
        $path = ieltslab_session_path($token);
        if (is_file($path)) {
            unlink($path);
        }
    }

    setcookie(ieltslab_session_cookie_name(), '', [
        'expires' => time() - 3600,
        'path' => '/',
        'httponly' => true,
        'secure' => ieltslab_cookie_is_secure(),
        'samesite' => 'Lax',
    ]);
}

function ieltslab_current_user(): ?array
{
    ieltslab_seed_admin_if_needed();
    $token = (string) ($_COOKIE[ieltslab_session_cookie_name()] ?? '');
    if ($token === '') {
        return null;
    }

    $session = ieltslab_read_json_file(ieltslab_session_path($token), null);
    if (!is_array($session)) {
        return null;
    }

    if ((int) ($session['expiresAt'] ?? 0) < time()) {
        $path = ieltslab_session_path($token);
        if (is_file($path)) {
            unlink($path);
        }
        return null;
    }

    return ieltslab_load_user_by_id((string) ($session['userId'] ?? ''));
}

function ieltslab_require_auth(): array
{
    $user = ieltslab_current_user();
    if (!$user) {
        ieltslab_fail('Authentication required.', 401);
    }
    return $user;
}

function ieltslab_require_admin(): array
{
    $user = ieltslab_require_auth();
    if (($user['role'] ?? 'student') !== 'admin') {
        ieltslab_fail('Admin access required.', 403);
    }
    return $user;
}

function ieltslab_record_event(string $type, array $payload = [], ?array $user = null): void
{
    ieltslab_ensure_platform_storage();
    ieltslab_append_line(ieltslab_data_path('analytics', 'events.jsonl'), [
        'type' => $type,
        'payload' => $payload,
        'userId' => $user['id'] ?? null,
        'email' => $user['email'] ?? null,
        'at' => time(),
        'ip' => (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
    ]);
}

function ieltslab_issue_token(string $folder, array $user, int $ttlSeconds, array $extra = []): array
{
    $token = ieltslab_generate_token(20);
    $record = array_merge($extra, [
        'token' => $token,
        'userId' => (string) $user['id'],
        'email' => (string) $user['email'],
        'createdAt' => time(),
        'expiresAt' => time() + $ttlSeconds,
    ]);
    ieltslab_write_json_file(ieltslab_data_path($folder, $token . '.json'), $record);
    return $record;
}

function ieltslab_consume_token(string $folder, string $token): array
{
    $path = ieltslab_data_path($folder, $token . '.json');
    $record = ieltslab_read_json_file($path, null);
    if (!is_array($record)) {
        ieltslab_fail('Invalid or expired token.', 400);
    }
    if ((int) ($record['expiresAt'] ?? 0) < time()) {
        if (is_file($path)) {
            unlink($path);
        }
        ieltslab_fail('The token has expired.', 400);
    }
    if (is_file($path)) {
        unlink($path);
    }
    return $record;
}

function ieltslab_outbox_message(string $type, array $user, array $record): void
{
    $baseUrl = rtrim((string) (ieltslab_setting('APP_URL', '') ?? ''), '/');
    $path = $type === 'verify'
        ? '/api/auth-verify-email.php?token=' . rawurlencode((string) $record['token'])
        : '/api/auth-reset-password.php?token=' . rawurlencode((string) $record['token']);
    $link = $baseUrl !== '' ? $baseUrl . $path : $path;

    ieltslab_write_json_file(ieltslab_data_path('outbox', time() . '-' . $type . '-' . ($user['id'] ?? 'user') . '.json'), [
        'type' => $type,
        'email' => $user['email'] ?? '',
        'token' => $record['token'] ?? '',
        'link' => $link,
        'createdAt' => time(),
    ]);
}

function ieltslab_list_outbox(): array
{
    $dir = ieltslab_data_path('outbox');
    $files = glob($dir . '/*.json') ?: [];
    rsort($files);
    return array_values(array_filter(array_map(static function (string $file): ?array {
        $item = ieltslab_read_json_file($file, null);
        return is_array($item) ? $item : null;
    }, array_slice($files, 0, 25))));
}

function ieltslab_recursive_files(string $directory, string $prefix = ''): array
{
    if (!is_dir($directory)) {
        return [];
    }

    $result = [];
    $items = scandir($directory) ?: [];
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }

        $fullPath = $directory . '/' . $item;
        $relative = ltrim($prefix . '/' . $item, '/');
        if (is_dir($fullPath)) {
            $result = array_merge($result, ieltslab_recursive_files($fullPath, $relative));
            continue;
        }

        $result[] = str_replace('\\', '/', $relative);
    }

    return $result;
}

function ieltslab_content_metadata_path(): string
{
    return ieltslab_data_path('content', 'metadata.json');
}

function ieltslab_content_metadata(): array
{
    $meta = ieltslab_read_json_file(ieltslab_content_metadata_path(), []);
    return is_array($meta) ? $meta : [];
}

function ieltslab_save_content_metadata(array $meta): void
{
    ieltslab_write_json_file(ieltslab_content_metadata_path(), $meta);
}

function ieltslab_catalog_payload(): array
{
    $pathData = ieltslab_read_json_file(ieltslab_root_path('path.json'), ['root' => '.', 'totalCount' => 0, 'paths' => []]);
    $paths = is_array($pathData['paths'] ?? null) ? $pathData['paths'] : [];
    $uploadDirName = ieltslab_public_upload_dir();
    $uploadFiles = ieltslab_recursive_files(ieltslab_root_path($uploadDirName), $uploadDirName);
    $meta = ieltslab_content_metadata();

    foreach ($uploadFiles as $file) {
        if (!in_array($file, $paths, true)) {
            $paths[] = $file;
        }
    }

    $visible = array_values(array_filter($paths, static function (string $path) use ($meta): bool {
        return !(bool) ($meta[$path]['hidden'] ?? false);
    }));

    sort($visible);

    return [
        'root' => '.',
        'totalCount' => count($visible),
        'paths' => $visible,
        'meta' => $meta,
    ];
}

function ieltslab_admin_resources(): array
{
    $catalog = ieltslab_catalog_payload();
    $meta = is_array($catalog['meta'] ?? null) ? $catalog['meta'] : [];
    $resources = [];
    foreach (($catalog['paths'] ?? []) as $path) {
        $resources[] = [
            'path' => $path,
            'meta' => $meta[$path] ?? [],
        ];
    }
    return $resources;
}

function ieltslab_save_uploaded_resource(array $file, string $section): array
{
    $allowed = ['listening', 'reading', 'writing', 'speaking'];
    if (!in_array($section, $allowed, true)) {
        ieltslab_fail('Invalid resource section.', 400);
    }

    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        ieltslab_fail('Upload failed.', 400);
    }

    $tmp = (string) ($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        ieltslab_fail('Uploaded file is invalid.', 400);
    }

    $maxBytes = 32 * 1024 * 1024;
    if ((int) ($file['size'] ?? 0) <= 0 || (int) ($file['size'] ?? 0) > $maxBytes) {
        ieltslab_fail('Uploaded file must be between 1 byte and 32 MB.', 400);
    }

    $extension = strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION));
    $allowedExtensions = ['pdf', 'mp3', 'm4a', 'wav', 'mp4', 'webm', 'mov', 'jpg', 'jpeg', 'png'];
    if (!in_array($extension, $allowedExtensions, true)) {
        ieltslab_fail('Unsupported file type. Allowed: PDF, audio, video, and common image formats.', 400);
    }

    $originalName = preg_replace('/[^A-Za-z0-9._-]+/', '-', (string) ($file['name'] ?? 'resource.bin')) ?? 'resource.bin';
    $targetDir = ieltslab_root_path(ieltslab_public_upload_dir() . '/' . $section);
    if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
        ieltslab_fail('Failed to prepare upload directory.', 500);
    }

    $targetName = time() . '-' . ltrim($originalName, '-');
    $targetPath = $targetDir . '/' . $targetName;
    if (!move_uploaded_file($tmp, $targetPath)) {
        ieltslab_fail('Failed to move uploaded file.', 500);
    }

    return [
        'path' => ieltslab_public_upload_dir() . '/' . $section . '/' . $targetName,
        'name' => $targetName,
    ];
}

function ieltslab_list_users_public(): array
{
    $users = [];
    foreach (ieltslab_list_user_ids() as $userId) {
        $user = ieltslab_load_user_by_id($userId);
        if ($user) {
            $users[] = ieltslab_public_user($user);
        }
    }

    usort($users, static function (array $left, array $right): int {
        return ($right['joinedAt'] ?? 0) <=> ($left['joinedAt'] ?? 0);
    });
    return $users;
}

function ieltslab_recent_events(int $limit = 50): array
{
    $eventsFile = ieltslab_data_path('analytics', 'events.jsonl');
    if (!is_file($eventsFile)) {
        return [];
    }

    $lines = file($eventsFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    $decoded = [];
    foreach (array_reverse($lines) as $line) {
        $item = json_decode((string) $line, true);
        if (is_array($item)) {
            $decoded[] = $item;
        }
        if (count($decoded) >= $limit) {
            break;
        }
    }

    return $decoded;
}

function ieltslab_managed_test_path(string $testId): string
{
    return ieltslab_data_path('managed-tests', $testId . '.json');
}

function ieltslab_list_managed_tests(): array
{
    $files = glob(ieltslab_data_path('managed-tests') . '/*.json') ?: [];
    rsort($files);
    $items = [];
    foreach ($files as $file) {
        $item = ieltslab_read_json_file($file, null);
        if (is_array($item)) {
            $items[] = $item;
        }
    }
    return $items;
}

function ieltslab_save_managed_test(array $test): array
{
    $test['id'] = (string) ($test['id'] ?? ieltslab_generate_session_id());
    $test['title'] = trim((string) ($test['title'] ?? 'Untitled Test'));
    $test['section'] = trim((string) ($test['section'] ?? 'reading'));
    $test['description'] = trim((string) ($test['description'] ?? ''));
    $test['durationMinutes'] = max(5, min(180, (int) ($test['durationMinutes'] ?? 60)));
    $test['attemptLimit'] = max(1, min(20, (int) ($test['attemptLimit'] ?? 3)));
    $test['premium'] = (bool) ($test['premium'] ?? false);
    $test['status'] = trim((string) ($test['status'] ?? 'draft'));
    $test['questions'] = array_values(array_filter(is_array($test['questions'] ?? null) ? $test['questions'] : [], static function ($question): bool {
        return is_array($question);
    }));
    $test['updatedAt'] = time();
    $test['createdAt'] = (int) ($test['createdAt'] ?? time());

    ieltslab_write_json_file(ieltslab_managed_test_path($test['id']), $test);
    return $test;
}

function ieltslab_delete_managed_test(string $testId): void
{
    $path = ieltslab_managed_test_path($testId);
    if (is_file($path)) {
        unlink($path);
    }
}

function ieltslab_submission_path(string $submissionId): string
{
    return ieltslab_data_path('submissions', $submissionId . '.json');
}

function ieltslab_save_submission(array $submission): array
{
    $submission['id'] = (string) ($submission['id'] ?? ieltslab_generate_session_id());
    $submission['type'] = (string) ($submission['type'] ?? 'writing');
    $submission['status'] = (string) ($submission['status'] ?? 'pending_review');
    $submission['updatedAt'] = time();
    $submission['createdAt'] = (int) ($submission['createdAt'] ?? time());
    ieltslab_write_json_file(ieltslab_submission_path($submission['id']), $submission);
    return $submission;
}

function ieltslab_list_submissions(): array
{
    $files = glob(ieltslab_data_path('submissions') . '/*.json') ?: [];
    rsort($files);
    $items = [];
    foreach ($files as $file) {
        $item = ieltslab_read_json_file($file, null);
        if (is_array($item)) {
            $items[] = $item;
        }
    }
    return $items;
}

function ieltslab_plan_definitions_path(): string
{
    return ieltslab_data_path('billing', 'plans.json');
}

function ieltslab_default_plan_definitions(): array
{
    return [
        [
            'id' => 'free',
            'name' => 'Free',
            'price' => 0,
            'interval' => 'month',
            'enabled' => true,
            'features' => ['Library access', 'Basic progress tracking', 'Limited mock tests'],
            'updatedAt' => time(),
        ],
        [
            'id' => 'pro',
            'name' => 'Pro',
            'price' => 19,
            'interval' => 'month',
            'enabled' => true,
            'features' => ['Unlimited tests', 'Writing reviews', 'Speaking evaluations'],
            'updatedAt' => time(),
        ],
    ];
}

function ieltslab_load_plan_definitions(): array
{
    $plans = ieltslab_read_json_file(ieltslab_plan_definitions_path(), null);
    if (!is_array($plans) || $plans === []) {
        $plans = ieltslab_default_plan_definitions();
        ieltslab_write_json_file(ieltslab_plan_definitions_path(), $plans);
        return $plans;
    }

    $didRepair = false;
    foreach ($plans as &$plan) {
        if (!is_array($plan)) {
            continue;
        }

        $id = trim((string) ($plan['id'] ?? ''));
        if ($id === '') {
            $plan['id'] = ieltslab_generate_session_id();
            $didRepair = true;
        }
    }
    unset($plan);

    if ($didRepair) {
        ieltslab_write_json_file(ieltslab_plan_definitions_path(), $plans);
    }

    return $plans;
}

function ieltslab_save_plan_definitions(array $plans): array
{
    $normalized = array_values(array_filter(array_map(static function ($plan): ?array {
        if (!is_array($plan)) {
            return null;
        }

        $id = trim((string) ($plan['id'] ?? ''));
        if ($id === '') {
            $id = ieltslab_generate_session_id();
        }

        return [
            'id' => $id,
            'name' => trim((string) ($plan['name'] ?? 'Untitled Plan')),
            'price' => max(0, (float) ($plan['price'] ?? 0)),
            'interval' => trim((string) ($plan['interval'] ?? 'month')),
            'enabled' => (bool) ($plan['enabled'] ?? true),
            'features' => array_values(array_filter(array_map('strval', is_array($plan['features'] ?? null) ? $plan['features'] : []))),
            'updatedAt' => time(),
        ];
    }, $plans)));

    ieltslab_write_json_file(ieltslab_plan_definitions_path(), $normalized);
    return $normalized;
}

function ieltslab_platform_settings_path(): string
{
    return ieltslab_data_path('settings', 'platform.json');
}

/**
 * Make an HTTP POST with optional Basic-auth credentials.
 * Returns the decoded JSON response body as an array.
 */
function ieltslab_http_post(string $url, string $body, array $headers = [], string $basicAuth = ''): array
{
    if (!function_exists('curl_init')) {
        ieltslab_fail('The cURL extension is required for external HTTP calls.', 500);
    }

    $curl = curl_init($url);
    curl_setopt_array($curl, [
        CURLOPT_POST           => true,
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_POSTFIELDS     => $body,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 30,
        CURLOPT_SSL_VERIFYPEER => true,
    ]);

    if ($basicAuth !== '') {
        curl_setopt($curl, CURLOPT_USERPWD, $basicAuth);
    }

    $raw    = curl_exec($curl);
    $status = (int) curl_getinfo($curl, CURLINFO_RESPONSE_CODE);
    $error  = curl_error($curl);
    curl_close($curl);

    if ($raw === false || $error !== '') {
        ieltslab_fail('HTTP request failed: ' . $error, 502);
    }

    $decoded = json_decode((string) $raw, true);
    if (!is_array($decoded)) {
        ieltslab_fail('Unexpected response from external service (status ' . $status . ').', 502);
    }

    return $decoded;
}

function ieltslab_default_platform_settings(): array
{
    return [
        'platformName' => 'IELTSLab',
        'supportEmail' => 'support@ieltslab.local',
        'logoUrl' => '',
        'landingMedia' => [
            'hero' => [
                'mode' => 'image',
                'src' => '',
                'lightSrc' => '',
                'darkSrc' => '',
                'poster' => '',
                'alt' => 'IELTSLab dashboard preview',
            ],
            'listening' => [
                'mode' => 'image',
                'src' => '',
                'lightSrc' => '',
                'darkSrc' => '',
                'poster' => '',
                'alt' => 'IELTSLab listening preview',
            ],
            'reading' => [
                'mode' => 'image',
                'src' => '',
                'lightSrc' => '',
                'darkSrc' => '',
                'poster' => '',
                'alt' => 'IELTSLab reading preview',
            ],
            'writing' => [
                'mode' => 'image',
                'src' => '',
                'lightSrc' => '',
                'darkSrc' => '',
                'poster' => '',
                'alt' => 'IELTSLab writing preview',
            ],
            'speaking' => [
                'mode' => 'image',
                'src' => '',
                'lightSrc' => '',
                'darkSrc' => '',
                'poster' => '',
                'alt' => 'IELTSLab speaking preview',
            ],
        ],
        'brand' => [
            'primaryColor' => '#00bfa6',
            'accentColor' => '#47d9cd',
        ],
        'integrations' => [
            'aiServiceKey' => '',
            'paymentPublicKey' => '',
            'paymentSecretKey' => '',
            'paypal' => [
                'clientId' => '',
                'secretKey' => '',
                'mode' => 'sandbox',
            ],
        ],
    ];
}

function ieltslab_load_platform_settings(): array
{
    $stored = ieltslab_read_json_file(ieltslab_platform_settings_path(), null);
    if (!is_array($stored)) {
        $stored = ieltslab_default_platform_settings();
        ieltslab_write_json_file(ieltslab_platform_settings_path(), $stored);
        return $stored;
    }

    $merged = array_replace_recursive(ieltslab_default_platform_settings(), $stored);
    if ($merged !== $stored) {
        ieltslab_write_json_file(ieltslab_platform_settings_path(), $merged);
    }

    return $merged;
}

function ieltslab_save_platform_settings(array $settings): array
{
    $merged = array_replace_recursive(ieltslab_default_platform_settings(), $settings);
    ieltslab_write_json_file(ieltslab_platform_settings_path(), $merged);
    return $merged;
}

function ieltslab_save_brand_asset(array $file): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        ieltslab_fail('Logo upload failed.', 400);
    }

    $tmp = (string) ($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        ieltslab_fail('Invalid logo upload.', 400);
    }

    $extension = strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION));
    if (!in_array($extension, ['png', 'jpg', 'jpeg', 'svg', 'webp'], true)) {
        ieltslab_fail('Unsupported logo file type.', 400);
    }

    $targetDir = ieltslab_root_path(ieltslab_public_upload_dir() . '/branding');
    if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
        ieltslab_fail('Failed to prepare branding directory.', 500);
    }

    $targetName = 'logo-' . time() . '.' . $extension;
    $targetPath = $targetDir . '/' . $targetName;
    if (!move_uploaded_file($tmp, $targetPath)) {
        ieltslab_fail('Failed to store logo file.', 500);
    }

    return ieltslab_public_upload_dir() . '/branding/' . $targetName;
}

function ieltslab_save_landing_media_asset(array $file, string $slot, string $variant = 'media'): string
{
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        ieltslab_fail('Landing media upload failed.', 400);
    }

    $tmp = (string) ($file['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        ieltslab_fail('Invalid landing media upload.', 400);
    }

    $extension = strtolower(pathinfo((string) ($file['name'] ?? ''), PATHINFO_EXTENSION));
    $allowed = ['png', 'jpg', 'jpeg', 'svg', 'webp', 'gif', 'mp4', 'webm', 'mov', 'm4v'];
    if (!in_array($extension, $allowed, true)) {
        ieltslab_fail('Unsupported landing media file type.', 400);
    }

    $normalizedSlot = preg_replace('/[^a-z0-9_-]+/i', '-', strtolower($slot)) ?: 'media';
    $normalizedVariant = preg_replace('/[^a-z0-9_-]+/i', '-', strtolower($variant)) ?: 'asset';
    $targetDir = ieltslab_root_path(ieltslab_public_upload_dir() . '/landing-media');
    if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
        ieltslab_fail('Failed to prepare landing media directory.', 500);
    }

    $targetName = $normalizedSlot . '-' . $normalizedVariant . '-' . time() . '.' . $extension;
    $targetPath = $targetDir . '/' . $targetName;
    if (!move_uploaded_file($tmp, $targetPath)) {
        ieltslab_fail('Failed to store landing media file.', 500);
    }

    return ieltslab_public_upload_dir() . '/landing-media/' . $targetName;
}

function ieltslab_public_platform_settings(): array
{
    $settings = ieltslab_load_platform_settings();

    $paypal = is_array($settings['integrations']['paypal'] ?? null) ? $settings['integrations']['paypal'] : [];
    return [
        'platformName'   => $settings['platformName'] ?? 'IELTSLab',
        'supportEmail'   => $settings['supportEmail'] ?? '',
        'logoUrl'        => $settings['logoUrl'] ?? '',
        'brand'          => is_array($settings['brand'] ?? null) ? $settings['brand'] : [],
        'landingMedia'   => is_array($settings['landingMedia'] ?? null) ? $settings['landingMedia'] : [],
        'paypalClientId' => trim((string) ($paypal['clientId'] ?? '')),
        'paypalMode'     => in_array(trim((string) ($paypal['mode'] ?? 'sandbox')), ['sandbox', 'live'], true)
                            ? trim((string) ($paypal['mode'] ?? 'sandbox'))
                            : 'sandbox',
    ];
}

function ieltslab_generated_content_summary(): array
{
    $sections = ['tests', 'writing', 'reading', 'exams'];
    $summary = [];
    foreach ($sections as $section) {
        $files = glob(ieltslab_data_path($section) . '/*.json') ?: [];
        $summary[$section] = count($files);
    }
    return $summary;
}

function ieltslab_analytics_summary(): array
{
    $eventsFile = ieltslab_data_path('analytics', 'events.jsonl');
    $eventsByType = [];
    $eventCount = 0;
    if (is_file($eventsFile)) {
        $lines = file($eventsFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
        foreach ($lines as $line) {
            $decoded = json_decode((string) $line, true);
            if (!is_array($decoded)) {
                continue;
            }
            $eventCount++;
            $type = (string) ($decoded['type'] ?? 'unknown');
            $eventsByType[$type] = ($eventsByType[$type] ?? 0) + 1;
        }
    }

    $users = ieltslab_list_users_public();
    $proUsers = count(array_filter($users, static function (array $user): bool {
        return strtolower((string) ($user['plan'] ?? 'free')) === 'pro';
    }));

    return [
        'userCount' => count($users),
        'adminCount' => count(array_filter($users, static fn(array $user): bool => ($user['role'] ?? 'student') === 'admin')),
        'proUserCount' => $proUsers,
        'resourceCount' => (int) (ieltslab_catalog_payload()['totalCount'] ?? 0),
        'eventCount' => $eventCount,
        'eventsByType' => $eventsByType,
        'generatedContent' => ieltslab_generated_content_summary(),
    ];
}

ieltslab_seed_admin_if_needed();