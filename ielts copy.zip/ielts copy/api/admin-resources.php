<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    ieltslab_json_response(['success' => true, 'resources' => ieltslab_admin_resources()]);
}

ieltslab_require_post();
$input = ieltslab_read_json_request();
$action = trim((string) ($input['action'] ?? 'update'));
$path = trim((string) ($input['path'] ?? ''));
if ($path === '') {
    ieltslab_fail('Resource path is required.', 400);
}

$meta = ieltslab_content_metadata();
$current = is_array($meta[$path] ?? null) ? $meta[$path] : [];

if ($action === 'delete') {
    $isUploaded = str_starts_with($path, ieltslab_public_upload_dir() . '/');
    if ($isUploaded) {
        $fullPath = ieltslab_root_path($path);
        if (is_file($fullPath)) {
            unlink($fullPath);
        }
        unset($meta[$path]);
    } else {
        $meta[$path] = array_merge($current, ['hidden' => true, 'deletedAt' => time()]);
    }

    ieltslab_save_content_metadata($meta);
    ieltslab_record_event('admin.resource_delete', ['path' => $path], $admin);
    ieltslab_json_response(['success' => true]);
}

$meta[$path] = array_merge($current, [
    'title' => trim((string) ($input['title'] ?? ($current['title'] ?? ''))),
    'section' => trim((string) ($input['section'] ?? ($current['section'] ?? ''))),
    'description' => trim((string) ($input['description'] ?? ($current['description'] ?? $current['notes'] ?? ''))),
    'notes' => trim((string) ($input['notes'] ?? ($current['notes'] ?? ''))),
    'hidden' => (bool) ($input['hidden'] ?? ($current['hidden'] ?? false)),
    'premium' => (bool) ($input['premium'] ?? ($current['premium'] ?? false)),
    'updatedAt' => time(),
]);
ieltslab_save_content_metadata($meta);
ieltslab_record_event('admin.resource_update', ['path' => $path], $admin);

ieltslab_json_response(['success' => true, 'meta' => $meta[$path]]);