<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$sessionId = trim((string) ($_GET['sessionId'] ?? ''));
if ($sessionId === '') {
    http_response_code(400);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'sessionId is required.';
    exit;
}

$wavPath = ieltslab_storage_path('audio', $sessionId . '.wav');
$mp3Path = ieltslab_storage_path('audio', $sessionId . '.mp3');

if (is_file($wavPath)) {
    $path = $wavPath;
    $contentType = 'audio/wav';
} elseif (is_file($mp3Path)) {
    $path = $mp3Path;
    $contentType = 'audio/mpeg';
} else {
    http_response_code(404);
    header('Content-Type: text/plain; charset=utf-8');
    echo 'Audio file not found.';
    exit;
}

header('Content-Type: ' . $contentType);
header('Content-Length: ' . (string) filesize($path));
header('Cache-Control: private, max-age=3600');
readfile($path);
exit;
