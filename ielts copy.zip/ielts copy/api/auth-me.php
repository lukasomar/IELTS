<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$user = ieltslab_current_user();
ieltslab_json_response([
    'success' => true,
    'user' => $user ? ieltslab_public_user($user) : null,
]);