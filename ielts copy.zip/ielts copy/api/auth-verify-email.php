<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    $token = trim((string) ($_GET['token'] ?? ''));
} else {
    ieltslab_require_post();
    $input = ieltslab_read_json_request();
    $token = trim((string) ($input['token'] ?? ''));
}

if ($token === '') {
    ieltslab_fail('Verification token is required.', 400);
}

$record = ieltslab_consume_token('email-verifications', $token);
$user = ieltslab_load_user_by_id((string) ($record['userId'] ?? ''));
if (!$user) {
    ieltslab_fail('User not found for verification token.', 404);
}

$user['emailVerified'] = true;
$user = ieltslab_save_user($user);
ieltslab_record_event('auth.verify_email', [], $user);

ieltslab_json_response(['success' => true, 'message' => 'Email verified.', 'user' => ieltslab_public_user($user)]);