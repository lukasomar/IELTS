<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_current_user();
if ($user) {
    ieltslab_record_event('auth.logout', [], $user);
}
ieltslab_destroy_current_session();

ieltslab_json_response(['success' => true]);