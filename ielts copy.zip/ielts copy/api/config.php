<?php

declare(strict_types=1);

define('GEMINI_API_KEY', 'AIzaSyB2kOxgbs-cD-2LDWIYp0IcomuNKF2dPlA');
define('GEMINI_MODEL', 'gemini-2.5-flash-lite');
define('GEMINI_TTS_MODEL', 'gemini-2.5-flash-preview-tts');
define('GEMINI_TTS_VOICE', 'Kore');
define('GEMINI_SPEAKING_MODEL', 'gemini-2.5-flash-lite');
