<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();

if (!isset($_FILES['avatar']) || !is_array($_FILES['avatar'])) {
    ieltslab_fail('Avatar file is required.', 400);
}

$upload = $_FILES['avatar'];
if (($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    ieltslab_fail('Avatar upload failed.', 400);
}

$tmp = (string) ($upload['tmp_name'] ?? '');
if ($tmp === '' || !is_uploaded_file($tmp)) {
    ieltslab_fail('Invalid avatar upload.', 400);
}

$mime = mime_content_type($tmp) ?: 'application/octet-stream';
if (!in_array($mime, ['image/png', 'image/jpeg', 'image/webp', 'image/gif'], true)) {
    ieltslab_fail('Please upload a PNG, JPG, WEBP, or GIF image.', 400);
}

$extensionMap = ['image/png' => 'png', 'image/jpeg' => 'jpg', 'image/webp' => 'webp', 'image/gif' => 'gif'];
$extension = $extensionMap[$mime] ?? 'png';
$targetDir = ieltslab_root_path(ieltslab_public_upload_dir() . '/avatars');
if (!is_dir($targetDir) && !mkdir($targetDir, 0775, true) && !is_dir($targetDir)) {
    ieltslab_fail('Failed to prepare avatar directory.', 500);
}

$fileName = $user['id'] . '-' . time() . '.' . $extension;
$targetPath = $targetDir . '/' . $fileName;
if (!move_uploaded_file($tmp, $targetPath)) {
    ieltslab_fail('Failed to save avatar.', 500);
}

$user['avatarUrl'] = ieltslab_public_upload_dir() . '/avatars/' . $fileName;
$user = ieltslab_save_user($user);
ieltslab_record_event('profile.upload_avatar', [], $user);

ieltslab_json_response(['success' => true, 'user' => ieltslab_public_user($user)]);