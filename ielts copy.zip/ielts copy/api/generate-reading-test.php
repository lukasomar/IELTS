<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();

$targetBand = (string) ($input['targetBand'] ?? '6.5');
$questionCount = max(6, min(12, (int) ($input['questionCount'] ?? 8)));
$theme = trim((string) ($input['theme'] ?? 'academic article'));
$sessionId = ieltslab_generate_session_id();
$model = ieltslab_setting('GEMINI_MODEL', 'gemini-2.5-flash') ?? 'gemini-2.5-flash';

$schema = [
    'type' => 'object',
    'properties' => [
        'testTitle' => ['type' => 'string'],
        'passage' => ['type' => 'string'],
        'questions' => [
            'type' => 'array',
            'items' => [
                'type' => 'object',
                'properties' => [
                    'number' => ['type' => 'integer'],
                    'type' => ['type' => 'string'],
                    'typeLabel' => ['type' => 'string'],
                    'prompt' => ['type' => 'string'],
                    'options' => ['type' => 'array', 'items' => ['type' => 'string']],
                    'acceptedAnswers' => ['type' => 'array', 'items' => ['type' => 'string'], 'minItems' => 1],
                    'canonicalAnswer' => ['type' => 'string'],
                    'explanation' => ['type' => 'string'],
                ],
                'required' => ['number', 'type', 'typeLabel', 'prompt', 'options', 'acceptedAnswers', 'canonicalAnswer', 'explanation'],
            ],
            'minItems' => $questionCount,
        ],
    ],
    'required' => ['testTitle', 'passage', 'questions'],
];

$prompt = <<<PROMPT
Generate a mini IELTS reading test as valid JSON only.
Target band: {$targetBand}
Theme: {$theme}
Question count: {$questionCount}

Rules:
- Create one passage of 450 to 650 words.
- Use objective question types only: multiple_choice, true_false_not_given, short_answer.
- Each question must include acceptedAnswers.
- Keep the answer key fully consistent with the passage.
PROMPT;

$response = ieltslab_gemini_request($model, [
    'contents' => [[
        'role' => 'user',
        'parts' => [['text' => $prompt]],
    ]],
    'generationConfig' => [
        'responseMimeType' => 'application/json',
        'responseJsonSchema' => $schema,
        'temperature' => 0.8,
        'maxOutputTokens' => 4096,
    ],
]);

$content = ieltslab_gemini_text($response);
$decoded = json_decode($content, true);
if (!is_array($decoded)) {
    ieltslab_fail('The reading generation response was invalid JSON.', 502, ['providerBody' => $content]);
}

$decoded['sessionId'] = $sessionId;
$decoded['questionCount'] = count($decoded['questions'] ?? []);
$decoded['targetBand'] = $targetBand;
$decoded['theme'] = $theme;
$decoded['createdAt'] = time();
ieltslab_write_json_file(ieltslab_data_path('reading', $sessionId . '.json'), $decoded + ['userId' => $user['id']]);
ieltslab_record_event('reading.generate', ['sessionId' => $sessionId], $user);

ieltslab_json_response(['success' => true, 'session' => $decoded]);