<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$user = ieltslab_require_auth();
ieltslab_require_post();

$input   = ieltslab_read_json_request();
$orderId = trim((string) ($input['orderId'] ?? ''));
$planId  = trim((string) ($input['planId'] ?? ''));

if ($orderId === '' || $planId === '') {
    ieltslab_fail('orderId and planId are required.', 400);
}

// Load plan
$plans = ieltslab_load_plan_definitions();
$plan  = null;
foreach ($plans as $p) {
    if ((string) ($p['id'] ?? '') === $planId) {
        $plan = $p;
        break;
    }
}
if (!$plan) {
    ieltslab_fail('Plan not found.', 404);
}

// Load PayPal credentials
$settings  = ieltslab_load_platform_settings();
$paypal    = is_array($settings['integrations']['paypal'] ?? null)
    ? $settings['integrations']['paypal']
    : [];
$clientId  = trim((string) ($paypal['clientId'] ?? ''));
$secret    = trim((string) ($paypal['secretKey'] ?? ''));
$mode      = trim((string) ($paypal['mode'] ?? 'sandbox'));

if ($clientId === '' || $secret === '') {
    ieltslab_fail('PayPal is not configured.', 503);
}

$baseUrl = $mode === 'live'
    ? 'https://api-m.paypal.com'
    : 'https://api-m.sandbox.paypal.com';

// Get access token
$authResponse = ieltslab_http_post(
    $baseUrl . '/v1/oauth2/token',
    'grant_type=client_credentials',
    ['Content-Type: application/x-www-form-urlencoded'],
    $clientId . ':' . $secret
);

if (!isset($authResponse['access_token'])) {
    ieltslab_fail('PayPal authentication failed.', 502);
}

$accessToken = (string) $authResponse['access_token'];

// Capture the order
$captureResponse = ieltslab_http_post(
    $baseUrl . '/v2/checkout/orders/' . rawurlencode($orderId) . '/capture',
    '{}',
    [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $accessToken,
    ]
);

$captureStatus = (string) ($captureResponse['status'] ?? '');
if ($captureStatus !== 'COMPLETED') {
    ieltslab_fail('PayPal capture did not complete (status: ' . $captureStatus . ').', 402);
}

// Upgrade the user plan
$freshUser         = ieltslab_load_user_by_id((string) $user['id']);
if (!$freshUser) {
    ieltslab_fail('User not found.', 404);
}
$freshUser['plan'] = (string) ($plan['name'] ?? 'Pro');
$freshUser['subscription'] = [
    'status'    => 'active',
    'provider'  => 'paypal',
    'planId'    => $planId,
    'orderId'   => $orderId,
    'mode'      => $mode,
    'startedAt' => time(),
];
$freshUser = ieltslab_save_user($freshUser);

// Record billing history
$historyPath = ieltslab_data_path('billing', 'history.json');
$history     = ieltslab_read_json_file($historyPath, []);
if (!is_array($history)) {
    $history = [];
}
$history[] = [
    'id'        => $orderId,
    'userId'    => $user['id'],
    'userName'  => $user['name'] ?? '',
    'userEmail' => $user['email'] ?? '',
    'planId'    => $planId,
    'planName'  => $plan['name'] ?? '',
    'amount'    => (float) ($plan['price'] ?? 0),
    'currency'  => 'USD',
    'provider'  => 'paypal',
    'mode'      => $mode,
    'status'    => 'paid',
    'createdAt' => time(),
];
ieltslab_write_json_file($historyPath, $history);

ieltslab_record_event('payment.captured', [
    'orderId' => $orderId,
    'planId'  => $planId,
    'amount'  => $plan['price'] ?? 0,
], $freshUser);

ieltslab_json_response([
    'success' => true,
    'user'    => ieltslab_public_user($freshUser),
]);
