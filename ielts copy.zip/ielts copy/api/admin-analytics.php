<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();
ieltslab_record_event('admin.analytics_view', [], $admin);

ieltslab_json_response([
    'success' => true,
    'summary' => ieltslab_analytics_summary(),
    'recentEvents' => ieltslab_recent_events(40),
]);
