<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$input = ieltslab_read_json_request();

$name = trim((string) ($input['name'] ?? ''));
$email = ieltslab_normalize_email((string) ($input['email'] ?? ''));
$password = (string) ($input['password'] ?? '');

if ($name === '' || $email === '' || $password === '') {
    ieltslab_fail('Name, email, and password are required.', 400);
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    ieltslab_fail('Please enter a valid email address.', 400);
}

if (strlen($password) < 8) {
    ieltslab_fail('Password must be at least 8 characters.', 400);
}

if (ieltslab_find_user_by_email($email)) {
    ieltslab_fail('An account with that email already exists.', 409);
}

$userIds = ieltslab_list_user_ids();
$adminEmail = ieltslab_normalize_email((string) (ieltslab_setting('ADMIN_EMAIL', '') ?? ''));
$role = (count($userIds) === 0 || ($adminEmail !== '' && $adminEmail === $email)) ? 'admin' : 'student';

$user = ieltslab_save_user([
    'name' => $name,
    'email' => $email,
    'passwordHash' => password_hash($password, PASSWORD_DEFAULT),
    'role' => $role,
    'plan' => $role === 'admin' ? 'Pro' : 'Free',
    'goalBand' => 7,
    'studyGoalMinutes' => 30,
    'joinedAt' => time(),
    'emailVerified' => false,
]);

$record = ieltslab_issue_token('email-verifications', $user, 86400 * 3, ['type' => 'verify']);
ieltslab_outbox_message('verify', $user, $record);
ieltslab_create_session($user);
ieltslab_record_event('auth.signup', ['role' => $role], $user);

$response = [
    'success' => true,
    'user' => ieltslab_public_user($user),
    'message' => 'Account created successfully.',
];

if ((ieltslab_setting('APP_ENV', 'production') ?? 'production') !== 'production') {
    $response['verificationToken'] = $record['token'];
}

ieltslab_json_response($response, 201);