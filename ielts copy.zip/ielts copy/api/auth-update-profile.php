<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();
$input = ieltslab_read_json_request();

$user['name'] = trim((string) ($input['name'] ?? $user['name'] ?? ''));
$user['goalBand'] = max(4, min(9, (float) ($input['goalBand'] ?? $user['goalBand'] ?? 7)));
$user['studyGoalMinutes'] = max(10, min(240, (int) ($input['studyGoalMinutes'] ?? $user['studyGoalMinutes'] ?? 30)));
$user['settings'] = array_merge(
    is_array($user['settings'] ?? null) ? $user['settings'] : ieltslab_default_settings(),
    is_array($input['settings'] ?? null) ? $input['settings'] : []
);

if (isset($input['progress']) && is_array($input['progress'])) {
    $user['progress'] = array_replace_recursive(
        is_array($user['progress'] ?? null) ? $user['progress'] : ieltslab_default_progress(),
        $input['progress']
    );
}

$user = ieltslab_save_user($user);
ieltslab_record_event('profile.update', [], $user);

ieltslab_json_response([
    'success' => true,
    'user' => ieltslab_public_user($user),
]);