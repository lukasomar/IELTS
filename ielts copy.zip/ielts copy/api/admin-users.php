<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

$admin = ieltslab_require_admin();

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
    ieltslab_json_response(['success' => true, 'users' => ieltslab_list_users_public()]);
}

ieltslab_require_post();
$input = ieltslab_read_json_request();
$action = trim((string) ($input['action'] ?? 'update'));

if ($action === 'create') {
    $name = trim((string) ($input['name'] ?? ''));
    $email = ieltslab_normalize_email((string) ($input['email'] ?? ''));
    $password = (string) ($input['password'] ?? '');
    $role = trim((string) ($input['role'] ?? 'student'));
    $plan = trim((string) ($input['plan'] ?? 'Free'));

    if ($name === '' || $email === '' || $password === '') {
        ieltslab_fail('Name, email, and password are required.', 400);
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        ieltslab_fail('A valid email address is required.', 400);
    }
    if (strlen($password) < 8) {
        ieltslab_fail('Password must be at least 8 characters.', 400);
    }
    if (!in_array($role, ieltslab_allowed_roles(), true)) {
        ieltslab_fail('Invalid role selected.', 400);
    }
    if (!in_array($plan, ['Free', 'Pro'], true)) {
        ieltslab_fail('Invalid plan selected.', 400);
    }
    if (ieltslab_find_user_by_email($email)) {
        ieltslab_fail('A user with that email already exists.', 409);
    }

    $user = ieltslab_save_user([
        'name' => $name,
        'email' => $email,
        'passwordHash' => password_hash($password, PASSWORD_DEFAULT),
        'role' => $role,
        'plan' => $plan,
        'emailVerified' => (bool) ($input['emailVerified'] ?? false),
    ]);
    ieltslab_record_event('admin.user_create', ['targetUserId' => $user['id']], $admin);
    ieltslab_json_response(['success' => true, 'user' => ieltslab_public_user($user)], 201);
}

$targetUserId = (string) ($input['userId'] ?? '');
$target = ieltslab_load_user_by_id($targetUserId);
if (!$target) {
    ieltslab_fail('User not found.', 404);
}

if ($action === 'delete') {
    if ((string) ($target['id'] ?? '') === (string) ($admin['id'] ?? '')) {
        ieltslab_fail('You cannot delete your own admin account.', 400);
    }

    ieltslab_delete_user($targetUserId);
    ieltslab_record_event('admin.user_delete', ['targetUserId' => $targetUserId], $admin);
    ieltslab_json_response(['success' => true]);
}

if (isset($input['role']) && in_array($input['role'], ieltslab_allowed_roles(), true)) {
    $target['role'] = $input['role'];
}
if (isset($input['plan']) && in_array($input['plan'], ['Free', 'Pro'], true)) {
    $target['plan'] = $input['plan'];
}
if (isset($input['emailVerified'])) {
    $target['emailVerified'] = (bool) $input['emailVerified'];
}
if (isset($input['name'])) {
    $target['name'] = trim((string) $input['name']);
}

$target = ieltslab_save_user($target);
ieltslab_record_event('admin.user_update', ['targetUserId' => $target['id']], $admin);

ieltslab_json_response(['success' => true, 'user' => ieltslab_public_user($target)]);