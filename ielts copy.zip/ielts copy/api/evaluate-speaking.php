<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

ieltslab_require_post();
$user = ieltslab_require_auth();

$part = trim((string) ($_POST['part'] ?? 'Part 2'));
$prompt = trim((string) ($_POST['prompt'] ?? ''));
$targetBand = trim((string) ($_POST['targetBand'] ?? '7.0'));

if (!isset($_FILES['audio']) || !is_array($_FILES['audio'])) {
    ieltslab_fail('An audio upload is required.', 400);
}

$audio = $_FILES['audio'];
if (($audio['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    ieltslab_fail('The audio upload failed.', 400);
}

$tempFile = (string) ($audio['tmp_name'] ?? '');
$originalName = (string) ($audio['name'] ?? 'speech.webm');
if ($tempFile === '' || !is_uploaded_file($tempFile)) {
    ieltslab_fail('The uploaded audio file is invalid.', 400);
}

$analysisModel = ieltslab_setting('GEMINI_SPEAKING_MODEL', ieltslab_setting('GEMINI_MODEL', 'gemini-2.5-flash') ?? 'gemini-2.5-flash') ?? 'gemini-2.5-flash';
$mimeType = mime_content_type($tempFile) ?: ((string) ($audio['type'] ?? 'audio/webm'));
$audioBytes = (string) file_get_contents($tempFile);

if ($audioBytes === '') {
    ieltslab_fail('The uploaded audio file is empty.', 400);
}

if (strlen($audioBytes) > 18 * 1024 * 1024) {
    ieltslab_fail('The uploaded audio file is too large for inline Gemini processing. Keep it under 18 MB.', 400);
}

$responseSchema = [
    'type' => 'object',
    'properties' => [
        'transcript' => ['type' => 'string'],
        'overallBand' => ['type' => 'number'],
        'breakdown' => [
            'type' => 'object',
            'properties' => [
                'fluency' => ['type' => 'number'],
                'vocabulary' => ['type' => 'number'],
                'grammar' => ['type' => 'number'],
                'pronunciation' => ['type' => 'number'],
            ],
            'required' => ['fluency', 'vocabulary', 'grammar', 'pronunciation'],
        ],
        'summary' => ['type' => 'string'],
        'improvements' => ['type' => 'array', 'items' => ['type' => 'string'], 'minItems' => 3, 'maxItems' => 5],
        'correctedSample' => ['type' => 'string'],
    ],
    'required' => ['transcript', 'overallBand', 'breakdown', 'summary', 'improvements', 'correctedSample'],
];

$systemPrompt = <<<PROMPT
You are an IELTS speaking examiner.
Return only valid JSON.
First infer the spoken transcript from the uploaded audio, then evaluate the candidate using IELTS speaking criteria.
PROMPT;

$userPrompt = <<<PROMPT
Transcribe and evaluate this spoken IELTS response.
Return JSON with this exact shape:
{
  "transcript": "string",
  "overallBand": 0,
  "breakdown": {
    "fluency": 0,
    "vocabulary": 0,
    "grammar": 0,
    "pronunciation": 0
  },
  "summary": "string",
  "improvements": ["string"],
  "correctedSample": "string"
}

Context:
- speaking part: {$part}
- target band: {$targetBand}
- prompt: {$prompt}
- uploaded filename: {$originalName}

Rules:
- Bands must be numeric values between 0 and 9 and can use .5 increments.
- transcript must be the best faithful transcription of the audio.
- improvements should contain 3 to 5 concise actions.
- correctedSample should be a better spoken response in natural English.
- Do not include markdown fences or explanation outside JSON.
PROMPT;

$analysis = ieltslab_gemini_request($analysisModel, [
    'systemInstruction' => [
        'parts' => [
            ['text' => $systemPrompt],
        ],
    ],
    'contents' => [
        [
            'role' => 'user',
            'parts' => [
                [
                    'inlineData' => [
                        'mimeType' => $mimeType,
                        'data' => base64_encode($audioBytes),
                    ],
                ],
                ['text' => $userPrompt],
            ],
        ],
    ],
    'generationConfig' => [
        'responseMimeType' => 'application/json',
        'responseJsonSchema' => $responseSchema,
        'temperature' => 0.4,
        'maxOutputTokens' => 2048,
    ],
]);

$content = ieltslab_gemini_text($analysis);
if (!is_string($content) || trim($content) === '') {
    ieltslab_fail('The speaking analysis response was empty.', 502);
}

$decoded = json_decode($content, true);
if (!is_array($decoded)) {
    ieltslab_fail('The speaking analysis response was invalid JSON.', 502, ['providerBody' => $content]);
}

$result = [
    'attemptId' => ieltslab_generate_session_id(),
    'transcript' => (string) ($decoded['transcript'] ?? ''),
    'targetBand' => $targetBand,
    'overallBand' => isset($decoded['overallBand']) ? (float) $decoded['overallBand'] : null,
    'breakdown' => [
        'fluency' => isset($decoded['breakdown']['fluency']) ? (float) $decoded['breakdown']['fluency'] : null,
        'vocabulary' => isset($decoded['breakdown']['vocabulary']) ? (float) $decoded['breakdown']['vocabulary'] : null,
        'grammar' => isset($decoded['breakdown']['grammar']) ? (float) $decoded['breakdown']['grammar'] : null,
        'pronunciation' => isset($decoded['breakdown']['pronunciation']) ? (float) $decoded['breakdown']['pronunciation'] : null,
    ],
    'summary' => (string) ($decoded['summary'] ?? ''),
    'improvements' => array_values(array_filter(array_map('strval', $decoded['improvements'] ?? []))),
    'correctedSample' => (string) ($decoded['correctedSample'] ?? ''),
    'part' => $part,
    'prompt' => $prompt,
    'createdAt' => time(),
];

$submission = ieltslab_save_submission([
    'id' => 'speaking-' . $result['attemptId'],
    'type' => 'speaking',
    'userId' => $user['id'],
    'userName' => $user['name'] ?? '',
    'status' => 'reviewed',
    'prompt' => $prompt,
    'part' => $part,
    'audioName' => $originalName,
    'assignedReviewerId' => null,
    'reviewBand' => $result['overallBand'],
    'reviewFeedback' => $result['summary'],
    'result' => $result,
]);

$user['progress']['skills']['speaking']['status'] = 'In progress';
$user['progress']['skills']['speaking']['band'] = (float) ($result['overallBand'] ?? 0);
$user['progress']['overallBand'] = (float) ($result['overallBand'] ?? ($user['progress']['overallBand'] ?? 0));
$user = ieltslab_save_user($user);
ieltslab_record_event('speaking.evaluate', ['attemptId' => $result['attemptId']], $user);

ieltslab_json_response([
    'success' => true,
    'result' => $result,
    'submission' => $submission,
]);
