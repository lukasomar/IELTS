<?php

declare(strict_types=1);

require_once dirname(__DIR__) . '/api/bootstrap.php';

$currentUser = ieltslab_current_user();
$isAdmin = $currentUser && (($currentUser['role'] ?? 'student') === 'admin');
$status = $isAdmin ? 'admin' : ($currentUser ? 'forbidden' : 'guest');

if ($status === 'forbidden') {
    http_response_code(403);
}

$bootstrap = [
    'status' => $status,
    'user' => $isAdmin ? ieltslab_public_user($currentUser) : null,
    'appUrl' => rtrim((string) (ieltslab_setting('APP_URL', '') ?? ''), '/'),
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IELTSLab Admin Dashboard</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Manrope:wght@400;500;600;700;800&family=Sora:wght@400;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="admin.css">
</head>
<body>
  <div id="admin-app"></div>
  <script>
    window.IELTSLabAdminBootstrap = <?php echo json_encode($bootstrap, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
  </script>
  <script src="admin-components.js"></script>
  <script src="admin-app.js"></script>
</body>
</html>
