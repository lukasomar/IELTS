(function () {
  function escape(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function badge(text, tone) {
    return '<span class="admin-badge admin-badge--' + escape(tone || 'neutral') + '">' + escape(text) + '</span>';
  }

  function statCard(label, value, helper) {
    return '<article class="admin-stat-card"><span class="admin-kicker">' + escape(label) + '</span><strong>' + escape(value) + '</strong><p>' + escape(helper || '') + '</p></article>';
  }

  function panel(title, body, extraClass) {
    return '<section class="admin-panel ' + escape(extraClass || '') + '"><div class="admin-panel__body"><h3>' + escape(title) + '</h3>' + body + '</div></section>';
  }

  function sectionHeader(title, description, actions) {
    return '<header class="admin-section-header"><div><span class="admin-kicker">Admin Section</span><h2>' + escape(title) + '</h2><p>' + escape(description || '') + '</p></div><div class="admin-section-header__actions">' + (actions || '') + '</div></header>';
  }

  function table(headers, rows) {
    return '<div class="admin-table-wrap"><table class="admin-table"><thead><tr>' + headers.map(function (header) {
      return '<th>' + escape(header) + '</th>';
    }).join('') + '</tr></thead><tbody>' + (rows.length ? rows.join('') : '<tr><td colspan="' + headers.length + '"><div class="admin-empty">No records found.</div></td></tr>') + '</tbody></table></div>';
  }

  function modal(title, body) {
    return '<div class="admin-modal-backdrop" data-action="close-modal"><div class="admin-modal" data-stop-click="true"><div class="admin-modal__header"><h3>' + escape(title) + '</h3><button type="button" class="admin-icon-button" data-action="close-modal">Close</button></div><div class="admin-modal__body">' + body + '</div></div></div>';
  }

  function option(value, label, selected) {
    return '<option value="' + escape(value) + '"' + (selected ? ' selected' : '') + '>' + escape(label) + '</option>';
  }

  window.IELTSLabAdminComponents = {
    escape: escape,
    badge: badge,
    statCard: statCard,
    panel: panel,
    sectionHeader: sectionHeader,
    table: table,
    modal: modal,
    option: option
  };
})();
