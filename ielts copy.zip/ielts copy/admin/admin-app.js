(function () {
  var ui = window.IELTSLabAdminComponents;
  var bootstrap = window.IELTSLabAdminBootstrap || { status: 'guest', user: null };
  var THEME_STORAGE_KEY = 'ieltslab-admin-theme';
  var sections = [
    { id: 'overview', label: 'Overview' },
    { id: 'users', label: 'Users' },
    { id: 'materials', label: 'Learning Materials' },
    { id: 'tests', label: 'Tests / Exams' },
    { id: 'submissions', label: 'Submissions' },
    { id: 'payments', label: 'Payments / Subscriptions' },
    { id: 'analytics', label: 'Analytics' },
    { id: 'settings', label: 'Settings' }
  ];

  var state = {
    bootStatus: bootstrap.status,
    user: bootstrap.user,
    theme: loadTheme(),
    activeSection: getInitialSection(),
    loading: false,
    authLoading: false,
    brandingLogoPendingName: '',
    error: '',
    message: '',
    modal: null,
    settingsAdvancedSlots: {},
    settingsUploadPreviews: {},
    data: {
      overview: null,
      users: null,
      materials: null,
      tests: null,
      submissions: null,
      payments: null,
      analytics: null,
      settings: null
    },
    filters: {
      usersSearch: '',
      usersRole: 'all',
      materialsSearch: '',
      materialsCategory: 'all',
      materialsAccess: 'all',
      testsSearch: '',
      testsSection: 'all',
      submissionsType: 'all',
      submissionsStatus: 'all'
    }
  };

  function getInitialSection() {
    var hash = String(window.location.hash || '').replace(/^#/, '');
    return sections.some(function (section) { return section.id === hash; }) ? hash : 'overview';
  }

  function apiPath(path) {
    return '../api/' + path;
  }

  async function request(path, options) {
    var response = await fetch(apiPath(path), Object.assign({
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json'
      }
    }, options || {}));
    var payload = await response.json().catch(function () {
      return { success: false, error: 'Invalid server response.' };
    });

    if (!response.ok || !payload.success) {
      throw new Error(payload.error || 'Request failed.');
    }

    return payload;
  }

  async function requestForm(path, formData) {
    var response = await fetch(apiPath(path), {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    });
    var payload = await response.json().catch(function () {
      return { success: false, error: 'Invalid server response.' };
    });

    if (!response.ok || !payload.success) {
      throw new Error(payload.error || 'Request failed.');
    }

    return payload;
  }

  function post(path, body) {
    return request(path, {
      method: 'POST',
      body: JSON.stringify(body || {})
    });
  }

  function bindEvents() {
    document.addEventListener('click', handleClick);
    document.addEventListener('submit', handleSubmit);
    document.addEventListener('input', handleInput);
    document.addEventListener('change', handleChange);
    window.addEventListener('hashchange', function () {
      var next = getInitialSection();
      if (next !== state.activeSection) {
        state.activeSection = next;
        loadActiveSection();
      }
    });
  }

  function handleInput(event) {
    var target = event.target;
    if (!target.matches('[data-filter]')) return;
    state.filters[target.getAttribute('data-filter')] = target.value;
    render();
  }

  function handleChange(event) {
    var target = event.target;
    if (target.matches('[data-branding-logo-input]')) {
      var logoFile = target.files && target.files[0];
      state.brandingLogoPendingName = logoFile ? (logoFile.name || '') : '';
      updateBrandingLogoUploadStatus();
      return;
    }

    if (!target.matches('[data-settings-media-input]')) return;

    var slot = target.getAttribute('data-slot') || '';
    var variant = target.getAttribute('data-variant') || 'media';
    var file = target.files && target.files[0];
    if (!slot) return;

    ensureSettingsUploadPreviewSlot(slot);

    if (state.settingsUploadPreviews[slot][variant] && state.settingsUploadPreviews[slot][variant].url) {
      try {
        window.URL.revokeObjectURL(state.settingsUploadPreviews[slot][variant].url);
      } catch (error) {
      }
    }

    if (!file) {
      state.settingsUploadPreviews[slot][variant] = null;
      updateLandingMediaUploadStatus(slot, variant);
      render();
      return;
    }

    state.settingsUploadPreviews[slot][variant] = {
      url: window.URL.createObjectURL(file),
      fileName: file.name,
      type: file.type || '',
      file: file
    };
    updateLandingMediaUploadStatus(slot, variant);
    updateLandingMediaPreview(slot);
  }

  function handleClick(event) {
    var stopBoundary = event.target.closest('[data-stop-click="true"]');
    if (stopBoundary) {
      event.stopPropagation();
    }

    var actionTarget = event.target.closest('[data-action]');
    if (!actionTarget) return;

    // Prevent clicks inside a stop-click boundary from triggering actions outside it
    if (stopBoundary && !stopBoundary.contains(actionTarget) && stopBoundary !== actionTarget) return;

    var action = actionTarget.getAttribute('data-action');

    if (action === 'switch-section') {
      state.activeSection = actionTarget.getAttribute('data-section') || 'overview';
      window.location.hash = state.activeSection;
      loadActiveSection();
      return;
    }

    if (action === 'close-modal') {
      state.modal = null;
      render();
      return;
    }

    if (action === 'toggle-theme') {
      toggleTheme();
      return;
    }

    if (action === 'toggle-password-visibility') {
      var wrap = actionTarget.closest('.admin-password-wrap');
      var pwdInput = wrap ? wrap.querySelector('input') : null;
      if (pwdInput) {
        var show = pwdInput.type === 'password';
        pwdInput.type = show ? 'text' : 'password';
        var label = actionTarget.querySelector('[data-pwd-label]');
        if (label) label.textContent = show ? 'Hide' : 'Show';
        actionTarget.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
        actionTarget.setAttribute('title', show ? 'Hide password' : 'Show password');
      }
      return;
    }

    if (action === 'toggle-landing-advanced') {
      var slot = actionTarget.getAttribute('data-slot') || '';
      if (!slot) return;
      state.settingsAdvancedSlots[slot] = !state.settingsAdvancedSlots[slot];
      render();
      return;
    }

    if (action === 'open-create-user') {
      state.modal = { type: 'user', payload: null };
      render();
      return;
    }

    if (action === 'edit-user') {
      state.modal = { type: 'user', payload: findById((state.data.users && state.data.users.users) || [], actionTarget.getAttribute('data-id')) };
      render();
      return;
    }

    if (action === 'delete-user') {
      confirmDeleteUser(actionTarget.getAttribute('data-id'));
      return;
    }

    if (action === 'edit-material') {
      state.modal = { type: 'material', payload: findByPath((state.data.materials && state.data.materials.resources) || [], decodeURIComponent(actionTarget.getAttribute('data-key') || '')) };
      render();
      return;
    }

    if (action === 'delete-material') {
      confirmDeleteMaterial(decodeURIComponent(actionTarget.getAttribute('data-key') || ''));
      return;
    }

    if (action === 'open-create-test') {
      state.modal = { type: 'test', payload: null };
      render();
      return;
    }

    if (action === 'edit-test') {
      state.modal = { type: 'test', payload: findById((state.data.tests && state.data.tests.tests) || [], actionTarget.getAttribute('data-id')) };
      render();
      return;
    }

    if (action === 'delete-test') {
      confirmDeleteTest(actionTarget.getAttribute('data-id'));
      return;
    }

    if (action === 'open-create-plan') {
      state.modal = { type: 'plan', payload: null };
      render();
      return;
    }

    if (action === 'edit-plan') {
      state.modal = { type: 'plan', payload: findById((state.data.payments && state.data.payments.plans) || [], actionTarget.getAttribute('data-id')) };
      render();
      return;
    }

    if (action === 'delete-plan') {
      confirmDeletePlan(actionTarget.getAttribute('data-id'));
      return;
    }

    if (action === 'review-submission') {
      state.modal = { type: 'submission', payload: findById((state.data.submissions && state.data.submissions.submissions) || [], actionTarget.getAttribute('data-id')) };
      render();
      return;
    }

    if (action === 'logout') {
      post('auth-logout.php', {}).finally(function () {
        window.location.reload();
      });
    }
  }

  async function handleSubmit(event) {
    var form = event.target;

    if (form.matches('[data-form="admin-login"]')) {
      event.preventDefault();
      state.authLoading = true;
      state.error = '';
      render();
      var loginData = new FormData(form);
      try {
        var login = await post('auth-login.php', {
          email: String(loginData.get('email') || '').trim(),
          password: String(loginData.get('password') || '')
        });
        if (!login.user || login.user.role !== 'admin') {
          await post('auth-logout.php', {});
          throw new Error('Admin access required.');
        }
        window.location.reload();
      } catch (error) {
        state.authLoading = false;
        state.error = error.message || 'Login failed.';
        render();
      }
      return;
    }

    if (form.matches('[data-form="user-modal"]')) {
      event.preventDefault();
      var userData = new FormData(form);
      await mutate(function () {
        return post('admin-users.php', {
          action: userData.get('action') || 'update',
          userId: userData.get('userId') || '',
          name: userData.get('name') || '',
          email: userData.get('email') || '',
          password: userData.get('password') || '',
          role: userData.get('role') || 'student',
          plan: userData.get('plan') || 'Free',
          emailVerified: userData.get('emailVerified') === 'true'
        });
      }, 'User saved.', 'Failed to save user.', 'users');
      return;
    }

    if (form.matches('[data-form="materials-upload"]')) {
      event.preventDefault();
      await mutate(function () {
        return requestForm('admin-resource-upload.php', new FormData(form));
      }, 'Material uploaded.', 'Failed to upload material.', 'materials', function () {
        form.reset();
      });
      return;
    }

    if (form.matches('[data-form="material-modal"]')) {
      event.preventDefault();
      var materialData = new FormData(form);
      await mutate(function () {
        return post('admin-resources.php', {
          action: 'update',
          path: materialData.get('path') || '',
          title: materialData.get('title') || '',
          section: materialData.get('section') || '',
          description: materialData.get('description') || '',
          notes: materialData.get('notes') || '',
          premium: materialData.get('premium') === 'on',
          hidden: materialData.get('hidden') === 'on'
        });
      }, 'Material updated.', 'Failed to update material.', 'materials');
      return;
    }

    if (form.matches('[data-form="test-modal"]')) {
      event.preventDefault();
      var testData = new FormData(form);
      var questions;
      try {
        questions = JSON.parse(String(testData.get('questionsJson') || '[]'));
        if (!Array.isArray(questions)) {
          throw new Error('Questions must be a JSON array.');
        }
      } catch (error) {
        state.error = error.message || 'Questions JSON is invalid.';
        render();
        return;
      }
      await mutate(function () {
        return post('admin-tests.php', {
          id: testData.get('id') || '',
          title: testData.get('title') || '',
          section: testData.get('section') || 'reading',
          description: testData.get('description') || '',
          durationMinutes: Number(testData.get('durationMinutes') || 60),
          attemptLimit: Number(testData.get('attemptLimit') || 3),
          premium: testData.get('premium') === 'on',
          status: testData.get('status') || 'draft',
          questions: questions
        });
      }, 'Test saved.', 'Failed to save test.', 'tests');
      return;
    }

    if (form.matches('[data-form="submission-modal"]')) {
      event.preventDefault();
      var submissionData = new FormData(form);
      await mutate(function () {
        return post('admin-submissions.php', {
          id: submissionData.get('id') || '',
          assignedReviewerId: submissionData.get('assignedReviewerId') || null,
          status: submissionData.get('status') || 'pending_review',
          reviewBand: submissionData.get('reviewBand') === '' ? null : Number(submissionData.get('reviewBand')),
          reviewFeedback: submissionData.get('reviewFeedback') || ''
        });
      }, 'Submission updated.', 'Failed to update submission.', 'submissions');
      return;
    }

    if (form.matches('[data-form="plan-modal"]')) {
      event.preventDefault();
      var planData = new FormData(form);
      await mutate(function () {
        return post('admin-payments.php', {
          action: 'savePlan',
          id: planData.get('id') || '',
          name: planData.get('name') || '',
          price: Number(planData.get('price') || 0),
          interval: planData.get('interval') || 'month',
          enabled: planData.get('enabled') === 'on',
          featuresText: planData.get('featuresText') || ''
        });
      }, 'Plan saved.', 'Failed to save plan.', 'payments');
      return;
    }

    if (form.matches('[data-form="paypal-config-form"]')) {
      event.preventDefault();
      var paypalData = new FormData(form);
      await mutate(function () {
        return requestForm('admin-settings.php', paypalData);
      }, 'PayPal config saved.', 'Failed to save PayPal config.', 'payments');
      return;
    }

    if (form.matches('[data-form="settings-form"]')) {
      event.preventDefault();
      await mutate(function () {
        return requestForm('admin-settings.php', buildSettingsFormData(form));
      }, 'Settings saved.', 'Failed to save settings.', 'settings', function () {
        clearSettingsUploadPreviews();
      });
    }
  }

  async function mutate(work, successMessage, errorMessage, sectionToReload, onSuccess) {
    state.loading = true;
    state.error = '';
    state.message = '';
    render();
    try {
      await work();
      state.loading = false;
      state.message = successMessage;
      state.modal = null;
      if (typeof onSuccess === 'function') {
        onSuccess();
      }
      await loadSection(sectionToReload || state.activeSection, true);
    } catch (error) {
      state.loading = false;
      state.error = error.message || errorMessage;
      render();
    }
  }

  function findById(items, id) {
    return (items || []).find(function (item) { return String(item.id || '') === String(id || ''); }) || null;
  }

  function findByPath(items, path) {
    return (items || []).find(function (item) { return String(item.path || '') === String(path || ''); }) || null;
  }

  async function loadSection(section, force) {
    if (!section || (state.data[section] && !force)) {
      render();
      return;
    }

    state.loading = true;
    state.error = '';
    render();

    try {
      if (section === 'overview') state.data.overview = await request('admin-dashboard.php', { method: 'GET' });
      if (section === 'users') state.data.users = await request('admin-users.php', { method: 'GET' });
      if (section === 'materials') state.data.materials = await request('admin-resources.php', { method: 'GET' });
      if (section === 'tests') state.data.tests = await request('admin-tests.php', { method: 'GET' });
      if (section === 'submissions') state.data.submissions = await request('admin-submissions.php', { method: 'GET' });
      if (section === 'payments') {
        state.data.payments = await request('admin-payments.php', { method: 'GET' });
        state.data.settings = await request('admin-settings.php', { method: 'GET' });
      }
      if (section === 'analytics') state.data.analytics = await request('admin-analytics.php', { method: 'GET' });
      if (section === 'settings') state.data.settings = await request('admin-settings.php', { method: 'GET' });
      state.loading = false;
      render();
    } catch (error) {
      state.loading = false;
      state.error = error.message || 'Failed to load section.';
      render();
    }
  }

  function loadActiveSection() {
    loadSection(state.activeSection, true);
  }

  function render() {
    var app = document.getElementById('admin-app');
    if (!app) return;

    if (state.bootStatus === 'guest') {
      app.innerHTML = renderLogin();
      return;
    }

    if (state.bootStatus === 'forbidden') {
      app.innerHTML = renderForbidden();
      return;
    }

    app.innerHTML = renderDashboard();
  }

  function renderLogin() {
    return '<div class="admin-login-shell"><div class="admin-login-card"><span class="admin-kicker">Dedicated Admin Portal</span><h1>IELTSLab Admin</h1><p>Sign in with an administrator account to manage users, materials, tests, submissions, billing, analytics, and platform settings.</p>' +
      (state.error ? '<div class="admin-error">' + ui.escape(state.error) + '</div>' : '') +
      '<form data-form="admin-login" class="admin-form-grid admin-form-grid--single"><div class="admin-field"><label for="admin-email">Email</label><input class="admin-input" id="admin-email" name="email" type="email" placeholder="admin@ieltslab.local" required></div><div class="admin-field"><label for="admin-password">Password</label><div class="admin-password-wrap"><input class="admin-input admin-password-input" id="admin-password" name="password" type="password" required><button type="button" class="admin-password-toggle" data-action="toggle-password-visibility" aria-label="Show password" title="Show password"><span data-pwd-label>Show</span></button></div></div><div class="admin-form-actions"><button class="admin-button" type="submit"' + (state.authLoading ? ' disabled' : '') + '>' + (state.authLoading ? 'Signing in...' : 'Sign in to admin') + '</button><button class="admin-button--secondary" type="button" data-action="toggle-theme">' + ui.escape(getThemeButtonLabel()) + '</button><a class="admin-button--ghost" href="../">Back to site</a></div></form></div></div>';
  }

  function renderForbidden() {
    return '<div class="admin-forbidden-shell"><div class="admin-forbidden-card"><span class="admin-kicker">Access Restricted</span><h1>Admin access required</h1><p>Your current account is signed in, but it does not have the admin role needed to access this dashboard.</p><div class="admin-form-actions"><button class="admin-button--secondary" type="button" data-action="toggle-theme">' + ui.escape(getThemeButtonLabel()) + '</button><a class="admin-button" href="../">Return to main app</a></div></div></div>';
  }

  function renderDashboard() {
    return '<div class="admin-layout"><aside class="admin-sidebar"><div class="admin-brand"><span class="admin-kicker">IELTSLab Platform</span><strong>Admin Dashboard</strong><p>Separate operational console for the live platform.</p></div><nav class="admin-nav">' + sections.map(function (section) {
      return '<button type="button" class="' + (state.activeSection === section.id ? 'is-active' : '') + '" data-action="switch-section" data-section="' + section.id + '">' + ui.escape(section.label) + '</button>';
    }).join('') + '</nav><div class="admin-sidebar__footer"><div class="admin-sidebar__user"><strong>' + ui.escape((state.user && state.user.name) || 'Admin') + '</strong><p>' + ui.escape((state.user && state.user.email) || '') + '</p></div><button type="button" class="admin-button--secondary" data-action="toggle-theme">' + ui.escape(getThemeButtonLabel()) + '</button><a class="admin-button--secondary" href="../">Open main app</a><button type="button" class="admin-button--ghost" data-action="logout">Sign out</button></div></aside><main class="admin-main"><header class="admin-topbar"><div><span class="admin-kicker">Standalone route: /admin</span><h1>' + ui.escape(getSectionLabel(state.activeSection)) + '</h1><p>Dedicated operations workspace for managing the IELTSLab platform.</p></div><div class="admin-topbar__actions"><button class="admin-button--secondary" type="button" data-action="toggle-theme">' + ui.escape(getThemeButtonLabel()) + '</button><a class="admin-button--secondary" href="../">View user app</a></div></header>' + (state.message ? '<div class="admin-message">' + ui.escape(state.message) + '</div>' : '') + (state.error ? '<div class="admin-error">' + ui.escape(state.error) + '</div>' : '') + '<div class="admin-content">' + renderActiveSection() + '</div></main>' + (state.modal ? renderModal() : '') + '</div>';
  }

  function getSectionLabel(sectionId) {
    var match = sections.find(function (section) { return section.id === sectionId; });
    return match ? match.label : 'Overview';
  }

  function renderLoadingBlock() {
    return ui.panel('Loading', '<p>Fetching live admin data...</p>');
  }

  function renderActiveSection() {
    if (state.loading && !state.data[state.activeSection]) return renderLoadingBlock();
    if (state.activeSection === 'overview') return renderOverview();
    if (state.activeSection === 'users') return renderUsers();
    if (state.activeSection === 'materials') return renderMaterials();
    if (state.activeSection === 'tests') return renderTests();
    if (state.activeSection === 'submissions') return renderSubmissions();
    if (state.activeSection === 'payments') return renderPayments();
    if (state.activeSection === 'analytics') return renderAnalytics();
    if (state.activeSection === 'settings') return renderSettings();
    return renderOverview();
  }

  function renderOverview() {
    var data = state.data.overview || { summary: {}, users: [], resources: [], outbox: [] };
    var summary = data.summary || {};
    return ui.sectionHeader('Platform overview', 'High-level metrics and operational highlights across the live platform.') +
      '<div class="admin-stats">' +
        ui.statCard('Users', String(summary.userCount || 0), 'Registered accounts') +
        ui.statCard('Events', String(summary.eventCount || 0), 'Tracked activity events') +
        ui.statCard('Resources', String(summary.resourceCount || 0), 'Catalog items visible to users') +
        ui.statCard('Pro users', String(summary.proUserCount || 0), 'Active paid accounts') +
      '</div>' +
      '<div class="admin-overview-grid">' +
        ui.panel('Recent users', renderOverviewList((data.users || []).slice(0, 6), function (user) {
          return '<div><strong>' + ui.escape(user.name) + '</strong><p>' + ui.escape(user.email) + '</p></div><div>' + ui.badge(user.role, user.role === 'admin' ? 'info' : (user.role === 'instructor' ? 'warning' : 'neutral')) + '</div>';
        })) +
        ui.panel('Outgoing messages', renderOverviewList((data.outbox || []).slice(0, 6), function (item) {
          return '<div><strong>' + ui.escape(item.type) + '</strong><p>' + ui.escape(item.email || '') + '</p></div><div>' + ui.badge('Queued', 'neutral') + '</div>';
        })) +
      '</div>' +
      ui.panel('Catalog snapshot', '<div class="admin-list">' + (data.resources || []).slice(0, 8).map(function (item) {
        var meta = item.meta || {};
        return '<div class="admin-list-item"><div><strong>' + ui.escape(meta.title || item.path) + '</strong><p>' + ui.escape(meta.description || item.path) + '</p></div><div>' + ui.badge(meta.section || 'uncategorized', 'info') + '</div></div>';
      }).join('') + '</div>');
  }

  function renderOverviewList(items, renderer) {
    if (!items.length) return '<div class="admin-empty">No recent records available.</div>';
    return '<div class="admin-list">' + items.map(function (item) { return '<div class="admin-list-item">' + renderer(item) + '</div>'; }).join('') + '</div>';
  }

  function renderUsers() {
    var users = ((state.data.users || {}).users || []).filter(function (user) {
      var roleMatch = state.filters.usersRole === 'all' || user.role === state.filters.usersRole;
      var search = state.filters.usersSearch.toLowerCase();
      var searchMatch = !search || user.name.toLowerCase().includes(search) || user.email.toLowerCase().includes(search);
      return roleMatch && searchMatch;
    });
    return ui.sectionHeader('Users management', 'Search, filter, add, edit, and delete platform accounts.', '<button class="admin-button" type="button" data-action="open-create-user">Add user</button>') +
      '<div class="admin-search-row"><input class="admin-input" data-filter="usersSearch" placeholder="Search by name or email" value="' + ui.escape(state.filters.usersSearch) + '"><select class="admin-select" data-filter="usersRole">' + ui.option('all', 'All roles', state.filters.usersRole === 'all') + ui.option('student', 'Student', state.filters.usersRole === 'student') + ui.option('instructor', 'Instructor', state.filters.usersRole === 'instructor') + ui.option('admin', 'Admin', state.filters.usersRole === 'admin') + '</select><div></div></div>' +
      ui.table(['User', 'Role', 'Plan', 'Verification', 'Joined', 'Actions'], users.map(function (user) {
        return '<tr><td><strong>' + ui.escape(user.name) + '</strong><br><span class="admin-kicker">' + ui.escape(user.email) + '</span></td><td>' + ui.badge(user.role, user.role === 'admin' ? 'info' : (user.role === 'instructor' ? 'warning' : 'neutral')) + '</td><td>' + ui.badge(user.plan, user.plan === 'Pro' ? 'success' : 'neutral') + '</td><td>' + ui.badge(user.emailVerified ? 'Verified' : 'Pending', user.emailVerified ? 'success' : 'warning') + '</td><td>' + ui.escape(formatDate(user.joinedAt)) + '</td><td><div class="admin-table-actions"><button class="admin-button--secondary" type="button" data-action="edit-user" data-id="' + ui.escape(user.id) + '">Edit</button><button class="admin-button--ghost" type="button" data-action="delete-user" data-id="' + ui.escape(user.id) + '">Delete</button></div></td></tr>';
      }));
  }

  function renderMaterials() {
    var resources = ((state.data.materials || {}).resources || []).filter(function (item) {
      var meta = item.meta || {};
      var search = state.filters.materialsSearch.toLowerCase();
      var categoryMatch = state.filters.materialsCategory === 'all' || String(meta.section || '') === state.filters.materialsCategory;
      var accessMatch = state.filters.materialsAccess === 'all' || (state.filters.materialsAccess === 'premium' ? !!meta.premium : !meta.premium);
      var searchMatch = !search || String(meta.title || item.path).toLowerCase().includes(search) || String(meta.description || '').toLowerCase().includes(search);
      return categoryMatch && accessMatch && searchMatch;
    });
    return ui.sectionHeader('Learning materials', 'Upload, classify, and monetize reading, writing, listening, and speaking materials.') +
      '<div class="admin-two-column">' +
        ui.panel('Upload new material', '<form data-form="materials-upload" class="admin-form-grid admin-form-grid--single"><div class="admin-field"><label>Title</label><input class="admin-input" name="title" required></div><div class="admin-field"><label>Description</label><textarea class="admin-textarea" name="description" rows="3"></textarea></div><div class="admin-field"><label>Category</label><select class="admin-select" name="section">' + ui.option('reading', 'Reading') + ui.option('writing', 'Writing') + ui.option('listening', 'Listening') + ui.option('speaking', 'Speaking') + '</select></div><div class="admin-field"><label>Notes</label><textarea class="admin-textarea" name="notes" rows="3"></textarea></div><label class="admin-checkbox"><input type="checkbox" name="premium" value="1"><span>Mark as premium</span></label><div class="admin-field"><label>File</label><input class="admin-input" type="file" name="resource" required></div><div class="admin-form-actions"><button class="admin-button" type="submit">Upload material</button></div></form>') +
        ui.panel('Content filters', '<div class="admin-search-row"><input class="admin-input" data-filter="materialsSearch" placeholder="Search materials" value="' + ui.escape(state.filters.materialsSearch) + '"><select class="admin-select" data-filter="materialsCategory">' + ui.option('all', 'All categories', state.filters.materialsCategory === 'all') + ui.option('reading', 'Reading', state.filters.materialsCategory === 'reading') + ui.option('writing', 'Writing', state.filters.materialsCategory === 'writing') + ui.option('listening', 'Listening', state.filters.materialsCategory === 'listening') + ui.option('speaking', 'Speaking', state.filters.materialsCategory === 'speaking') + '</select><select class="admin-select" data-filter="materialsAccess">' + ui.option('all', 'All access', state.filters.materialsAccess === 'all') + ui.option('free', 'Free only', state.filters.materialsAccess === 'free') + ui.option('premium', 'Premium only', state.filters.materialsAccess === 'premium') + '</select></div><p>Uploaded files can be deleted physically; repo materials are hidden from the public catalog when removed.</p>') +
      '</div>' +
      ui.table(['Material', 'Category', 'Access', 'Visibility', 'Updated', 'Actions'], resources.map(function (item) {
        var meta = item.meta || {};
        return '<tr><td><strong>' + ui.escape(meta.title || item.path) + '</strong><br><span class="admin-kicker">' + ui.escape(meta.description || item.path) + '</span></td><td>' + ui.badge(meta.section || 'uncategorized', 'info') + '</td><td>' + ui.badge(meta.premium ? 'Premium' : 'Free', meta.premium ? 'warning' : 'success') + '</td><td>' + ui.badge(meta.hidden ? 'Hidden' : 'Visible', meta.hidden ? 'danger' : 'success') + '</td><td>' + ui.escape(formatDate(meta.updatedAt || meta.uploadedAt || 0)) + '</td><td><div class="admin-table-actions"><button class="admin-button--secondary" type="button" data-action="edit-material" data-key="' + encodeURIComponent(item.path || '') + '">Edit</button><button class="admin-button--ghost" type="button" data-action="delete-material" data-key="' + encodeURIComponent(item.path || '') + '">Delete</button></div></td></tr>';
      }));
  }

  function renderTests() {
    var tests = ((state.data.tests || {}).tests || []).filter(function (test) {
      var search = state.filters.testsSearch.toLowerCase();
      var sectionMatch = state.filters.testsSection === 'all' || test.section === state.filters.testsSection;
      var searchMatch = !search || String(test.title || '').toLowerCase().includes(search) || String(test.description || '').toLowerCase().includes(search);
      return sectionMatch && searchMatch;
    });
    return ui.sectionHeader('Tests and exams', 'Create and manage structured IELTS-style tests with questions, timers, answers, and attempt limits.', '<button class="admin-button" type="button" data-action="open-create-test">Create test</button>') +
      '<div class="admin-search-row"><input class="admin-input" data-filter="testsSearch" placeholder="Search tests" value="' + ui.escape(state.filters.testsSearch) + '"><select class="admin-select" data-filter="testsSection">' + ui.option('all', 'All sections', state.filters.testsSection === 'all') + ui.option('reading', 'Reading', state.filters.testsSection === 'reading') + ui.option('writing', 'Writing', state.filters.testsSection === 'writing') + ui.option('listening', 'Listening', state.filters.testsSection === 'listening') + ui.option('speaking', 'Speaking', state.filters.testsSection === 'speaking') + '</select><div></div></div>' +
      ui.table(['Test', 'Section', 'Questions', 'Timer', 'Attempts', 'Status', 'Actions'], tests.map(function (test) {
        return '<tr><td><strong>' + ui.escape(test.title) + '</strong><br><span class="admin-kicker">' + ui.escape(test.description || '') + '</span></td><td>' + ui.badge(test.section, 'info') + '</td><td>' + ui.escape(String((test.questions || []).length)) + '</td><td>' + ui.escape(String(test.durationMinutes || 60)) + ' min</td><td>' + ui.escape(String(test.attemptLimit || 3)) + '</td><td>' + ui.badge(test.status || 'draft', test.status === 'published' ? 'success' : 'warning') + '</td><td><div class="admin-table-actions"><button class="admin-button--secondary" type="button" data-action="edit-test" data-id="' + ui.escape(test.id) + '">Edit</button><button class="admin-button--ghost" type="button" data-action="delete-test" data-id="' + ui.escape(test.id) + '">Delete</button></div></td></tr>';
      }));
  }

  function renderSubmissions() {
    var data = state.data.submissions || { submissions: [], reviewers: [] };
    var submissions = (data.submissions || []).filter(function (submission) {
      var typeMatch = state.filters.submissionsType === 'all' || submission.type === state.filters.submissionsType;
      var statusMatch = state.filters.submissionsStatus === 'all' || submission.status === state.filters.submissionsStatus;
      return typeMatch && statusMatch;
    });
    return ui.sectionHeader('Submissions management', 'Review writing and speaking submissions, assign reviewers, and record band scores and feedback.') +
      '<div class="admin-filter-row"><select class="admin-select" data-filter="submissionsType">' + ui.option('all', 'All types', state.filters.submissionsType === 'all') + ui.option('writing', 'Writing', state.filters.submissionsType === 'writing') + ui.option('speaking', 'Speaking', state.filters.submissionsType === 'speaking') + '</select><select class="admin-select" data-filter="submissionsStatus">' + ui.option('all', 'All statuses', state.filters.submissionsStatus === 'all') + ui.option('pending_review', 'Pending review', state.filters.submissionsStatus === 'pending_review') + ui.option('assigned', 'Assigned', state.filters.submissionsStatus === 'assigned') + ui.option('reviewed', 'Reviewed', state.filters.submissionsStatus === 'reviewed') + '</select><div></div></div>' +
      ui.table(['Student', 'Type', 'Prompt', 'Status', 'Band', 'Reviewer', 'Actions'], submissions.map(function (submission) {
        var reviewer = findById(data.reviewers || [], submission.assignedReviewerId);
        return '<tr><td><strong>' + ui.escape(submission.userName || submission.userId || 'Unknown user') + '</strong><br><span class="admin-kicker">' + ui.escape(submission.userId || '') + '</span></td><td>' + ui.badge(submission.type || 'submission', submission.type === 'speaking' ? 'warning' : 'info') + '</td><td>' + ui.escape((submission.prompt || '').slice(0, 80) || 'No prompt') + '</td><td>' + ui.badge(submission.status || 'pending_review', submission.status === 'reviewed' ? 'success' : 'warning') + '</td><td>' + ui.escape(submission.reviewBand == null ? '--' : submission.reviewBand) + '</td><td>' + ui.escape(reviewer ? reviewer.name : 'Unassigned') + '</td><td><button class="admin-button--secondary" type="button" data-action="review-submission" data-id="' + ui.escape(submission.id) + '">Review</button></td></tr>';
      }));
  }

  function renderPayments() {
    var data = state.data.payments || { plans: [], payments: [] };
    var paypalCfg = (((state.data.settings || {}).settings || {}).integrations || {}).paypal || {};
    var paypalClientId = paypalCfg.clientId || '';
    var paypalSecretKey = paypalCfg.secretKey || '';
    var paypalMode = paypalCfg.mode || 'sandbox';
    var paypalSaved = paypalClientId !== '';
    return ui.sectionHeader('Payments and subscriptions', 'Create plans, toggle availability, and inspect payment history.', '<button class="admin-button" type="button" data-action="open-create-plan">Create plan</button>') +
      '<div class="admin-card-grid">' + (data.plans || []).map(function (plan) {
        return '<article class="admin-panel"><div class="admin-panel__body"><div class="admin-topbar"><div><span class="admin-kicker">Subscription plan</span><h3>' + ui.escape(plan.name) + '</h3><p>$' + ui.escape(String(plan.price)) + ' / ' + ui.escape(plan.interval || 'month') + '</p></div><div>' + ui.badge(plan.enabled ? 'Enabled' : 'Disabled', plan.enabled ? 'success' : 'danger') + '</div></div><ul class="admin-list">' + (plan.features || []).map(function (feature) { return '<li>' + ui.escape(feature) + '</li>'; }).join('') + '</ul><div class="admin-form-actions"><button class="admin-button--secondary" type="button" data-action="edit-plan" data-id="' + ui.escape(plan.id) + '">Edit</button><button class="admin-button--ghost" type="button" data-action="delete-plan" data-id="' + ui.escape(plan.id) + '">Delete</button></div></div></article>';
      }).join('') + '</div>' +
      ui.panel('Payment history', ui.table(['User', 'Plan', 'Amount', 'Status', 'Provider', 'Created'], (data.payments || []).map(function (payment) {
        return '<tr><td>' + ui.escape(payment.userId || '') + '</td><td>' + ui.badge(payment.plan || 'Plan', 'info') + '</td><td>$' + ui.escape(String(payment.amount || 0)) + '</td><td>' + ui.badge(payment.status || 'unknown', payment.status === 'completed' ? 'success' : 'warning') + '</td><td>' + ui.escape(payment.provider || 'manual') + '</td><td>' + ui.escape(formatDate(payment.createdAt || 0)) + '</td></tr>';
      }))) +
      '<section class="admin-panel" style="margin-top:24px"><div class="admin-panel__body"><div class="admin-topbar"><div><span class="admin-kicker">Payment gateway</span><h3>PayPal Configuration</h3><p>Enter your PayPal sandbox or live API credentials. These are stored server-side and never exposed to users.</p></div>' + ui.badge(paypalSaved ? (paypalMode === 'live' ? 'Live' : 'Sandbox') : 'Not configured', paypalSaved ? (paypalMode === 'live' ? 'success' : 'warning') : 'danger') + '</div>' +
        '<form data-form="paypal-config-form" class="admin-form-grid admin-form-grid--single" style="margin-top:16px">' +
          '<div class="admin-field"><label>Mode</label><select class="admin-select" name="paypalMode">' + ui.option('sandbox', 'Sandbox (testing)', paypalMode === 'sandbox') + ui.option('live', 'Live (production)', paypalMode === 'live') + '</select></div>' +
          '<div class="admin-field"><label>Client ID</label><input class="admin-input" name="paypalClientId" value="' + ui.escape(paypalClientId) + '" placeholder="AXxx..."></div>' +
          '<div class="admin-field"><label>Secret Key</label><input class="admin-input" type="password" name="paypalSecretKey" value="' + ui.escape(paypalSecretKey) + '" placeholder="EXxx..."></div>' +
          '<div class="admin-form-actions"><button class="admin-button" type="submit">Save PayPal config</button></div>' +
        '</form>' +
      '</div></section>';
  }

  function renderAnalytics() {
    var data = state.data.analytics || { summary: {}, recentEvents: [] };
    var summary = data.summary || {};
    return ui.sectionHeader('Analytics dashboard', 'Key platform metrics, activity patterns, and operational visibility.') +
      '<div class="admin-stats">' + ui.statCard('Users', String(summary.userCount || 0), 'Total registered users') + ui.statCard('Admins', String(summary.adminCount || 0), 'Active administrators') + ui.statCard('Events', String(summary.eventCount || 0), 'Tracked engagement events') + ui.statCard('Resources', String(summary.resourceCount || 0), 'Visible materials in catalog') + '</div>' +
      '<div class="admin-two-column">' + ui.panel('Engagement by event', renderBars(summary.eventsByType || {}, maxValue(Object.values(summary.eventsByType || {})))) + ui.panel('Generated content volume', renderBars(summary.generatedContent || {}, maxValue(Object.values(summary.generatedContent || {})))) + '</div>' +
      ui.panel('Recent platform activity', ui.table(['Time', 'Type', 'User', 'IP'], (data.recentEvents || []).map(function (eventItem) {
        return '<tr><td>' + ui.escape(formatDate(eventItem.at || 0)) + '</td><td>' + ui.badge(eventItem.type || 'event', 'neutral') + '</td><td>' + ui.escape(eventItem.email || eventItem.userId || 'Unknown') + '</td><td>' + ui.escape(eventItem.ip || '') + '</td></tr>';
      })));
  }

  function renderSettings() {
    var settings = ((state.data.settings || {}).settings) || {};
    var landingMedia = settings.landingMedia || {};
    return ui.sectionHeader('Platform settings', 'Manage branding, support contacts, and integration configuration for the live platform.') +
      '<form data-form="settings-form" class="admin-settings-grid">' +
        '<section class="admin-panel"><div class="admin-panel__body"><h3>Landing media manager</h3><p class="admin-helper-text">Update homepage hero and section previews with separate light and dark assets. Selecting a file shows a local preview immediately. Click save in this section to publish it to the public landing page.</p><div class="admin-media-grid">' +
          renderLandingMediaAdminCard('hero', 'Hero preview', landingMedia.hero, 'Large showcase at the top of the homepage.') +
          renderLandingMediaAdminCard('listening', 'Listening preview', landingMedia.listening, 'Section preview for listening practice.') +
          renderLandingMediaAdminCard('reading', 'Reading preview', landingMedia.reading, 'Section preview for reading practice.') +
          renderLandingMediaAdminCard('writing', 'Writing preview', landingMedia.writing, 'Section preview for writing practice.') +
          renderLandingMediaAdminCard('speaking', 'Speaking preview', landingMedia.speaking, 'Section preview for speaking practice.') +
        '</div><div class="admin-form-actions"><button class="admin-button" type="submit">Save landing media</button></div></div></section>' +
        '<section class="admin-panel"><div class="admin-panel__body"><h3>Branding</h3><div class="admin-form-grid admin-form-grid--single"><div class="admin-field"><label>Platform name</label><input class="admin-input" name="platformName" value="' + ui.escape(settings.platformName || 'IELTSLab') + '"></div><div class="admin-field"><label>Support email</label><input class="admin-input" type="email" name="supportEmail" value="' + ui.escape(settings.supportEmail || '') + '"></div><div class="admin-field"><label>Primary color</label><input class="admin-input" name="primaryColor" value="' + ui.escape((settings.brand && settings.brand.primaryColor) || '#00bfa6') + '"></div><div class="admin-field"><label>Accent color</label><input class="admin-input" name="accentColor" value="' + ui.escape((settings.brand && settings.brand.accentColor) || '#47d9cd') + '"></div>' + renderBrandingLogoUploadField(settings) + ((settings.logoUrl || '') ? '<div class="admin-field"><label>Current logo</label><a href="' + ui.escape(resolveAdminAssetPath(settings.logoUrl)) + '" target="_blank" rel="noreferrer">' + ui.escape(settings.logoUrl) + '</a></div>' : '') + '</div><div class="admin-form-actions"><button class="admin-button" type="submit">Save branding</button></div></div></section>' +
        '<section class="admin-panel"><div class="admin-panel__body"><h3>Integrations</h3><div class="admin-form-grid admin-form-grid--single"><div class="admin-field"><label>AI service key</label><input class="admin-input" name="aiServiceKey" value="' + ui.escape((settings.integrations && settings.integrations.aiServiceKey) || '') + '"></div><div class="admin-field"><label>Payment public key</label><input class="admin-input" name="paymentPublicKey" value="' + ui.escape((settings.integrations && settings.integrations.paymentPublicKey) || '') + '"></div><div class="admin-field"><label>Payment secret key</label><input class="admin-input" name="paymentSecretKey" value="' + ui.escape((settings.integrations && settings.integrations.paymentSecretKey) || '') + '"></div></div><div class="admin-form-actions"><button class="admin-button" type="submit">Save settings</button></div></div></section>' +
      '</form>';
  }

  function renderBrandingLogoUploadField(settings) {
    var fieldId = 'branding-logo-upload';
    return '<div class="admin-field"><label>Logo upload</label><div class="admin-file-pill-row"><input class="admin-file-pill__input" id="' + fieldId + '" type="file" name="logo" data-branding-logo-input="true" accept="image/*"><label class="admin-file-pill" for="' + fieldId + '">Choose file</label><span class="admin-file-pill__status" data-branding-logo-status="true">' + ui.escape(getBrandingLogoStatusLabel(settings)) + '</span></div></div>';
  }

  function getBrandingLogoStatusLabel(settings) {
    if (state.brandingLogoPendingName) {
      return 'Selected: ' + state.brandingLogoPendingName;
    }
    var savedLogo = String((settings && settings.logoUrl) || '').trim();
    if (savedLogo) {
      return 'Saved: ' + formatAssetName(savedLogo);
    }
    return 'No file chosen';
  }

  function updateBrandingLogoUploadStatus() {
    var host = document.querySelector('[data-branding-logo-status="true"]');
    if (!host) return;
    var settings = ((state.data.settings || {}).settings) || {};
    host.textContent = getBrandingLogoStatusLabel(settings);
  }

  function renderLandingMediaAdminCard(slot, title, media, description) {
    var item = media || {};
    var mode = item.mode === 'video' ? 'video' : 'image';
    var src = item.src || '';
    var lightSrc = item.lightSrc || '';
    var darkSrc = item.darkSrc || '';
    var poster = item.poster || '';
    var alt = item.alt || ('IELTSLab ' + slot + ' preview');
    var advancedOpen = !!state.settingsAdvancedSlots[slot];
    var advancedLabel = advancedOpen ? 'Hide advanced' : 'Advanced';

    return '<article class="admin-media-card">' +
      '<div class="admin-media-card__header"><div><span class="admin-kicker">Landing slot</span><h4>' + ui.escape(title) + '</h4><p>' + ui.escape(description) + '</p></div>' + ui.badge(mode === 'video' ? 'Looping video' : 'Screenshot', mode === 'video' ? 'warning' : 'info') + '</div>' +
      '<div class="admin-media-preview-grid">' +
        '<div class="admin-media-preview-host" data-preview-slot="' + ui.escape(slot) + '" data-preview-theme="light">' + renderLandingMediaAdminPreview(slot, item, 'light') + '</div>' +
        '<div class="admin-media-preview-host" data-preview-slot="' + ui.escape(slot) + '" data-preview-theme="dark">' + renderLandingMediaAdminPreview(slot, item, 'dark') + '</div>' +
      '</div>' +
      '<div class="admin-form-grid admin-form-grid--single">' +
        '<div class="admin-field"><label>Display mode</label><select class="admin-select" name="landingMode_' + ui.escape(slot) + '">' + ui.option('image', 'Screenshot', mode === 'image') + ui.option('video', 'Looping video', mode === 'video') + '</select></div>' +
        renderLandingMediaUploadField(slot, 'lightMedia', 'landingLightFile_' + slot, 'Upload light mode screenshot or video', 'image/*,video/mp4,video/webm,video/quicktime') +
        renderLandingMediaUploadField(slot, 'darkMedia', 'landingDarkFile_' + slot, 'Upload dark mode screenshot or video', 'image/*,video/mp4,video/webm,video/quicktime') +
        '<div class="admin-form-actions"><button class="admin-button--secondary" type="button" data-action="toggle-landing-advanced" data-slot="' + ui.escape(slot) + '">' + ui.escape(advancedLabel) + '</button></div>' +
        (advancedOpen ? (
          '<div class="admin-field"><label>Light mode source URL or saved path</label><input class="admin-input" name="landingLightSrc_' + ui.escape(slot) + '" value="' + ui.escape(lightSrc) + '" placeholder="user-content/landing-media/... or https://..."></div>' +
          '<div class="admin-field"><label>Dark mode source URL or saved path</label><input class="admin-input" name="landingDarkSrc_' + ui.escape(slot) + '" value="' + ui.escape(darkSrc) + '" placeholder="user-content/landing-media/... or https://..."></div>' +
          '<div class="admin-field"><label>Fallback source URL or saved path</label><input class="admin-input" name="landingSrc_' + ui.escape(slot) + '" value="' + ui.escape(src) + '" placeholder="Used when light/dark asset is missing"></div>' +
          renderLandingMediaUploadField(slot, 'media', 'landingFile_' + slot, 'Upload fallback screenshot or video', 'image/*,video/mp4,video/webm,video/quicktime') +
          '<div class="admin-field"><label>Poster URL or saved path</label><input class="admin-input" name="landingPoster_' + ui.escape(slot) + '" value="' + ui.escape(poster) + '" placeholder="Optional poster for videos"></div>' +
          renderLandingMediaUploadField(slot, 'poster', 'landingPosterFile_' + slot, 'Upload poster image', 'image/*') +
          '<div class="admin-field"><label>Alt text / label</label><input class="admin-input" name="landingAlt_' + ui.escape(slot) + '" value="' + ui.escape(alt) + '" placeholder="Describe what appears in the preview"></div>'
        ) : '') +
      '</div>' +
    '</article>';
  }

  function renderLandingMediaUploadField(slot, variant, inputName, labelText, accept) {
    var fieldId = 'landing-upload-' + slot + '-' + variant;
    return '<div class="admin-field"><label>' + ui.escape(labelText) + '</label><div class="admin-file-pill-row"><input class="admin-file-pill__input" id="' + ui.escape(fieldId) + '" type="file" name="' + ui.escape(inputName) + '" data-settings-media-input="true" data-slot="' + ui.escape(slot) + '" data-variant="' + ui.escape(variant) + '" accept="' + ui.escape(accept) + '"><label class="admin-file-pill" for="' + ui.escape(fieldId) + '">Choose file</label><span class="admin-file-pill__status" data-file-status-slot="' + ui.escape(slot) + '" data-file-status-variant="' + ui.escape(variant) + '">' + ui.escape(getUploadStatusLabel(slot, variant)) + '</span></div></div>';
  }

  function getUploadStatusLabel(slot, variant) {
    var entry = state.settingsUploadPreviews[slot] || {};
    var pending = entry[variant] || null;
    if (pending && pending.fileName) {
      return 'Selected: ' + pending.fileName;
    }

    var settings = ((state.data.settings || {}).settings) || {};
    var landingMedia = settings.landingMedia || {};
    var item = landingMedia[slot] || {};
    var savedPath = '';

    if (variant === 'lightMedia') {
      savedPath = item.lightSrc || '';
    } else if (variant === 'darkMedia') {
      savedPath = item.darkSrc || '';
    } else if (variant === 'media') {
      savedPath = item.src || '';
    } else if (variant === 'poster') {
      savedPath = item.poster || '';
    }

    if (savedPath) {
      return 'Saved: ' + formatAssetName(savedPath);
    }

    return 'No file chosen';
  }

  function formatAssetName(path) {
    var value = String(path || '').trim();
    if (!value) return '';
    var clean = value.split('?')[0].split('#')[0];
    var parts = clean.split('/').filter(Boolean);
    return parts.length ? parts[parts.length - 1] : clean;
  }

  function renderLandingMediaAdminPreview(slot, media, themeName) {
    var item = media || {};
    var pending = state.settingsUploadPreviews[slot] || {};
    var mode = item.mode === 'video' ? 'video' : 'image';
    var activeTheme = themeName === 'dark' ? 'dark' : 'light';
    var themeLabel = activeTheme === 'dark' ? 'Dark mode' : 'Light mode';
    var themedSrc = activeTheme === 'dark' ? (item.darkSrc || '') : (item.lightSrc || '');
    var sourcePreview = (activeTheme === 'dark' ? pending.darkMedia : pending.lightMedia) || pending.media || null;
    var posterPreview = pending.poster || null;
    var src = sourcePreview ? sourcePreview.url : resolveAdminAssetPath(themedSrc || item.src || '');
    var poster = posterPreview ? posterPreview.url : resolveAdminAssetPath(item.poster || '');
    var label = item.alt || ('IELTSLab ' + slot + ' preview');
    var sourceLabel = sourcePreview ? 'Pending upload: ' + sourcePreview.fileName : (themedSrc || item.src || '');

    if (sourcePreview && /^video\//i.test(sourcePreview.type || '')) {
      mode = 'video';
    }

    if (!src) {
      return '<div class="admin-media-preview admin-media-preview--empty"><strong>' + ui.escape(themeLabel) + ': no asset connected yet.</strong><span>Save an uploaded file or provide a URL/path for this theme.</span></div>';
    }

    if (mode === 'video') {
      return '<div class="admin-media-preview"><video class="admin-media-preview__asset" src="' + ui.escape(src) + '"' + (poster ? ' poster="' + ui.escape(poster) + '"' : '') + ' muted loop autoplay playsinline preload="metadata"></video><div class="admin-media-preview__meta"><strong>' + ui.escape(label) + ' (' + ui.escape(themeLabel) + ')</strong><span>' + ui.escape(sourceLabel) + '</span></div></div>';
    }

    return '<div class="admin-media-preview"><img class="admin-media-preview__asset" src="' + ui.escape(src) + '" alt="' + ui.escape(label) + '"><div class="admin-media-preview__meta"><strong>' + ui.escape(label) + ' (' + ui.escape(themeLabel) + ')</strong><span>' + ui.escape(sourceLabel) + '</span></div></div>';
  }

  function ensureSettingsUploadPreviewSlot(slot) {
    if (!state.settingsUploadPreviews[slot]) {
      state.settingsUploadPreviews[slot] = { media: null, lightMedia: null, darkMedia: null, poster: null };
    }
  }

  function updateLandingMediaPreview(slot) {
    var settings = ((state.data.settings || {}).settings) || {};
    var landingMedia = settings.landingMedia || {};
    var hosts = document.querySelectorAll('[data-preview-slot="' + cssEscape(slot) + '"]');
    if (!hosts.length) return;

    hosts.forEach(function (host) {
      var previewTheme = host.getAttribute('data-preview-theme') || 'light';
      host.innerHTML = renderLandingMediaAdminPreview(slot, landingMedia[slot] || {}, previewTheme);
    });
  }

  function updateLandingMediaUploadStatus(slot, variant) {
    var host = document.querySelector('[data-file-status-slot="' + cssEscape(slot) + '"][data-file-status-variant="' + cssEscape(variant) + '"]');
    if (!host) return;
    host.textContent = getUploadStatusLabel(slot, variant);
  }

  function buildSettingsFormData(form) {
    var formData = new FormData(form);
    Object.keys(state.settingsUploadPreviews || {}).forEach(function (slot) {
      var entry = state.settingsUploadPreviews[slot] || {};
      if (entry.media && entry.media.file) {
        formData.delete('landingFile_' + slot);
        formData.append('landingFile_' + slot, entry.media.file, entry.media.fileName || entry.media.file.name || 'media');
      }
      if (entry.lightMedia && entry.lightMedia.file) {
        formData.delete('landingLightFile_' + slot);
        formData.append('landingLightFile_' + slot, entry.lightMedia.file, entry.lightMedia.fileName || entry.lightMedia.file.name || 'light-media');
      }
      if (entry.darkMedia && entry.darkMedia.file) {
        formData.delete('landingDarkFile_' + slot);
        formData.append('landingDarkFile_' + slot, entry.darkMedia.file, entry.darkMedia.fileName || entry.darkMedia.file.name || 'dark-media');
      }
      if (entry.poster && entry.poster.file) {
        formData.delete('landingPosterFile_' + slot);
        formData.append('landingPosterFile_' + slot, entry.poster.file, entry.poster.fileName || entry.poster.file.name || 'poster');
      }
    });
    return formData;
  }

  function cssEscape(value) {
    return String(value || '').replace(/"/g, '\\"');
  }

  function clearSettingsUploadPreviews() {
    Object.keys(state.settingsUploadPreviews || {}).forEach(function (slot) {
      var entry = state.settingsUploadPreviews[slot] || {};
      ['media', 'lightMedia', 'darkMedia', 'poster'].forEach(function (variant) {
        if (entry[variant] && entry[variant].url) {
          try {
            window.URL.revokeObjectURL(entry[variant].url);
          } catch (error) {
          }
        }
      });
    });
    state.settingsUploadPreviews = {};
    state.brandingLogoPendingName = '';
  }

  function resolveAdminAssetPath(path) {
    var value = String(path || '').trim();
    if (!value) return '';
    if (/^(https?:)?\/\//i.test(value) || value.indexOf('data:') === 0) return value;
    return '../' + value.replace(/^\//, '');
  }

  function renderBars(map, max) {
    var entries = Object.keys(map || {});
    if (!entries.length) return '<div class="admin-empty">No analytics data yet.</div>';
    return '<div class="admin-bar-chart">' + entries.map(function (key) {
      var value = Number(map[key] || 0);
      var width = max > 0 ? Math.max(8, Math.round((value / max) * 100)) : 0;
      return '<div class="admin-bar-row"><span>' + ui.escape(key) + '</span><div class="admin-bar"><span style="width:' + width + '%"></span></div><strong>' + ui.escape(String(value)) + '</strong></div>';
    }).join('') + '</div>';
  }

  function renderModal() {
    if (!state.modal) return '';
    if (state.modal.type === 'user') return ui.modal(state.modal.payload ? 'Edit user' : 'Create user', renderUserModal(state.modal.payload));
    if (state.modal.type === 'material') return ui.modal('Edit material', renderMaterialModal(state.modal.payload));
    if (state.modal.type === 'test') return ui.modal(state.modal.payload ? 'Edit test' : 'Create test', renderTestModal(state.modal.payload));
    if (state.modal.type === 'submission') return ui.modal('Review submission', renderSubmissionModal(state.modal.payload));
    if (state.modal.type === 'plan') return ui.modal(state.modal.payload ? 'Edit plan' : 'Create plan', renderPlanModal(state.modal.payload));
    return '';
  }

  function renderUserModal(user) {
    var isEdit = !!user;
    return '<form data-form="user-modal" class="admin-form-grid"><input type="hidden" name="action" value="' + (isEdit ? 'update' : 'create') + '"><input type="hidden" name="userId" value="' + ui.escape((user && user.id) || '') + '"><div class="admin-field"><label>Full name</label><input class="admin-input" name="name" value="' + ui.escape((user && user.name) || '') + '" required></div><div class="admin-field"><label>Email</label><input class="admin-input" type="email" name="email" value="' + ui.escape((user && user.email) || '') + '"' + (isEdit ? ' disabled' : '') + ' required></div>' + (!isEdit ? '<div class="admin-field"><label>Password</label><input class="admin-input" type="password" name="password" required></div>' : '') + '<div class="admin-field"><label>Role</label><select class="admin-select" name="role">' + ui.option('student', 'Student', user && user.role === 'student') + ui.option('instructor', 'Instructor', user && user.role === 'instructor') + ui.option('admin', 'Admin', user && user.role === 'admin') + '</select></div><div class="admin-field"><label>Plan</label><select class="admin-select" name="plan">' + ui.option('Free', 'Free', !user || user.plan === 'Free') + ui.option('Pro', 'Pro', user && user.plan === 'Pro') + '</select></div><div class="admin-field"><label>Verification</label><select class="admin-select" name="emailVerified">' + ui.option('false', 'Pending', !user || !user.emailVerified) + ui.option('true', 'Verified', user && user.emailVerified) + '</select></div><div class="admin-form-actions"><button class="admin-button" type="submit">' + (isEdit ? 'Save user' : 'Create user') + '</button></div></form>';
  }

  function renderMaterialModal(item) {
    var meta = (item && item.meta) || {};
    return '<form data-form="material-modal" class="admin-form-grid admin-form-grid--single"><input type="hidden" name="path" value="' + ui.escape((item && item.path) || '') + '"><div class="admin-field"><label>Title</label><input class="admin-input" name="title" value="' + ui.escape(meta.title || '') + '"></div><div class="admin-field"><label>Category</label><select class="admin-select" name="section">' + ui.option('reading', 'Reading', meta.section === 'reading') + ui.option('writing', 'Writing', meta.section === 'writing') + ui.option('listening', 'Listening', meta.section === 'listening') + ui.option('speaking', 'Speaking', meta.section === 'speaking') + ui.option('', 'Uncategorized', !meta.section) + '</select></div><div class="admin-field"><label>Description</label><textarea class="admin-textarea" name="description" rows="4">' + ui.escape(meta.description || '') + '</textarea></div><div class="admin-field"><label>Notes</label><textarea class="admin-textarea" name="notes" rows="3">' + ui.escape(meta.notes || '') + '</textarea></div><label class="admin-checkbox"><input type="checkbox" name="premium"' + (meta.premium ? ' checked' : '') + '><span>Premium content</span></label><label class="admin-checkbox"><input type="checkbox" name="hidden"' + (meta.hidden ? ' checked' : '') + '><span>Hide from public catalog</span></label><div class="admin-form-actions"><button class="admin-button" type="submit">Save material</button></div></form>';
  }

  function renderTestModal(test) {
    return '<form data-form="test-modal" class="admin-form-grid admin-form-grid--single"><input type="hidden" name="id" value="' + ui.escape((test && test.id) || '') + '"><div class="admin-field"><label>Title</label><input class="admin-input" name="title" value="' + ui.escape((test && test.title) || '') + '" required></div><div class="admin-field"><label>Section</label><select class="admin-select" name="section">' + ui.option('reading', 'Reading', test && test.section === 'reading') + ui.option('writing', 'Writing', test && test.section === 'writing') + ui.option('listening', 'Listening', test && test.section === 'listening') + ui.option('speaking', 'Speaking', test && test.section === 'speaking') + '</select></div><div class="admin-field"><label>Description</label><textarea class="admin-textarea" name="description" rows="3">' + ui.escape((test && test.description) || '') + '</textarea></div><div class="admin-form-grid"><div class="admin-field"><label>Duration (minutes)</label><input class="admin-input" type="number" name="durationMinutes" min="5" max="180" value="' + ui.escape(String((test && test.durationMinutes) || 60)) + '"></div><div class="admin-field"><label>Attempt limit</label><input class="admin-input" type="number" name="attemptLimit" min="1" max="20" value="' + ui.escape(String((test && test.attemptLimit) || 3)) + '"></div></div><div class="admin-field"><label>Status</label><select class="admin-select" name="status">' + ui.option('draft', 'Draft', !test || test.status === 'draft') + ui.option('published', 'Published', test && test.status === 'published') + ui.option('archived', 'Archived', test && test.status === 'archived') + '</select></div><label class="admin-checkbox"><input type="checkbox" name="premium"' + (test && test.premium ? ' checked' : '') + '><span>Premium test</span></label><div class="admin-field"><label>Questions JSON</label><textarea class="admin-textarea" name="questionsJson" rows="12" placeholder="[{&quot;prompt&quot;:&quot;Question&quot;,&quot;answer&quot;:&quot;Answer&quot;,&quot;explanation&quot;:&quot;Explanation&quot;}]">' + ui.escape(JSON.stringify((test && test.questions) || [], null, 2)) + '</textarea></div><div class="admin-form-actions"><button class="admin-button" type="submit">Save test</button></div></form>';
  }

  function renderSubmissionModal(submission) {
    var reviewers = ((state.data.submissions || {}).reviewers) || [];
    if (!submission) return '<div class="admin-empty">Submission not found.</div>';
    return '<form data-form="submission-modal" class="admin-form-grid admin-form-grid--single"><input type="hidden" name="id" value="' + ui.escape(submission.id) + '"><div class="admin-field"><label>Prompt</label><textarea class="admin-textarea" rows="4" disabled>' + ui.escape(submission.prompt || '') + '</textarea></div><div class="admin-field"><label>Assign reviewer</label><select class="admin-select" name="assignedReviewerId">' + ui.option('', 'Unassigned', !submission.assignedReviewerId) + reviewers.map(function (reviewer) { return ui.option(reviewer.id, reviewer.name + ' (' + reviewer.role + ')', String(reviewer.id) === String(submission.assignedReviewerId || '')); }).join('') + '</select></div><div class="admin-form-grid"><div class="admin-field"><label>Status</label><select class="admin-select" name="status">' + ui.option('pending_review', 'Pending review', submission.status === 'pending_review') + ui.option('assigned', 'Assigned', submission.status === 'assigned') + ui.option('reviewed', 'Reviewed', submission.status === 'reviewed') + '</select></div><div class="admin-field"><label>Band score</label><input class="admin-input" type="number" name="reviewBand" min="0" max="9" step="0.5" value="' + ui.escape(submission.reviewBand == null ? '' : String(submission.reviewBand)) + '"></div></div><div class="admin-field"><label>Feedback</label><textarea class="admin-textarea" name="reviewFeedback" rows="6">' + ui.escape(submission.reviewFeedback || '') + '</textarea></div><div class="admin-form-actions"><button class="admin-button" type="submit">Save review</button></div></form>';
  }

  function renderPlanModal(plan) {
    return '<form data-form="plan-modal" class="admin-form-grid admin-form-grid--single"><input type="hidden" name="id" value="' + ui.escape((plan && plan.id) || '') + '"><div class="admin-field"><label>Plan name</label><input class="admin-input" name="name" value="' + ui.escape((plan && plan.name) || '') + '" required></div><div class="admin-form-grid"><div class="admin-field"><label>Price</label><input class="admin-input" type="number" min="0" step="0.01" name="price" value="' + ui.escape(String((plan && plan.price) || 0)) + '"></div><div class="admin-field"><label>Interval</label><select class="admin-select" name="interval">' + ui.option('month', 'Month', !plan || plan.interval === 'month') + ui.option('year', 'Year', plan && plan.interval === 'year') + '</select></div></div><div class="admin-field"><label>Features</label><textarea class="admin-textarea" name="featuresText" rows="6" placeholder="One feature per line">' + ui.escape(((plan && plan.features) || []).join('\n')) + '</textarea></div><label class="admin-checkbox"><input type="checkbox" name="enabled"' + (!plan || plan.enabled ? ' checked' : '') + '><span>Plan enabled</span></label><div class="admin-form-actions"><button class="admin-button" type="submit">Save plan</button></div></form>';
  }

  function confirmDeleteUser(userId) {
    if (!window.confirm('Delete this user?')) return;
    mutate(function () {
      return post('admin-users.php', { action: 'delete', userId: userId });
    }, 'User deleted.', 'Failed to delete user.', 'users');
  }

  function confirmDeleteMaterial(path) {
    if (!window.confirm('Delete or hide this material?')) return;
    mutate(function () {
      return post('admin-resources.php', { action: 'delete', path: path });
    }, 'Material removed.', 'Failed to remove material.', 'materials');
  }

  function confirmDeleteTest(testId) {
    if (!window.confirm('Delete this test?')) return;
    mutate(function () {
      return post('admin-tests.php', { action: 'delete', id: testId });
    }, 'Test deleted.', 'Failed to delete test.', 'tests');
  }

  function confirmDeletePlan(planId) {
    if (!window.confirm('Delete this subscription plan?')) return;
    mutate(function () {
      return post('admin-payments.php', { action: 'deletePlan', id: planId });
    }, 'Plan deleted.', 'Failed to delete plan.', 'payments');
  }

  function formatDate(timestamp) {
    var numeric = Number(timestamp || 0);
    if (!numeric) return '--';
    return new Date(numeric * 1000).toLocaleString();
  }

  function maxValue(values) {
    return (values || []).reduce(function (max, value) {
      return Math.max(max, Number(value || 0));
    }, 0);
  }

  function loadTheme() {
    try {
      var saved = window.localStorage.getItem(THEME_STORAGE_KEY);
      return saved === 'dark' ? 'dark' : 'light';
    } catch (error) {
      return 'light';
    }
  }

  function applyTheme(theme) {
    var resolvedTheme = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', resolvedTheme);
  }

  function getThemeButtonLabel() {
    return state.theme === 'dark' ? 'Light theme' : 'Dark theme';
  }

  function toggleTheme() {
    state.theme = state.theme === 'dark' ? 'light' : 'dark';
    applyTheme(state.theme);
    try {
      window.localStorage.setItem(THEME_STORAGE_KEY, state.theme);
    } catch (error) {
      // Ignore storage failures and keep the in-memory theme state.
    }
    render();
  }

  function init() {
    bindEvents();
    applyTheme(state.theme);
    render();
    if (state.bootStatus === 'admin') {
      loadActiveSection();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
