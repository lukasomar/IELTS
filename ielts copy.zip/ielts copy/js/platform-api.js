(function () {
  function getBasePath() {
    if (window.location.protocol === 'file:') return './';
    const pathname = window.location.pathname.toLowerCase();
    if (pathname.includes('/ietls')) return '/IETLS/';
    if (pathname.includes('/ielts')) return '/ielts/';
    return './';
  }

  const basePath = getBasePath();

  function normalizePath(path) {
    if (!path) return '';
    if (/^https?:/i.test(path)) return path;
    return basePath + String(path).replace(/^\//, '');
  }

  async function request(path, options) {
    const response = await fetch(normalizePath(path), Object.assign({
      credentials: 'same-origin',
      headers: {
        'Content-Type': 'application/json'
      }
    }, options || {}));

    const payload = await response.json().catch(function () {
      return { success: false, error: 'Invalid server response.' };
    });

    if (!response.ok || !payload.success) {
      throw new Error(payload && payload.error ? payload.error : 'Request failed.');
    }

    return payload;
  }

  function post(path, body) {
    return request(path, {
      method: 'POST',
      body: JSON.stringify(body || {})
    });
  }

  async function postForm(path, formData) {
    const response = await fetch(normalizePath(path), {
      method: 'POST',
      body: formData,
      credentials: 'same-origin'
    });

    const payload = await response.json().catch(function () {
      return { success: false, error: 'Invalid server response.' };
    });

    if (!response.ok || !payload.success) {
      throw new Error(payload && payload.error ? payload.error : 'Request failed.');
    }

    return payload;
  }

  window.IELTSLabPlatform = {
    isAvailable: function () {
      return window.location.protocol !== 'file:';
    },
    getMe: function () {
      return request('api/auth-me.php', { method: 'GET' });
    },
    signup: function (data) {
      return post('api/auth-signup.php', data);
    },
    login: function (data) {
      return post('api/auth-login.php', data);
    },
    logout: function () {
      return post('api/auth-logout.php', {});
    },
    updateProfile: function (data) {
      return post('api/auth-update-profile.php', data);
    },
    getPlatformSettings: function () {
      return request('api/platform-settings.php', { method: 'GET' });
    },
    getPlans: function () {
      return request('api/plans.php', { method: 'GET' });
    },
    createPayPalOrder: function (data) {
      return post('api/paypal-create-order.php', data);
    },
    capturePayPalOrder: function (data) {
      return post('api/paypal-capture-order.php', data);
    },
    checkoutBilling: function (data) {
      return post('api/billing-checkout.php', data);
    },
    generateReadingTest: function (data) {
      return post('api/generate-reading-test.php', data);
    },
    scoreReadingTest: function (data) {
      return post('api/score-reading-test.php', data);
    },
    evaluateWriting: function (data) {
      return post('api/evaluate-writing.php', data);
    },
    startMockExam: function (data) {
      return post('api/start-mock-exam.php', data);
    },
    updateMockExam: function (data) {
      return post('api/update-mock-exam.php', data);
    },
    getAdminDashboard: function () {
      return request('api/admin-dashboard.php', { method: 'GET' });
    },
    updateAdminUser: function (data) {
      return post('api/admin-users.php', data);
    },
    updateAdminResource: function (data) {
      return post('api/admin-resources.php', data);
    },
    uploadAdminResource: function (formData) {
      return postForm('api/admin-resource-upload.php', formData);
    },
    track: function (type, payload) {
      return post('api/analytics-track.php', { type: type, payload: payload || {} });
    }
  };
})();