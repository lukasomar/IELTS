/**
 * IELTSLab frontend shell
 * Static product UI built on top of the existing IELTS content catalog.
 */

(function () {
  const ACTIVITY_KEY = 'ieltslab-activity-v1';
  const listeningAI = window.IELTSLabListeningAI;
  const speakingAI = window.IELTSLabSpeakingAI;
  const platform = window.IELTSLabPlatform;
  const focusAudio = createFocusAudioEngine();
  let landingObserver = null;
  let landingMotionCleanup = null;

  const BASE_PATH = (function () {
    if (window.location.protocol === 'file:') return './';
    const pathname = window.location.pathname.toLowerCase();
    if (pathname.includes('/ietls')) return '/IETLS/';
    if (pathname.includes('/ielts')) return '/ielts/';
    return './';
  })();

  const NAV_ITEMS = [
    { id: 'dashboard', label: 'Dashboard', icon: 'dashboard' },
    { id: 'practice', label: 'Practice', icon: 'practice' },
    { id: 'writing', label: 'Writing', icon: 'writing' },
    { id: 'reading', label: 'Reading', icon: 'reading' },
    { id: 'listening', label: 'Listening', icon: 'listening' },
    { id: 'speaking', label: 'Speaking', icon: 'speaking' },
    { id: 'library', label: 'Library', icon: 'library' },
    { id: 'progress', label: 'Progress', icon: 'progress' },
    { id: 'profile', label: 'Profile', icon: 'profile' }
  ];

  const FOCUS_SOUNDS = ['Rain', 'Ocean', 'Brown Noise', 'Library Silence', 'Forest', 'Fireplace', 'Night Crickets'];
  const LIBRARY_CATEGORIES = ['all', 'writing', 'reading', 'listening', 'speaking'];

  const state = {
    catalog: null,
    platformSettings: null,
    user: null,
    entryScreen: 'landing',
    authModalOpen: false,
    settings: loadSettings(),
    view: 'dashboard',
    authMode: 'login',
    authError: '',
    authStatus: 'idle',
    libraryCategory: 'all',
    librarySearch: '',
    selectedPath: '',
    profileError: '',
    profileMessage: '',
    profileStatus: 'idle',
    plansStatus: 'idle',
    plansData: null,
    plansError: '',
    leaveSectionConfirmOpen: false,
    leaveSectionFromView: '',
    leaveSectionToView: 'dashboard',
    selectedPlanId: '',
    selectedPaymentMethod: '',
    cardCheckoutStatus: 'idle',
    cardCheckoutError: '',
    introReturnView: 'dashboard',
    writingIntroOpen: false,
    readingIntroOpen: false,
    listeningIntroOpen: false,
    speakingIntroOpen: false,
    focusAudioStatus: focusAudio.isSupported() ? 'idle' : 'unsupported',
    focusAudioError: '',
    aiReading: initialReadingState(),
    aiWriting: initialWritingState(),
    mockExam: initialMockExamState(),
    aiListening: listeningAI ? listeningAI.initialState() : null,
    aiSpeaking: speakingAI ? speakingAI.initialState() : null
  };

  async function init() {
    bindEvents();
    applyTheme(state.settings.theme);

    try {
      const results = await Promise.all([
        loadCatalog(BASE_PATH),
        hydrateSessionUser(),
        hydratePlatformSettings()
      ]);
      state.catalog = results[0];
      state.platformSettings = results[2] || null;
      if (results[1]) {
        state.entryScreen = 'app';
      }
      ensureSelectedPath();
      render();
    } catch (err) {
      render(err.message);
    }
  }

  function bindEvents() {
    document.addEventListener('click', handleClick);
    document.addEventListener('submit', handleSubmit);
    document.addEventListener('input', handleInput);
    window.addEventListener('beforeunload', function () {
      focusAudio.stop();
    });
  }

  function handleClick(event) {
    const stopBoundary = event.target.closest('[data-stop-click="true"]');
    if (stopBoundary) {
      event.stopPropagation();
    }

    const routeTarget = event.target.closest('[data-route]');
    if (routeTarget) {
      event.preventDefault();
      const nextView = routeTarget.getAttribute('data-route');
      if (nextView === 'admin' && (!state.user || state.user.role !== 'admin')) {
        return;
      }
      if (nextView === 'admin') {
        window.location.href = BASE_PATH + 'admin/';
        return;
      }
      if (nextView === 'writing') {
        state.introReturnView = state.view || 'dashboard';
        state.view = 'writing';
        state.writingIntroOpen = true;
        render();
        return;
      }
      if (nextView === 'reading') {
        state.introReturnView = state.view || 'dashboard';
        state.view = 'reading';
        state.readingIntroOpen = true;
        render();
        return;
      }
      if (nextView === 'listening') {
        state.introReturnView = state.view || 'dashboard';
        state.view = 'listening';
        state.listeningIntroOpen = true;
        render();
        return;
      }
      if (nextView === 'speaking') {
        state.introReturnView = state.view || 'dashboard';
        state.view = 'speaking';
        state.speakingIntroOpen = true;
        render();
        return;
      }
      if (nextView === 'dashboard' && ['writing', 'reading', 'listening', 'speaking'].indexOf(state.view) !== -1) {
        state.leaveSectionFromView = state.view;
        state.leaveSectionToView = 'dashboard';
        state.leaveSectionConfirmOpen = true;
        render();
        return;
      }
      if (nextView === 'practice') {
        state.view = 'practice';
        if (state.plansStatus === 'idle' && platform) {
          state.plansStatus = 'loading';
          render();
          platform.getPlans().then(function (res) {
            state.plansData = res.plans || [];
            state.plansStatus = 'ready';
            render();
          }).catch(function () {
            state.plansData = [];
            state.plansStatus = 'ready';
            render();
          });
          return;
        }
        render();
        return;
      }
      state.view = nextView;
      const category = routeTarget.getAttribute('data-category');
      if (state.view === 'library' && category) {
        state.libraryCategory = category;
      }
      if (state.view === 'library') {
        ensureSelectedPath();
      }
      render();
      return;
    }

    const actionTarget = event.target.closest('[data-action]');
    if (!actionTarget) return;

    // Prevent clicks inside a stop-click boundary from triggering actions outside it
    if (stopBoundary && !stopBoundary.contains(actionTarget) && stopBoundary !== actionTarget) return;

    event.preventDefault();
    const action = actionTarget.getAttribute('data-action');

    if (action === 'switch-auth') {
      state.authMode = actionTarget.getAttribute('data-mode') || 'login';
      state.authError = '';
      render();
      return;
    }

    if (action === 'show-auth') {
      state.authMode = actionTarget.getAttribute('data-mode') || 'login';
      state.authError = '';
      state.authModalOpen = true;
      render();
      return;
    }

    if (action === 'close-auth-modal') {
      state.authModalOpen = false;
      state.authError = '';
      render();
      return;
    }

    if (action === 'toggle-password-visibility') {
      const wrap = actionTarget.closest('.password-field-wrap');
      const pwdInput = wrap ? wrap.querySelector('input') : null;
      if (pwdInput) {
        const show = pwdInput.type === 'password';
        pwdInput.type = show ? 'text' : 'password';
        const label = actionTarget.querySelector('[data-pwd-label]');
        if (label) label.textContent = show ? 'Hide' : 'Show';
        actionTarget.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
      }
      return;
    }

    if (action === 'show-plans') {
      state.view = 'plans';
      state.plansStatus = 'loading';
      state.plansError = '';
      state.selectedPlanId = '';
      state.selectedPaymentMethod = '';
      state.cardCheckoutStatus = 'idle';
      state.cardCheckoutError = '';
      render();
      if (platform) {
        platform.getPlans().then(function (res) {
          state.plansData = res.plans || [];
          state.plansStatus = 'ready';
          render();
        }).catch(function (err) {
          state.plansError = err && err.message ? err.message : 'Failed to load plans.';
          state.plansStatus = 'error';
          render();
        });
      } else {
        state.plansData = [];
        state.plansStatus = 'ready';
        render();
      }
      return;
    }

    if (action === 'select-plan') {
      state.selectedPlanId = actionTarget.getAttribute('data-plan-id') || '';
      state.selectedPaymentMethod = '';
      state.cardCheckoutStatus = 'idle';
      state.cardCheckoutError = '';
      render();
      return;
    }

    if (action === 'choose-payment-method') {
      state.selectedPaymentMethod = actionTarget.getAttribute('data-method') || '';
      state.cardCheckoutStatus = 'idle';
      state.cardCheckoutError = '';
      render();
      return;
    }

    if (action === 'close-writing-intro') {
      state.writingIntroOpen = false;
      state.view = state.introReturnView || 'dashboard';
      render();
      return;
    }

    if (action === 'close-reading-intro') {
      state.readingIntroOpen = false;
      state.view = state.introReturnView || 'dashboard';
      render();
      return;
    }

    if (action === 'close-listening-intro') {
      state.listeningIntroOpen = false;
      state.view = state.introReturnView || 'dashboard';
      render();
      return;
    }

    if (action === 'close-speaking-intro') {
      state.speakingIntroOpen = false;
      state.view = state.introReturnView || 'dashboard';
      render();
      return;
    }

    if (action === 'cancel-leave-section') {
      state.leaveSectionConfirmOpen = false;
      state.leaveSectionFromView = '';
      state.leaveSectionToView = 'dashboard';
      render();
      return;
    }

    if (action === 'confirm-leave-section') {
      var nextRoute = state.leaveSectionToView || 'dashboard';
      state.leaveSectionConfirmOpen = false;
      state.leaveSectionFromView = '';
      state.leaveSectionToView = 'dashboard';
      state.view = nextRoute;
      render();
      return;
    }

    if (action === 'open-app') {
      if (!state.user) {
        state.authMode = 'login';
        state.authError = '';
        state.authModalOpen = true;
        render();
        return;
      }
      state.entryScreen = 'app';
      state.view = 'dashboard';
      render();
      return;
    }

    if (action === 'logout') {
      state.authStatus = 'submitting';
      render();

      platform.logout()
        .catch(function () {
          return null;
        })
        .finally(function () {
          focusAudio.stop();
          state.user = null;
          state.entryScreen = 'landing';
          state.settings = loadSettings();
          state.view = 'dashboard';
          state.authMode = 'login';
          state.authError = '';
          state.authStatus = 'idle';
          state.focusAudioStatus = focusAudio.isSupported() ? 'idle' : 'unsupported';
          state.focusAudioError = '';
          applyTheme(state.settings.theme);
          render();
        });
      return;
    }

    if (action === 'set-focus') {
      setFocusSound(actionTarget.getAttribute('data-sound') || 'Rain', true);
      return;
    }

    if (action === 'toggle-focus-sound') {
      if (focusAudio.isPlaying()) {
        stopFocusSound();
      } else {
        startFocusSound(state.settings.focusSound || 'Rain');
      }
      return;
    }

    if (action === 'stop-focus-sound') {
      stopFocusSound();
      return;
    }

    if (action === 'toggle-theme') {
      toggleTheme();
      return;
    }

    if (action === 'start-practice') {
      startPractice(actionTarget.getAttribute('data-skill') || 'practice');
      return;
    }

    if (action === 'select-category') {
      state.libraryCategory = actionTarget.getAttribute('data-category') || 'all';
      ensureSelectedPath();
      render();
      return;
    }

    if (action === 'select-path') {
      state.selectedPath = actionTarget.getAttribute('data-path') || '';
      addActivity('Opened resource', getFileName(state.selectedPath));
      render();
      return;
    }

    if (action === 'open-listening-library-item') {
      state.view = 'library';
      state.libraryCategory = 'listening';
      state.selectedPath = actionTarget.getAttribute('data-path') || '';
      addActivity('Opened listening audio', getFileName(state.selectedPath));
      render();
      return;
    }

    if (action === 'reset-listening-test' && state.aiListening) {
      state.aiListening = listeningAI.initialState();
      render();
      return;
    }

    if (action === 'generate-listening-audio' && state.aiListening && state.aiListening.session) {
      state.aiListening.audioStatus = 'generating';
      state.aiListening.audioError = '';
      state.aiListening.session.audioStatus = 'generating';
      render();

      listeningAI.generateAudio(state.aiListening.session.sessionId)
        .then(function (response) {
          state.aiListening.audioStatus = 'ready';
          state.aiListening.audioError = '';
          state.aiListening.session.audioUrl = response.audioUrl;
          state.aiListening.session.audioReady = true;
          state.aiListening.session.audioStatus = 'ready';
          addActivity('Generated listening audio', 'Audio is ready for playback.');
          render();
        })
        .catch(function (err) {
          state.aiListening.audioStatus = 'error';
          state.aiListening.audioError = err && err.message ? err.message : 'Failed to generate listening audio.';
          state.aiListening.session.audioStatus = 'error';
          render();
        });
      return;
    }

    if (action === 'start-speaking-recording' && state.aiSpeaking) {
      state.aiSpeaking.error = '';
      speakingAI.startRecording(state.aiSpeaking)
        .then(function () {
          render();
        })
        .catch(function (err) {
          state.aiSpeaking.error = err && err.message ? err.message : 'Failed to start microphone recording.';
          render();
        });
      render();
      return;
    }

    if (action === 'stop-speaking-recording' && state.aiSpeaking) {
      speakingAI.stopRecording(state.aiSpeaking)
        .then(function () {
          render();
        })
        .catch(function (err) {
          state.aiSpeaking.error = err && err.message ? err.message : 'Failed to stop microphone recording.';
          render();
        });
      render();
      return;
    }

    if (action === 'clear-speaking-recording' && state.aiSpeaking) {
      speakingAI.clearRecording(state.aiSpeaking);
      render();
      return;
    }

    if (action === 'start-mock-exam') {
      startMockExam();
      return;
    }

    if (action === 'save-mock-section') {
      updateMockExamSection(actionTarget.getAttribute('data-section') || getMockExamCurrentSectionKey(), 'save');
      return;
    }

    if (action === 'complete-mock-section') {
      updateMockExamSection(actionTarget.getAttribute('data-section') || getMockExamCurrentSectionKey(), 'complete');
      return;
    }

    if (action === 'open-mock-section') {
      state.view = actionTarget.getAttribute('data-section') || 'listening';
      render();
      return;
    }
  }

  async function handleSubmit(event) {
    const form = event.target;
    if (form.matches('[data-form="ai-reading-generate"]') && platform) {
      event.preventDefault();
      const data = new FormData(form);
      state.aiReading.status = 'generating';
      state.aiReading.error = '';
      state.aiReading.result = null;
      render();

      try {
        const response = await platform.generateReadingTest({
          targetBand: String(data.get('targetBand') || state.user.goalBand || '6.5'),
          questionCount: Number(data.get('questionCount') || 8),
          theme: String(data.get('theme') || 'academic article')
        });
        state.aiReading.status = 'ready';
        state.aiReading.session = response.session;
        state.user.progress.skills.reading.status = 'In progress';
        saveUser(state.user);
        persistCurrentUserState();
        addActivity('Generated reading test', response.session.testTitle || 'New reading passage ready.');
      } catch (err) {
        state.aiReading.status = 'error';
        state.aiReading.error = err && err.message ? err.message : 'Failed to generate the reading test.';
      }

      render();
      return;
    }

    if (form.matches('[data-form="ai-reading-answers"]') && state.aiReading.session && platform) {
      event.preventDefault();
      state.aiReading.status = 'scoring';
      state.aiReading.error = '';
      render();

      try {
        const response = await platform.scoreReadingTest({
          sessionId: state.aiReading.session.sessionId,
          answers: collectSequentialAnswers(form, state.aiReading.session.questions || [])
        });
        state.aiReading.status = 'scored';
        state.aiReading.result = response.result;
        state.user.progress.skills.reading.band = response.result.bandScore;
        state.user.progress.overallBand = response.result.bandScore;
        saveUser(state.user);
        persistCurrentUserState();
        addActivity('Scored reading test', 'Band ' + response.result.bandScore + ' from ' + response.result.rawScore + '/' + response.result.totalQuestions + '.');
      } catch (err) {
        state.aiReading.status = 'error';
        state.aiReading.error = err && err.message ? err.message : 'Failed to score the reading answers.';
      }

      render();
      return;
    }

    if (form.matches('[data-form="ai-writing-evaluate"]') && platform) {
      event.preventDefault();
      const data = new FormData(form);
      state.aiWriting.status = 'evaluating';
      state.aiWriting.error = '';
      render();

      try {
        const response = await platform.evaluateWriting({
          taskType: String(data.get('taskType') || 'Task 2'),
          prompt: String(data.get('prompt') || ''),
          essay: String(data.get('essay') || ''),
          targetBand: String(data.get('targetBand') || state.user.goalBand || '7.0')
        });
        state.aiWriting.status = 'done';
        state.aiWriting.result = response.result;
        state.user.progress.skills.writing.status = 'In progress';
        state.user.progress.skills.writing.band = response.result.overallBand;
        state.user.progress.overallBand = response.result.overallBand;
        saveUser(state.user);
        persistCurrentUserState();
        addActivity('Evaluated writing task', 'Band ' + response.result.overallBand + ' for ' + response.result.taskType + '.');
      } catch (err) {
        state.aiWriting.status = 'error';
        state.aiWriting.error = err && err.message ? err.message : 'Failed to evaluate the writing task.';
      }

      render();
      return;
    }

    if (form.matches('[data-form="ai-listening-generate"]') && state.aiListening) {
      event.preventDefault();
      const data = new FormData(form);
      state.aiListening.status = 'generating';
      state.aiListening.error = '';
      state.aiListening.result = null;
      render();

      try {
        const response = await listeningAI.generateTest({
          targetBand: data.get('targetBand'),
          questionCount: data.get('questionCount'),
          accentMix: data.get('accentMix'),
          theme: data.get('theme'),
          notes: data.get('notes')
        });
        state.aiListening.status = 'ready';
        state.aiListening.session = response.session;
        state.aiListening.result = null;
        state.aiListening.error = '';
        state.aiListening.audioStatus = response.session.audioReady ? 'ready' : 'idle';
        state.aiListening.audioError = '';
        if (state.user && state.user.progress && state.user.progress.skills.listening) {
          state.user.progress.skills.listening.status = 'In progress';
          saveUser(state.user);
          persistCurrentUserState();
        }
        addActivity('Generated AI listening test', response.session.testTitle || 'Fresh audio and questions are ready.');

        if (response.session && response.session.sessionId && !response.session.audioReady) {
          state.aiListening.audioStatus = 'generating';
          state.aiListening.session.audioStatus = 'generating';
          render();

          listeningAI.generateAudio(response.session.sessionId)
            .then(function (audioResponse) {
              state.aiListening.audioStatus = 'ready';
              state.aiListening.audioError = '';
              state.aiListening.session.audioUrl = audioResponse.audioUrl;
              state.aiListening.session.audioReady = true;
              state.aiListening.session.audioStatus = 'ready';
              addActivity('Generated listening audio', 'Audio is ready for playback.');
              render();
            })
            .catch(function (audioErr) {
              state.aiListening.audioStatus = 'error';
              state.aiListening.audioError = audioErr && audioErr.message ? audioErr.message : 'Failed to generate listening audio.';
              state.aiListening.session.audioStatus = 'error';
              render();
            });
        }
      } catch (err) {
        state.aiListening.status = 'error';
        state.aiListening.error = err && err.message ? err.message : 'Failed to generate the listening test.';
      }

      render();
      return;
    }

    if (form.matches('[data-form="ai-listening-answers"]') && state.aiListening && state.aiListening.session) {
      event.preventDefault();
      state.aiListening.status = 'scoring';
      state.aiListening.error = '';
      render();

      try {
        const response = await listeningAI.scoreTest(
          state.aiListening.session.sessionId,
          listeningAI.collectAnswers(form)
        );
        state.aiListening.status = 'scored';
        state.aiListening.result = response.result;
        state.user.progress.skills.listening.band = response.result.bandScore;
        state.user.progress.overallBand = response.result.bandScore;
        saveUser(state.user);
        persistCurrentUserState();
        addActivity('Scored AI listening test', 'Band ' + response.result.bandScore + ' from ' + response.result.rawScore + '/' + response.result.totalQuestions + '.');
      } catch (err) {
        state.aiListening.status = 'error';
        state.aiListening.error = err && err.message ? err.message : 'Failed to score the listening answers.';
      }

      render();
      return;
    }

    if (form.matches('[data-form="ai-speaking-evaluate"]') && state.aiSpeaking) {
      event.preventDefault();
      const speakingData = new FormData(form);
      state.aiSpeaking.part = String(speakingData.get('part') || state.aiSpeaking.part || 'Part 2');
      state.aiSpeaking.targetBand = String(speakingData.get('targetBand') || state.aiSpeaking.targetBand || state.user.goalBand || '7.0');
      state.aiSpeaking.prompt = String(speakingData.get('prompt') || state.aiSpeaking.prompt || '');
      state.aiSpeaking.status = 'evaluating';
      state.aiSpeaking.error = '';
      render();

      try {
        const response = await speakingAI.evaluateSpeech(form, state.aiSpeaking);
        state.aiSpeaking.status = 'done';
        state.aiSpeaking.result = response.result;
        if (state.user && state.user.progress && state.user.progress.skills.speaking) {
          state.user.progress.skills.speaking.status = 'In progress';
          state.user.progress.skills.speaking.band = response.result.overallBand;
          saveUser(state.user);
          persistCurrentUserState();
        }
        addActivity('Evaluated speaking answer', 'Band ' + response.result.overallBand + ' with transcript review.');
      } catch (err) {
        state.aiSpeaking.status = 'error';
        state.aiSpeaking.error = err && err.message ? err.message : 'Failed to evaluate the speaking upload.';
      }

      render();
      return;
    }

    if (form.matches('[data-form="profile"]')) {
      event.preventDefault();
      state.profileStatus = 'saving';
      state.profileError = '';
      state.profileMessage = '';
      render();

      const profileData = new FormData(form);

      try {
        const response = await platform.updateProfile({
          name: String(profileData.get('name') || state.user.name || '').trim(),
          goalBand: Number(profileData.get('goalBand') || state.user.goalBand || 7),
          studyGoalMinutes: Number(profileData.get('studyGoalMinutes') || state.user.studyGoalMinutes || 30),
          settings: {
            focusSound: String(profileData.get('focusSound') || state.settings.focusSound || 'Rain'),
            theme: String(profileData.get('theme') || state.settings.theme || 'light'),
            dailyReminder: profileData.get('dailyReminder') === 'on',
            timezone: String(profileData.get('timezone') || state.settings.timezone || 'UTC')
          },
          progress: state.user.progress
        });

        saveUser(response.user);
        state.profileStatus = 'idle';
        state.profileMessage = 'Profile updated.';
        addActivity('Updated profile', 'Saved study preferences and account targets.');
      } catch (err) {
        state.profileStatus = 'idle';
        state.profileError = err && err.message ? err.message : 'Failed to update the profile.';
      }

      render();
      return;
    }

    if (!form.matches('[data-form="auth"]')) return;

    event.preventDefault();
    const data = new FormData(form);
    const mode = data.get('mode');
    const email = String(data.get('email') || '').trim().toLowerCase();
    const password = String(data.get('password') || '').trim();
    const name = String(data.get('name') || '').trim();

    if (!email || !password) {
      state.authError = 'Email and password are required.';
      render();
      return;
    }

    state.authStatus = 'submitting';
    state.authError = '';
    render();

    try {
      const response = mode === 'signup'
        ? await platform.signup({ name: name, email: email, password: password })
        : await platform.login({ email: email, password: password });

      saveUser(response.user);
      state.entryScreen = 'app';
      state.view = 'dashboard';
      state.authStatus = 'idle';
      addActivity(mode === 'signup' ? 'Account created' : 'Logged in', mode === 'signup' ? 'Your IELTSLab workspace is ready.' : 'Returned to the IELTSLab dashboard.');
    } catch (err) {
      state.authStatus = 'idle';
      state.authError = err && err.message ? err.message : 'Authentication failed.';
    }

    render();
  }

  function handleInput(event) {
    if (event.target.matches('[data-model="library-search"]')) {
      state.librarySearch = event.target.value;
      ensureSelectedPath();
      render();
      return;
    }

    if (event.target.matches('#profile-theme')) {
      setTheme(event.target.value || 'light', { persist: true, logActivity: false });
      return;
    }

    if (event.target.matches('#profile-focus-sound')) {
      setFocusSound(event.target.value || 'Rain', focusAudio.isPlaying());
      return;
    }

    if (state.aiSpeaking && event.target.matches('#speaking-part')) {
      state.aiSpeaking.part = event.target.value || 'Part 2';
      return;
    }

    if (state.aiSpeaking && event.target.matches('#speaking-target-band')) {
      state.aiSpeaking.targetBand = event.target.value || String(state.user.goalBand || 7);
      return;
    }

    if (state.aiSpeaking && event.target.matches('#speaking-prompt')) {
      state.aiSpeaking.prompt = event.target.value || '';
      return;
    }

    if (event.target.matches('#speaking-audio') && state.aiSpeaking) {
      speakingAI.syncSelectedFile(event.target, state.aiSpeaking);
      render();
    }
  }

  function render(errorMessage) {
    const app = document.getElementById('app');
    if (!app) return;

    if (errorMessage) {
      app.innerHTML = '<div class="screen-shell"><div class="auth-panel"><div class="auth-card"><h2>Catalog failed to load</h2><p>' + escapeHtml(errorMessage) + '</p></div></div></div>';
      return;
    }

    if (state.entryScreen === 'landing' || !state.user) {
      app.innerHTML = renderLandingPage();
      setupLandingExperience();
      return;
    }

    teardownLandingExperience();
    app.innerHTML = renderShell();

    if (state.view === 'library' && state.selectedPath) {
      const preview = document.getElementById('library-preview-body');
      if (preview) {
        renderPreview(state.selectedPath, preview, BASE_PATH);
      }
    }

    if (state.view === 'plans' && state.plansStatus === 'ready') {
      mountPayPalButtons();
    }
  }

  function renderLandingPage() {
    const isSignup = state.authMode === 'signup';
    return (
      '<div class="screen-shell landing-shell">' +
        renderLandingTopbar() +
        renderLandingHero() +
        renderLandingProcess() +
        '<section class="landing-band landing-band--listening landing-reveal" id="listening" data-reveal="section">' +
          '<div class="landing-band__inner">' +
            renderLandingMockup('listening') +
            renderLandingCopy('listening', 'Train your ears for the real exam.', [
              'Neural TTS voices across British, American, and Australian accents.',
              'All key IELTS listening patterns under timed pressure.',
              'Playback control plus AI-generated practice sets when you need more.'
            ], 'Try Listening') +
          '</div>' +
        '</section>' +
        '<section class="landing-band landing-band--reading landing-reveal" id="reading" data-reveal="section">' +
          '<div class="landing-band__inner landing-band__inner--reverse">' +
            renderLandingMockup('reading') +
            renderLandingCopy('reading', 'Build speed and accuracy on real passages.', [
              'Academic and General Training practice with cleaner answer review.',
              'Question-type variety with explanations instead of blind marking.',
              'Timed drills that mirror the actual exam rhythm.'
            ], 'Try Reading') +
          '</div>' +
        '</section>' +
        '<section class="landing-band landing-band--writing landing-reveal" id="writing" data-reveal="section">' +
          '<div class="landing-band__inner">' +
            renderLandingCopy('writing', 'Write better essays, faster.', [
              'Task 1 and Task 2 practice with band-aligned AI feedback.',
              'Sharper comments on task response, cohesion, vocabulary, and grammar.',
              'A cleaner drafting workflow built for repeated practice.'
            ], 'Try Writing') +
            renderLandingMockup('writing') +
          '</div>' +
        '</section>' +
        '<section class="landing-band landing-band--speaking landing-reveal" id="speaking" data-reveal="section">' +
          '<div class="landing-band__inner landing-band__inner--reverse">' +
            renderLandingCopy('speaking', 'Practice speaking with less friction.', [
              'Browser microphone recording for Parts 1, 2, and 3.',
              'Band-focused prompts and structured examiner-style feedback.',
              'One workspace for prep, review, and progress tracking.'
            ], 'Try Speaking') +
            renderLandingMockup('speaking') +
          '</div>' +
        '</section>' +
        '<section class="landing-auth-zone landing-reveal" id="auth-entry" data-reveal="section">' +
          '<div class="landing-auth-zone__inner">' +
            '<div class="landing-auth-copy landing-reveal" data-reveal="copy">' +
              '<span class="eyebrow landing-eyebrow landing-eyebrow--teal landing-reveal-item">Get started</span>' +
              renderAnimatedHeadline('h2', 'Start with a free account, then keep training inside the full platform.', 'landing-auth__headline') +
              '<p class="landing-reveal-item">IELTSLab keeps the same color language and guided study flow across dashboard, AI practice, library work, and mock exam sessions. Create an account or sign back in to continue.</p>' +
              '<div class="landing-summary-grid">' +
                renderLandingStat('4', 'Core IELTS sections') +
                renderLandingStat('AI', 'Speaking, writing, reading, and listening support') +
                renderLandingStat('1', 'Shared workspace across practice and progress') +
              '</div>' +
            '</div>' +
            renderAuthCard(isSignup) +
          '</div>' +
        '</section>' +
        renderLandingFooter() +
        (state.authModalOpen ? renderAuthModal() : '') +
      '</div>'
    );
  }

  function renderAuthScreen() {
    const isSignup = state.authMode === 'signup';
    return renderAuthCard(isSignup);
  }

  function renderAuthModal() {
    const isSignup = state.authMode === 'signup';
    return '<div class="auth-modal-backdrop" data-action="close-auth-modal"><div class="auth-modal" data-stop-click="true">' +
      '<button type="button" class="auth-modal__close" data-action="close-auth-modal" aria-label="Close">&times;</button>' +
      '<div class="auth-toggle">' +
        '<button type="button" class="' + (isSignup ? '' : 'is-active') + '" data-action="switch-auth" data-mode="login">Log in</button>' +
        '<button type="button" class="' + (isSignup ? 'is-active' : '') + '" data-action="switch-auth" data-mode="signup">Sign up</button>' +
      '</div>' +
      '<h2 class="auth-modal__title">' + (isSignup ? 'Create your workspace' : 'Welcome back') + '</h2>' +
      '<p class="auth-modal__desc">' + (isSignup ? 'A real account stored by the PHP backend. You can log in from any device.' : 'Sign in to your IELTSLab workspace and continue where you left off.') + '</p>' +
      '<form data-form="auth">' +
        '<input type="hidden" name="mode" value="' + (isSignup ? 'signup' : 'login') + '">' +
        '<div class="form-grid">' +
          (isSignup ? '<div><label class="field-label" for="auth-name">Full name</label><input class="input" id="auth-name" name="name" placeholder="Brian Mawira" autocomplete="name"></div>' : '') +
          '<div><label class="field-label" for="auth-email">Email</label><input class="input" id="auth-email" name="email" type="email" placeholder="brian@ieltslab.ai" autocomplete="email"></div>' +
          '<div><label class="field-label" for="password">Password</label>' +
            '<div class="password-field-wrap">' +
              '<input class="input password-input" id="password" name="password" type="password" placeholder="' + (isSignup ? 'At least 8 characters' : 'Enter your password') + '" autocomplete="' + (isSignup ? 'new-password' : 'current-password') + '">' +
              '<button type="button" class="password-toggle" data-action="toggle-password-visibility" aria-label="Show password" title="Show password"><span data-pwd-label>Show</span></button>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="button-row" style="margin-top:18px">' +
          '<button class="btn btn-primary" type="submit"' + (state.authStatus === 'submitting' ? ' disabled' : '') + '>' + (state.authStatus === 'submitting' ? 'Please wait...' : (isSignup ? 'Create account' : 'Log in')) + '</button>' +
        '</div>' +
      '</form>' +
      (state.authError ? '<div class="auth-error">' + escapeHtml(state.authError) + '</div>' : '') +
    '</div></div>';
  }

  function renderLandingTopbar() {
    const nextTheme = state.settings.theme === 'dark' ? 'light' : 'dark';
    const themeLabel = nextTheme === 'light' ? 'Light' : 'Dark';
    const themeIcon = state.settings.theme === 'dark' ? 'sun' : 'moon';
    return '<header class="landing-topbar"><div class="landing-topbar__inner">' +
      renderBrand() +
      '<nav class="landing-nav"><a href="#approach">Approach</a><a href="#listening">Listening</a><a href="#reading">Reading</a><a href="#writing">Writing</a><a href="#speaking">Speaking</a></nav>' +
      '<div class="landing-topbar__actions">' +
        '<button class="btn btn-secondary landing-theme-toggle" type="button" data-action="toggle-theme" aria-label="Switch to ' + escapeAttr(themeLabel) + ' theme" title="Switch to ' + escapeAttr(themeLabel) + ' theme">' + icon(themeIcon, 'landing-inline-icon') + '<span>' + escapeHtml(themeLabel) + '</span></button>' +
        (state.user ? '<button class="btn btn-secondary" type="button" data-action="open-app">Open dashboard</button>' : '<button class="btn btn-ghost" type="button" data-action="show-auth" data-mode="login">Log in</button><button class="btn btn-primary" type="button" data-action="show-auth" data-mode="signup">Sign up free</button>') +
      '</div>' +
    '</div></header>';
  }

  function renderLandingHero() {
    return '<section class="landing-hero landing-reveal is-visible" data-reveal="section">' +
      '<div class="landing-hero__inner">' +
        '<div class="landing-hero__copy landing-reveal is-visible" data-reveal="copy">' +
          renderBrand() +
          '<span class="eyebrow landing-eyebrow landing-eyebrow--sky landing-reveal-item">IELTS prep, engineered.</span>' +
          renderAnimatedHeadline('h1', 'Enter the site and understand the product before you sign in.', 'landing-hero__headline') +
          '<p class="landing-reveal-item">IELTSLab combines structured IELTS practice, AI-assisted evaluation, progress tracking, and a reusable resource library in one product. The homepage now explains the platform clearly before users choose to log in or create an account.</p>' +
          '<div class="button-row landing-hero__actions landing-reveal-item">' +
            (state.user ? '<button class="btn btn-primary" type="button" data-action="open-app">Open dashboard</button><button class="btn btn-secondary" type="button" data-action="show-auth" data-mode="login">Account options</button>' : '<button class="btn btn-primary" type="button" data-action="show-auth" data-mode="signup">Get started free</button><a class="landing-hero__link" href="#approach">See how it works ' + icon('trend', 'landing-inline-icon') + '</a>') +
          '</div>' +
          '<div class="landing-proof landing-reveal-item"><span>Listening</span><span>Reading</span><span>Writing</span><span>Speaking</span><span>Progress</span></div>' +
        '</div>' +
        '<div class="landing-hero__visual landing-reveal is-visible" data-reveal="media">' + renderLandingHeroVisual() + '</div>' +
      '</div>' +
    '</section>';
  }

  function renderLandingHeroVisual() {
    return '<div class="landing-media-stack landing-media-stack--hero">' +
      '<div class="landing-glow landing-glow--hero" data-parallax-depth="0.22" data-parallax-horizontal="0.12"></div>' +
      '<div class="landing-browser-frame landing-browser-frame--hero" data-parallax-depth="0.12" data-parallax-horizontal="0.06" data-parallax-tilt="true">' +
        renderLandingBrowserChrome() +
        '<div class="landing-media-mask">' + renderLandingMediaElement('hero', 'landing-media landing-media--hero', 'hero-dashboard.svg', 'IELTSLab dashboard preview') + '</div>' +
      '</div>' +
    '</div>';
  }

  function renderLandingProcess() {
    return '<section class="landing-process landing-reveal" id="approach" data-reveal="section">' +
      '<div class="landing-process__inner">' +
        '<div class="landing-process__intro landing-reveal" data-reveal="copy">' +
          '<span class="eyebrow landing-eyebrow landing-eyebrow--teal landing-reveal-item">How it works</span>' +
          renderAnimatedHeadline('h2', 'One clear prep system from first session to final band target.', 'landing-process__headline') +
          '<p class="landing-reveal-item">The reference page had stronger narrative structure. This section gives the homepage that same product rhythm: understand the method, see the feedback loop, then decide whether to enter the platform.</p>' +
        '</div>' +
        '<div class="landing-process__grid">' +
          renderLandingProcessCard('01', 'Start with the right section', 'Choose listening, reading, writing, or speaking based on your weak spot instead of entering a generic dashboard first.', 'target') +
          renderLandingProcessCard('02', 'Practice with feedback loops', 'Timed tasks, AI-assisted review, and clear follow-up actions make each session feel directional rather than static.', 'spark') +
          renderLandingProcessCard('03', 'Track the band path', 'Study time, performance patterns, and reusable resources stay in one workspace so improvement is visible over time.', 'trend') +
        '</div>' +
        '<div class="landing-metric-rail landing-reveal" data-reveal="copy">' +
          '<div class="landing-metric-pill landing-reveal-item"><strong>4</strong><span>core exam modules</span></div>' +
          '<div class="landing-metric-pill landing-reveal-item"><strong>AI</strong><span>guided evaluation and feedback</span></div>' +
          '<div class="landing-metric-pill landing-reveal-item"><strong>1</strong><span>continuous study workspace</span></div>' +
        '</div>' +
      '</div>' +
    '</section>';
  }

  function renderLandingProcessCard(step, title, description, iconName) {
    return '<article class="landing-process-card landing-reveal" data-reveal="copy">' +
      '<div class="landing-process-card__step landing-reveal-item">' + escapeHtml(step) + '</div>' +
      '<div class="landing-process-card__icon landing-reveal-item">' + icon(iconName, 'landing-process-icon') + '</div>' +
      '<h3 class="landing-reveal-item">' + escapeHtml(title) + '</h3>' +
      '<p class="landing-reveal-item">' + escapeHtml(description) + '</p>' +
    '</article>';
  }

  function renderLandingCopy(section, title, bullets, ctaLabel) {
    return '<div class="landing-copy landing-reveal" data-reveal="copy">' +
      '<span class="eyebrow landing-eyebrow landing-eyebrow--' + escapeAttr(getAccent(section)) + ' landing-reveal-item">' + escapeHtml(section) + '</span>' +
      renderAnimatedHeadline('h2', title, 'landing-section__headline') +
      '<ul class="landing-checklist landing-reveal-item">' + bullets.map(function (bullet) {
        return '<li>' + icon('check', 'landing-check-icon') + '<span>' + escapeHtml(bullet) + '</span></li>';
      }).join('') + '</ul>' +
      '<button class="btn btn-primary landing-reveal-item" type="button" data-action="' + (state.user ? 'open-app' : 'show-auth') + '"' + (state.user ? '' : ' data-mode="signup"') + '>' + escapeHtml(state.user ? 'Open dashboard' : ctaLabel) + '</button>' +
    '</div>';
  }

  function renderLandingMockup(section) {
    return '<div class="landing-media-stack landing-media-stack--section landing-media-stack--' + escapeAttr(section) + ' landing-reveal" data-reveal="media">' +
      '<div class="landing-glow landing-glow--' + escapeAttr(section) + '" data-parallax-depth="0.18" data-parallax-horizontal="0.1"></div>' +
      '<div class="landing-browser-frame landing-browser-frame--section landing-browser-frame--' + escapeAttr(section) + '" data-parallax-depth="0.1" data-parallax-horizontal="0.05" data-parallax-tilt="true">' +
        renderLandingBrowserChrome() +
        '<div class="landing-media-mask landing-media-mask--section">' + renderLandingMediaElement(section, 'landing-media landing-media--section', section + '-screen.svg', 'IELTSLab ' + section + ' preview') + '</div>' +
      '</div>' +
    '</div>';
  }

  function renderLandingBrowserChrome() {
    return '';
  }

  function getLandingAssetPath(fileName) {
    return BASE_PATH + 'assets/landing/' + fileName;
  }

  function getLandingMediaConfig(slot) {
    const settings = state.platformSettings || {};
    const media = settings.landingMedia || {};
    return media[slot] || null;
  }

  function normalizeMediaMode(value) {
    return String(value || '').toLowerCase() === 'video' ? 'video' : 'image';
  }

  function resolvePublicAssetPath(path) {
    const value = String(path || '').trim();
    if (!value) return '';
    if (/^(https?:)?\/\//i.test(value) || value.startsWith('data:')) {
      return value;
    }
    return BASE_PATH + value.replace(/^\//, '');
  }

  function renderLandingMediaElement(slot, className, fallbackFileName, fallbackAlt) {
    const config = getLandingMediaConfig(slot);
    const mode = normalizeMediaMode(config && config.mode);
    const theme = state.settings && state.settings.theme === 'dark' ? 'dark' : 'light';
    const themeSrc = theme === 'dark'
      ? (config && config.darkSrc)
      : (config && config.lightSrc);
    const src = resolvePublicAssetPath(themeSrc || (config && config.src)) || getLandingAssetPath(fallbackFileName);
    const poster = resolvePublicAssetPath(config && config.poster);
    const alt = String((config && config.alt) || fallbackAlt || 'IELTSLab preview');

    if (mode === 'video') {
      return '<video class="' + escapeAttr(className) + '" src="' + escapeAttr(src) + '"' + (poster ? ' poster="' + escapeAttr(poster) + '"' : '') + ' autoplay muted loop playsinline preload="metadata" aria-label="' + escapeAttr(alt) + '"></video>';
    }

    return '<img class="' + escapeAttr(className) + '" src="' + escapeAttr(src) + '" alt="' + escapeAttr(alt) + '">';
  }

  function renderAnimatedHeadline(tagName, text, className) {
    const words = String(text || '').trim().split(/\s+/).filter(Boolean);
    return '<' + tagName + ' class="landing-headline ' + escapeAttr(className || '') + '" data-reveal="headline">' + words.map(function (word, index) {
      return '<span class="landing-word-wrap"><span class="landing-word" style="transition-delay:' + (index * 36) + 'ms">' + escapeHtml(word) + '</span></span>';
    }).join(' ') + '</' + tagName + '>';
  }

  function renderLandingStat(value, label) {
    return '<div class="landing-summary-card landing-reveal-item"><strong>' + escapeHtml(value) + '</strong><span>' + escapeHtml(label) + '</span></div>';
  }

  function renderLandingFooter() {
    const platformName = escapeHtml(String((state.platformSettings && state.platformSettings.platformName) || 'IELTSLab'));
    return '<footer class="landing-footer landing-reveal" data-reveal="section">' +
      '<div class="landing-footer__inner">' +
        '<div class="landing-footer__copy landing-reveal" data-reveal="copy">' +
          '<span class="eyebrow landing-eyebrow landing-eyebrow--sky landing-reveal-item">Ready when you are</span>' +
          renderAnimatedHeadline('h2', 'See the public product story first. Enter the full workspace second.', 'landing-footer__headline') +
          '<p class="landing-reveal-item">That was the main behavioral change you asked for at the root URL. The landing page now explains the platform, and the platform itself remains one click away.</p>' +
        '</div>' +
        '<div class="landing-footer__actions landing-reveal" data-reveal="copy">' +
          '<div class="button-row landing-reveal-item">' +
            (state.user ? '<button class="btn btn-primary" type="button" data-action="open-app">Open dashboard</button><button class="btn btn-secondary" type="button" data-action="logout">Sign out</button>' : '<button class="btn btn-primary" type="button" data-action="show-auth" data-mode="signup">Create account</button><button class="btn btn-secondary" type="button" data-action="show-auth" data-mode="login">Log in</button>') +
          '</div>' +
          '<div class="landing-footer__meta landing-reveal-item"><span>Shared-hosting PHP backend</span><span>Gemini-powered feedback</span><span>Student and admin apps separated cleanly</span></div>' +
        '</div>' +
      '</div>' +
      '<div class="landing-footer__legal landing-reveal-item"><span>&copy; 2026 ' + platformName + '</span><span>Powered by <a href="https://devlukas.com" target="_blank" rel="noreferrer">devlukas.com</a></span></div>' +
    '</footer>';
  }

  function renderAuthCard(isSignup) {
    if (state.user) {
      return '<section class="auth-panel landing-reveal" data-reveal="copy">' +
        '<div class="auth-card auth-card--welcome">' +
          '<span class="eyebrow landing-eyebrow landing-eyebrow--teal">Signed in</span>' +
          renderAnimatedHeadline('h2', 'Welcome back, ' + (state.user.name || 'there') + '.', 'landing-auth__headline') +
          '<p class="landing-reveal-item">Your session is active locally. The root page now stays public first, and you can enter the product when you want.</p>' +
          '<div class="button-row landing-reveal-item">' +
            '<button class="btn btn-primary" type="button" data-action="open-app">Open dashboard</button>' +
            '<button class="btn btn-secondary" type="button" data-action="logout">Sign out</button>' +
          '</div>' +
        '</div>' +
      '</section>';
    }

    return '<section class="auth-panel landing-reveal" data-reveal="copy">' +
      '<div class="auth-card">' +
        '<div class="auth-toggle">' +
          '<button type="button" class="' + (isSignup ? '' : 'is-active') + '" data-action="switch-auth" data-mode="login">Log in</button>' +
          '<button type="button" class="' + (isSignup ? 'is-active' : '') + '" data-action="switch-auth" data-mode="signup">Sign up</button>' +
        '</div>' +
        renderAnimatedHeadline('h2', isSignup ? 'Create your workspace' : 'Welcome back', 'landing-auth__headline') +
        '<p class="landing-reveal-item">' + (isSignup ? 'Create a real account stored by the shared-hosting PHP backend.' : 'Sign in to your saved IELTSLab workspace and continue where you left off.') + '</p>' +
        '<form data-form="auth">' +
          '<input type="hidden" name="mode" value="' + (isSignup ? 'signup' : 'login') + '">' +
          '<div class="form-grid">' +
            (isSignup ? '<div><label class="field-label" for="name">Full name</label><input class="input" id="name" name="name" placeholder="Brian Mawira"></div>' : '') +
            '<div><label class="field-label" for="email">Email</label><input class="input" id="email" name="email" type="email" placeholder="brian@ieltslab.ai"></div>' +
            '<div><label class="field-label" for="password">Password</label><input class="input" id="password" name="password" type="password" placeholder="Enter password"></div>' +
          '</div>' +
          '<div class="button-row">' +
            '<button class="btn btn-primary" type="submit"' + (state.authStatus === 'submitting' ? ' disabled' : '') + '>' + (state.authStatus === 'submitting' ? 'Please wait...' : (isSignup ? 'Create account' : 'Log in')) + '</button>' +
          '</div>' +
        '</form>' +
        (state.authError ? '<div class="auth-error">' + escapeHtml(state.authError) + '</div>' : '') +
        '<p class="auth-note">Accounts use PHP sessions and file-based storage. For local testing, run the site through PHP instead of opening the HTML file directly.</p>' +
      '</div>' +
    '</section>';
  }

  function teardownLandingExperience() {
    if (landingObserver) {
      landingObserver.disconnect();
      landingObserver = null;
    }

    if (landingMotionCleanup) {
      landingMotionCleanup();
      landingMotionCleanup = null;
    }
  }

  function setupLandingExperience() {
    teardownLandingExperience();

    const root = document.querySelector('.landing-shell');
    if (!root) return;

    const revealNodes = root.querySelectorAll('[data-reveal]');

    if (!('IntersectionObserver' in window)) {
      revealNodes.forEach(function (node) {
        node.classList.add('is-visible');
      });
      return;
    }

    landingObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          landingObserver.unobserve(entry.target);
        }
      });
    }, {
      threshold: 0.18,
      rootMargin: '0px 0px -10% 0px'
    });

    revealNodes.forEach(function (node) {
      if (!node.classList.contains('is-visible')) {
        landingObserver.observe(node);
      }
    });

    landingMotionCleanup = setupLandingMotion(root);
  }

  function setupLandingMotion(root) {
    const motionNodes = Array.from(root.querySelectorAll('[data-parallax-depth]'));
    const motionPreference = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : null;
    let frame = 0;

    if (!motionNodes.length) {
      return null;
    }

    function resetMotion() {
      motionNodes.forEach(function (node) {
        node.style.removeProperty('--parallax-shift-x');
        node.style.removeProperty('--parallax-shift-y');
        node.style.removeProperty('--parallax-rotate-x');
        node.style.removeProperty('--parallax-rotate-y');
      });
    }

    function updateMotion() {
      frame = 0;

      if ((motionPreference && motionPreference.matches) || window.innerWidth < 900) {
        resetMotion();
        return;
      }

      const viewportHeight = window.innerHeight || 1;
      const viewportWidth = window.innerWidth || 1;

      motionNodes.forEach(function (node) {
        const rect = node.getBoundingClientRect();
        const centerY = rect.top + (rect.height / 2);
        const centerX = rect.left + (rect.width / 2);
        const verticalProgress = ((viewportHeight / 2) - centerY) / viewportHeight;
        const horizontalProgress = ((viewportWidth / 2) - centerX) / viewportWidth;
        const depth = parseFloat(node.getAttribute('data-parallax-depth') || '0');
        const horizontalDepth = parseFloat(node.getAttribute('data-parallax-horizontal') || String(depth * 0.5));
        const shiftY = verticalProgress * depth * 160;
        const shiftX = horizontalProgress * horizontalDepth * 120;

        node.style.setProperty('--parallax-shift-x', shiftX.toFixed(2) + 'px');
        node.style.setProperty('--parallax-shift-y', shiftY.toFixed(2) + 'px');

        if (node.hasAttribute('data-parallax-tilt')) {
          node.style.setProperty('--parallax-rotate-x', (verticalProgress * depth * -14).toFixed(2) + 'deg');
          node.style.setProperty('--parallax-rotate-y', (horizontalProgress * depth * 18).toFixed(2) + 'deg');
        }
      });
    }

    function requestMotionUpdate() {
      if (frame) return;
      frame = window.requestAnimationFrame(updateMotion);
    }

    requestMotionUpdate();
    window.addEventListener('scroll', requestMotionUpdate, { passive: true });
    window.addEventListener('resize', requestMotionUpdate);

    if (motionPreference) {
      if (motionPreference.addEventListener) {
        motionPreference.addEventListener('change', requestMotionUpdate);
      } else if (motionPreference.addListener) {
        motionPreference.addListener(requestMotionUpdate);
      }
    }

    return function cleanupLandingMotion() {
      if (frame) {
        window.cancelAnimationFrame(frame);
        frame = 0;
      }

      window.removeEventListener('scroll', requestMotionUpdate);
      window.removeEventListener('resize', requestMotionUpdate);

      if (motionPreference) {
        if (motionPreference.removeEventListener) {
          motionPreference.removeEventListener('change', requestMotionUpdate);
        } else if (motionPreference.removeListener) {
          motionPreference.removeListener(requestMotionUpdate);
        }
      }

      resetMotion();
    };
  }

  function renderShell() {
    const metrics = getCatalogMetrics();
    return (
      '<div class="screen-shell shell">' +
        '<aside class="sidebar">' +
          '<div class="sidebar-top">' +
            renderBrand() +
            '<nav><ul class="nav-list">' + getNavItems().map(function (item) {
              return '<li><button type="button" class="nav-button ' + (state.view === item.id ? 'is-active' : '') + '" data-route="' + item.id + '">' + icon(item.icon, 'nav-icon') + '<span>' + item.label + '</span></button></li>';
            }).join('') + '</ul></nav>' +
          '</div>' +
          '<div class="sidebar-bottom">' +
            '<div class="focus-fab">' +
              '<button type="button" class="focus-fab-trigger" aria-haspopup="true">Focus Sound</button>' +
              '<div class="focus-fab-panel">' +
                '<h3>Focus Sound</h3>' +
                '<p>Hover here and pick an ambient loop for study sessions.</p>' +
                '<div class="sound-list">' + FOCUS_SOUNDS.map(function (sound) {
                  return '<button type="button" class="sound-button ' + (state.settings.focusSound === sound ? 'is-active' : '') + '" data-action="set-focus" data-sound="' + sound + '">' + sound + '</button>';
                }).join('') + '</div>' +
                '<div class="focus-controls">' +
                  '<button type="button" class="btn btn-secondary focus-control-button" data-action="toggle-focus-sound"' + (state.focusAudioStatus === 'unsupported' ? ' disabled' : '') + '>' + (focusAudio.isPlaying() ? 'Pause sound' : 'Play sound') + '</button>' +
                  '<button type="button" class="btn btn-ghost focus-control-button" data-action="stop-focus-sound"' + (!focusAudio.isPlaying() ? ' disabled' : '') + '>Stop</button>' +
                '</div>' +
                '<div class="focus-status">' + renderFocusSoundStatus() + '</div>' +
              '</div>' +
            '</div>' +
            '<div class="sidebar-actions">' +
              '<div class="sidebar-action-row">' +
                '<button type="button" class="sidebar-action" data-route="profile">' + icon('settings', 'action-icon') + '<span>Settings</span></button>' +
                '<button type="button" class="sidebar-icon-action" data-action="toggle-theme" aria-label="Switch to ' + escapeAttr(state.settings.theme === 'dark' ? 'light' : 'dark') + ' theme" title="Switch to ' + escapeAttr(state.settings.theme === 'dark' ? 'light' : 'dark') + ' theme">' + icon(state.settings.theme === 'dark' ? 'sun' : 'moon', 'action-icon') + '</button>' +
              '</div>' +
              '<button type="button" class="sidebar-action" data-action="logout">' + icon('logout', 'action-icon') + '<span>Sign out</span></button>' +
            '</div>' +
          '</div>' +
        '</aside>' +
        '<main class="workspace">' +
          '<div class="workspace-inner">' +
            '<header class="topbar">' +
              '<div class="page-copy">' +
                '<span class="eyebrow" style="background: rgba(57, 216, 208, 0.12); color: var(--teal-dark);">' + escapeHtml(getViewEyebrow()) + '</span>' +
                '<h1>' + escapeHtml(getViewTitle()) + '</h1>' +
                '<p>' + escapeHtml(getViewDescription(metrics)) + '</p>' +
              '</div>' +
              '<div class="topbar-tools">' +
                '<button type="button" class="chip" data-route="profile">' + icon('spark', 'stat-icon') + escapeHtml(state.user.plan) + ' plan</button>' +
                '<span class="pill">' + escapeHtml(String(metrics.totalResources)) + ' resources available</span>' +
              '</div>' +
            '</header>' +
            renderView(metrics) +
          '</div>' +
        '</main>' +
        (state.leaveSectionConfirmOpen ? renderLeaveSectionModal() : '') +
      '</div>'
    );
  }

  function renderLeaveSectionModal() {
    var fromView = state.leaveSectionFromView || 'section';
    var fromLabel = capitalize(fromView);
    return '<div class="writing-studio-backdrop" data-action="cancel-leave-section"><div class="writing-studio-modal leave-section-modal" data-stop-click="true">' +
      '<button type="button" class="writing-studio-close" data-action="cancel-leave-section" aria-label="Close warning">&#215;</button>' +
      '<div class="writing-studio-header leave-section-header">' +
        '<span class="writing-studio-kicker">Confirm navigation</span>' +
        '<h2 class="writing-studio-title">Leave ' + escapeHtml(fromLabel) + ' section?</h2>' +
        '<p class="writing-studio-subtitle">You may lose unsaved progress in this section. Are you sure you want to return to the dashboard?</p>' +
      '</div>' +
      '<div class="button-row leave-section-actions">' +
        '<button class="btn btn-secondary" type="button" data-action="cancel-leave-section">Stay here</button>' +
        '<button class="btn btn-primary" type="button" data-action="confirm-leave-section">Go to dashboard</button>' +
      '</div>' +
    '</div></div>';
  }

  function renderView(metrics) {
    switch (state.view) {
      case 'dashboard':
        return renderDashboard(metrics);
      case 'practice':
        return renderPractice(metrics);
      case 'writing':
      case 'reading':
      case 'listening':
      case 'speaking':
        return renderSkillPage(state.view, metrics);
      case 'library':
        return renderLibrary();
      case 'progress':
        return renderProgress(metrics);
      case 'profile':
        return renderProfile();
      case 'plans':
        return renderPlans();
      default:
        return renderDashboard(metrics);
    }
  }

  function renderDashboard(metrics) {
    const user = state.user;
    const activeSkills = countActiveSkills(user.progress.skills);
    const progressPercent = Math.min(100, Math.round((user.progress.minutesToday / user.studyGoalMinutes) * 100));

    return (
      '<section class="dashboard-hero">' +
        '<h1>Welcome back, ' + escapeHtml(user.name) + '</h1>' +
        '<p>Track your progress, move through guided IELTS sections, and use the existing content library inside a cleaner product dashboard.</p>' +
        '<div class="hero-meta">' +
          '<span class="hero-pill">Target band ' + escapeHtml(String(user.goalBand)) + '</span>' +
          '<span class="hero-pill">Focus sound: ' + escapeHtml(state.settings.focusSound) + '</span>' +
          '<span class="hero-pill">Mock tests: 2 free in starter mode</span>' +
        '</div>' +
      '</section>' +
      '<div class="stats-grid">' +
        renderStatCard('Overall Band', formatBand(user.progress.overallBand), 'Current score estimate', 'teal', 'target') +
        renderStatCard('Target', String(user.goalBand), 'Band goal', 'orange', 'flame') +
        renderStatCard('Sessions', String(user.progress.sessions), 'Total study sessions', 'violet', 'clock') +
        renderStatCard('Skills Active', activeSkills + '/4', 'Sections in progress', 'gold', 'trend') +
      '</div>' +
      '<div class="study-card">' +
        '<div class="study-head"><strong>Today\'s Study</strong><span class="muted-label">Goal: ' + escapeHtml(String(user.studyGoalMinutes)) + ' min</span></div>' +
        '<div class="study-progress">' +
          '<div class="study-ring" style="--progress:' + progressPercent + '%"><div><strong>' + escapeHtml(String(user.progress.minutesToday)) + '</strong><span>min</span></div></div>' +
          '<div><div class="progress-bar"><div class="progress-fill" style="width:' + progressPercent + '%"></div></div><div class="study-meta"><span>' + escapeHtml(String(user.progress.streak)) + ' day streak</span><span>' + escapeHtml(String(user.progress.minutesToday)) + '/' + escapeHtml(String(user.studyGoalMinutes)) + ' min</span></div></div>' +
        '</div>' +
      '</div>' +
      '<div class="section-heading">Practice</div>' +
      '<div class="practice-grid">' +
        renderPracticeCard('writing', 'Writing', 'Task 1 & Task 2 essays with AI-style feedback surfaces.', formatBand(user.progress.skills.writing.band), user.progress.skills.writing.status) +
        renderPracticeCard('reading', 'Reading', 'Academic and General Training flow, timers, and analysis cards.', formatBand(user.progress.skills.reading.band), user.progress.skills.reading.status) +
        renderPracticeCard('listening', 'Listening', 'AI generates fresh audio, objective questions, and instant score feedback on entry.', formatBand(user.progress.skills.listening.band), user.progress.skills.listening.status) +
        renderPracticeCard('speaking', 'Speaking', 'AI examiner and speaking partner experiences for Parts 1 to 3.', formatBand(user.progress.skills.speaking.band), user.progress.skills.speaking.status) +
      '</div>' +
      '<div class="two-column">' +
        '<div class="activity-card"><div class="activity-head"><h3>Recent Activity</h3><span class="muted-label">Local session history</span></div>' + renderActivityList() + '</div>' +
        '<div class="panel-card"><h3>Resource Snapshot</h3><p>The original IELTS content is still wired in, but it now sits behind product-style sections instead of a plain file tree.</p><ul class="metric-list"><li>' + escapeHtml(String(metrics.listeningBooks)) + ' Cambridge listening books grouped for audio practice.</li><li>' + escapeHtml(String(metrics.readingTests)) + ' reading PDFs currently available in the repo.</li><li>' + escapeHtml(String(metrics.writingSamples)) + ' writing samples and ' + escapeHtml(String(metrics.writingMaterials)) + ' writing materials ready in the library.</li></ul><div class="panel-footer"><button class="btn btn-secondary" type="button" data-route="library">Open library</button><button class="btn btn-ghost" type="button" data-route="practice">Explore practice</button></div></div>' +
      '</div>'
    );
  }

  function renderPractice(metrics) {
    return (
      '<div class="mode-grid">' +
        renderModeCard('Full Mock Exam', 'Take a realistic IELTS-style flow across Listening, Reading, Writing, and Speaking with section timers and AI-backed section generation.', 'dashboard', 'practice') +
        renderModeCard('AI Speaking Examiner', 'Part 1, Part 2, and Part 3 cards with follow-up prompts, fluency review, and pronunciation feedback placeholders.', 'speaking', 'speaking') +
        renderModeCard('AI Speaking Partner', 'Friend, interviewer, and debate-partner roles for spontaneous practice and conversational confidence.', 'spark', 'speaking') +
        renderModeCard('Writing Review Studio', 'Task 1 and Task 2 flows with category scoring, corrections, and model-answer guidance.', 'writing', 'writing') +
      '</div>' +
      renderPracticePlansPreview() +
      '<div class="metrics-grid">' +
        renderMetricsCard('Mock Exam Flow', '4 sections', 'Listening, Reading, Writing, and Speaking structured like an exam journey.') +
        renderMetricsCard('Question Bank', String(metrics.totalResources), 'Current repo resources that can back the library and practice screens.') +
        renderMetricsCard('Progress Signals', 'Band + trend', 'Target band, sessions, streak, and section status are tracked locally.') +
      '</div>' +
      renderMockExamPanel()
    );
  }

  function renderPracticePlansPreview() {
    if (state.plansStatus === 'loading') {
      return '<div class="empty-card">Loading plans...</div>';
    }
    const plans = state.plansData || [];
    if (!plans.length) {
      return '<div class="empty-card">No plans configured yet. <button type="button" class="btn btn-secondary" data-action="show-plans">View plans</button></div>';
    }
    return (
      '<div class="plan-grid">' +
        plans.map(function (plan) {
          const isCurrent = (plan.name || '').toLowerCase() === (state.user && state.user.plan ? state.user.plan.toLowerCase() : '');
          const isFree = Number(plan.price || 0) === 0;
          return (
            '<div class="plan-card' + (isCurrent ? ' is-highlighted' : '') + '">' +
              '<h3>' + escapeHtml(plan.name || 'Plan') + (isCurrent ? ' <span class="pill pill-success">Current</span>' : '') + '</h3>' +
              '<p>' + escapeHtml(plan.description || '') + '</p>' +
              '<div class="plan-price">' + (isFree ? 'Free' : '$' + escapeHtml(String(plan.price))) + (isFree ? '' : ' <span>/ ' + escapeHtml(plan.interval || 'month') + '</span>') + '</div>' +
              '<ul class="mini-list">' + (plan.features || []).map(function (f) { return '<li>' + escapeHtml(f) + '</li>'; }).join('') + '</ul>' +
              '<div class="panel-footer"><button type="button" class="btn ' + (isCurrent ? 'btn-secondary' : 'btn-primary') + '" data-action="show-plans">' + (isCurrent ? 'Manage subscription' : 'Get started') + '</button></div>' +
            '</div>'
          );
        }).join('') +
      '</div>'
    );
  }

  function renderSkillPage(skill, metrics) {
    const config = getSkillConfig(skill, metrics);
    const introOverlay = (skill === 'writing' && state.writingIntroOpen) ? renderWritingIntroOverlay(config) :
      (skill === 'reading' && state.readingIntroOpen) ? renderReadingIntroOverlay(config) :
      (skill === 'listening' && state.listeningIntroOpen) ? renderListeningIntroOverlay(config) :
      (skill === 'speaking' && state.speakingIntroOpen) ? renderSpeakingIntroOverlay(config) : '';
    const introPanels = (skill === 'writing' || skill === 'reading' || skill === 'listening' || skill === 'speaking') ? '' : (
      '<div class="two-column">' +
        '<div class="panel-card"><h3>' + escapeHtml(config.title) + '</h3><p>' + escapeHtml(config.summary) + '</p><ul class="mini-list">' + config.features.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul><div class="button-row"><button class="btn btn-primary" type="button" data-action="start-practice" data-skill="' + skill + '">Start ' + escapeHtml(config.cta) + '</button><button class="btn btn-secondary" type="button" data-route="library" data-category="' + skill + '">Open library</button></div></div>' +
        '<div class="panel-card"><h3>Evaluation Surface</h3><p>' + escapeHtml(config.evaluationIntro) + '</p><ul class="feedback-list">' + config.evaluation.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul></div>' +
      '</div>'
    );
    const readingPanel = skill === 'reading' ? renderReadingPanel() : '';
    const writingPanel = skill === 'writing' ? renderWritingPanel() : '';
    const aiPanel = skill === 'listening' && listeningAI && state.aiListening ? listeningAI.renderPanel(state.aiListening) : '';
    const speakingPanel = skill === 'speaking' && speakingAI && state.aiSpeaking ? speakingAI.renderPanel(state.aiSpeaking, { goalBand: state.user.goalBand }) : '';
    const listeningLibraryPanel = skill === 'listening' ? renderListeningLibraryPanel() : '';
    return (
      introPanels +
      writingPanel +
      readingPanel +
      aiPanel +
      listeningLibraryPanel +
      speakingPanel +
      '<div class="feature-grid">' + config.cards.map(function (card) {
        return '<div class="feature-card"><div class="card-head"><div class="metric-badge accent-' + card.accent + '">' + icon(card.icon, 'metric-icon') + '</div><span class="micro-kicker">' + escapeHtml(card.kicker) + '</span></div><h3>' + escapeHtml(card.title) + '</h3><p>' + escapeHtml(card.text) + '</p></div>';
      }).join('') + '</div>' +
      '<div class="resource-grid">' + getResourcePreview(skill) + '</div>' +
      introOverlay
    );
  }

  function renderListeningIntroOverlay(config) {
    return '<div class="writing-studio-backdrop" data-action="close-listening-intro"><div class="writing-studio-modal" data-stop-click="true">' +
      '<button type="button" class="writing-studio-close" data-action="close-listening-intro" aria-label="Close listening intro">&#215;</button>' +
      '<div class="writing-studio-header">' +
        '<span class="writing-studio-kicker">Listening Practice</span>' +
        '<h2 class="writing-studio-title">Start your listening session</h2>' +
        '<p class="writing-studio-subtitle">' + escapeHtml(config.summary) + '</p>' +
      '</div>' +
      '<div class="two-column">' +
        '<div class="panel-card"><h3>What\'s included</h3><ul class="mini-list">' + config.features.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul><div class="button-row"><button class="btn btn-primary" type="button" data-action="start-practice" data-skill="listening">Start session</button><button class="btn btn-secondary" type="button" data-route="library" data-category="listening">Open library</button></div></div>' +
        '<div class="panel-card"><h3>Evaluation Surface</h3><p>' + escapeHtml(config.evaluationIntro) + '</p><ul class="feedback-list">' + config.evaluation.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul></div>' +
      '</div>' +
    '</div></div>';
  }

  function renderSpeakingIntroOverlay(config) {
    return '<div class="writing-studio-backdrop" data-action="close-speaking-intro"><div class="writing-studio-modal" data-stop-click="true">' +
      '<button type="button" class="writing-studio-close" data-action="close-speaking-intro" aria-label="Close speaking intro">&#215;</button>' +
      '<div class="writing-studio-header">' +
        '<span class="writing-studio-kicker">Speaking Lab</span>' +
        '<h2 class="writing-studio-title">Start your speaking session</h2>' +
        '<p class="writing-studio-subtitle">' + escapeHtml(config.summary) + '</p>' +
      '</div>' +
      '<div class="two-column">' +
        '<div class="panel-card"><h3>What\'s included</h3><ul class="mini-list">' + config.features.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul><div class="button-row"><button class="btn btn-primary" type="button" data-action="start-practice" data-skill="speaking">Start session</button><button class="btn btn-secondary" type="button" data-route="library" data-category="speaking">Open library</button></div></div>' +
        '<div class="panel-card"><h3>Evaluation Surface</h3><p>' + escapeHtml(config.evaluationIntro) + '</p><ul class="feedback-list">' + config.evaluation.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul></div>' +
      '</div>' +
    '</div></div>';
  }

  function renderReadingIntroOverlay(config) {
    return '<div class="writing-studio-backdrop" data-action="close-reading-intro"><div class="writing-studio-modal" data-stop-click="true">' +
      '<button type="button" class="writing-studio-close" data-action="close-reading-intro" aria-label="Close reading intro">&#215;</button>' +
      '<div class="writing-studio-header">' +
        '<span class="writing-studio-kicker">Reading Practice</span>' +
        '<h2 class="writing-studio-title">Start your reading session</h2>' +
        '<p class="writing-studio-subtitle">' + escapeHtml(config.summary) + '</p>' +
      '</div>' +
      '<div class="two-column">' +
        '<div class="panel-card"><h3>What\'s included</h3><ul class="mini-list">' + config.features.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul><div class="button-row"><button class="btn btn-primary" type="button" data-action="start-practice" data-skill="reading">Start session</button><button class="btn btn-secondary" type="button" data-route="library" data-category="reading">Open library</button></div></div>' +
        '<div class="panel-card"><h3>Evaluation Surface</h3><p>' + escapeHtml(config.evaluationIntro) + '</p><ul class="feedback-list">' + config.evaluation.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul></div>' +
      '</div>' +
    '</div></div>';
  }

  function renderWritingIntroOverlay(config) {
    return '<div class="writing-studio-backdrop" data-action="close-writing-intro"><div class="writing-studio-modal" data-stop-click="true">' +
      '<button type="button" class="writing-studio-close" data-action="close-writing-intro" aria-label="Close writing intro">&#215;</button>' +
      '<div class="writing-studio-header">' +
        '<span class="writing-studio-kicker">Writing Studio</span>' +
        '<h2 class="writing-studio-title">Start your writing session</h2>' +
        '<p class="writing-studio-subtitle">' + escapeHtml(config.summary) + '</p>' +
      '</div>' +
      '<div class="two-column">' +
        '<div class="panel-card"><h3>What\'s included</h3><ul class="mini-list">' + config.features.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul><div class="button-row"><button class="btn btn-primary" type="button" data-action="start-practice" data-skill="writing">Start session</button><button class="btn btn-secondary" type="button" data-route="library" data-category="writing">Open library</button></div></div>' +
        '<div class="panel-card"><h3>Evaluation Surface</h3><p>' + escapeHtml(config.evaluationIntro) + '</p><ul class="feedback-list">' + config.evaluation.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul></div>' +
      '</div>' +
    '</div></div>';
  }

  function renderLibrary() {
    const items = getLibraryItems();
    const selected = items.find(function (item) {
      return item.path === state.selectedPath;
    });

    return (
      '<div class="library-layout">' +
        '<aside class="library-panel">' +
          '<h3>Resource Library</h3><p>Browse the existing IELTS files through cleaner categories instead of the old raw sidebar.</p>' +
          '<div class="library-search"><input class="input" data-model="library-search" placeholder="Search resources" value="' + escapeAttr(state.librarySearch) + '"></div>' +
          '<div class="tag-list">' + LIBRARY_CATEGORIES.map(function (category) {
            return '<button type="button" class="tag-button ' + (category === 'listening' ? 'tag-button--listening ' : '') + (state.libraryCategory === category ? 'is-active' : '') + '" data-action="select-category" data-category="' + category + '">' + escapeHtml(capitalize(category)) + '</button>';
          }).join('') + '</div>' +
          '<div class="library-list">' + (items.length ? items.map(function (item) {
            return '<button type="button" class="list-link ' + (state.selectedPath === item.path ? 'is-active' : '') + '" data-action="select-path" data-path="' + escapeAttr(item.path) + '"><div class="list-link-copy"><div class="list-link-top"><span class="library-item-marker accent-' + getAccent(item.section) + '">' + escapeHtml(item.sectionLabel) + '</span></div><strong>' + escapeHtml(item.label) + '</strong><span class="list-meta">' + escapeHtml(item.meta) + '</span></div></button>';
          }).join('') : '<div class="library-empty">No resources match this filter yet.</div>') + '</div>' +
        '</aside>' +
        '<section class="library-panel">' +
          '<div class="resource-head"><div><h3>' + (selected ? escapeHtml(selected.label) : 'Select a resource') + '</h3><div class="resource-meta">' + (selected ? escapeHtml(selected.meta) : 'Choose any file from the library list.') + '</div></div><span class="pill">' + (selected ? escapeHtml(selected.sectionLabel) : 'Preview') + '</span></div>' +
          '<div class="library-preview-body preview-frame" id="library-preview-body">' + (selected ? '' : '<div class="preview-placeholder-panel">Select a resource to open the built-in PDF, audio, image, or markdown preview.</div>') + '</div>' +
        '</section>' +
      '</div>'
    );
  }

  function renderListeningLibraryPanel() {
    const catalog = state.catalog || { listening: { audioByBook: {}, audio: [] } };
    const groups = catalog.listening && catalog.listening.audioByBook ? catalog.listening.audioByBook : {};
    const groupNames = Object.keys(groups).slice(0, 3);
    const items = [];

    groupNames.forEach(function (groupName) {
      (groups[groupName] || []).slice(0, 2).forEach(function (filePath) {
        items.push({
          group: groupName,
          path: filePath,
          label: getFileName(filePath)
        });
      });
    });

    if (!items.length) {
      return '';
    }

    return (
      '<section class="panel-card">' +
        '<div class="card-head"><div><h3>Existing Listening Library</h3><p>Use the original Cambridge listening files from the repo whenever you want a stable audio source alongside the AI-generated tests.</p></div><span class="pill pill--audio">Repo audio</span></div>' +
        '<div class="resource-grid">' + items.map(function (item) {
          const audioUrl = BASE_PATH + encodeURI(item.path);
          return '<article class="resource-card"><div class="resource-head"><div class="resource-badge accent-teal">' + icon('listening', 'resource-icon') + '</div><span class="resource-meta">' + escapeHtml(item.group) + '</span></div><h3>' + escapeHtml(item.label) + '</h3><audio class="preview-audio" controls preload="metadata" src="' + escapeAttr(audioUrl) + '"></audio><div class="resource-footer"><button type="button" class="btn btn-secondary" data-action="open-listening-library-item" data-path="' + escapeAttr(item.path) + '">Open in library</button></div></article>';
        }).join('') + '</div>' +
        '<div class="button-row"><button class="btn btn-secondary" type="button" data-route="library" data-category="listening">Browse full listening library</button></div>' +
      '</section>'
    );
  }

  function renderProgress(metrics) {
    return (
      '<div class="metrics-grid">' +
        renderMetricsCard('Overall Trend', formatBand(state.user.progress.overallBand), 'Current overall estimate stored in your profile state.') +
        renderMetricsCard('Membership', state.user.plan, 'Current access level returned by the authenticated session.') +
        renderMetricsCard('Weekly Streak', String(state.user.progress.streak) + ' days', 'Keeps the dashboard aligned with the product-style motivation loop.') +
        renderMetricsCard('Resources Opened', String(getActivities().length), 'Recent actions recorded from practice starts and library previews.') +
      '</div>' +
      '<div class="two-column">' +
        '<div class="panel-card"><h3>Skill Progress</h3><p>Each section has its own band target and in-progress state. This mirrors the progress-tracking requirement from the spec.</p>' + renderSkillProgressRows() + '</div>' +
        '<div class="panel-card"><h3>Product Readiness Snapshot</h3><ul class="metric-list"><li>Authentication, sessions, and profile storage now run through PHP.</li><li>Library reuses ' + escapeHtml(String(metrics.totalResources)) + ' repo-backed resources.</li><li>Listening, speaking, reading, writing, and mock exam sessions now call the backend; payments remain admin-only for now.</li></ul></div>' +
      '</div>'
    );
  }

  function renderReadingPanel() {
    const reading = state.aiReading;
    const session = reading.session;
    const result = reading.result;
    return (
      '<section class="panel-card flow-panel">' +
        '<div class="card-head"><div><h3>AI Reading Generator</h3><p>Generate a fresh passage with objective questions, then submit answers for instant scoring.</p></div><span class="pill">Backend live</span></div>' +
        '<form data-form="ai-reading-generate"><div class="form-grid"><div><label class="field-label">Target band</label><input class="input" name="targetBand" type="number" min="4" max="9" step="0.5" value="' + escapeAttr(String(state.user.goalBand || 6.5)) + '"></div><div><label class="field-label">Question count</label><input class="input" name="questionCount" type="number" min="6" max="12" step="1" value="8"></div><div><label class="field-label">Theme</label><input class="input" name="theme" value="academic article"></div></div><div class="button-row"><button class="btn btn-primary" type="submit"' + (reading.status === 'generating' ? ' disabled' : '') + '>' + (reading.status === 'generating' ? 'Generating...' : 'Generate reading test') + '</button></div></form>' +
        (reading.error ? '<div class="auth-error">' + escapeHtml(reading.error) + '</div>' : '') +
        (session ? renderReadingSession(session, result, reading.status) : '<div class="empty-card">No reading passage yet. Generate one above to begin.</div>') +
      '</section>'
    );
  }

  function renderReadingSession(session, result, status) {
    return '<div class="flow-stack"><div class="panel-card panel-card--nested"><div class="card-head"><div><h3>' + escapeHtml(session.testTitle || 'Reading passage') + '</h3><p>' + escapeHtml(session.theme || 'Academic article') + '</p></div><span class="pill">' + escapeHtml(String(session.questionCount || (session.questions || []).length)) + ' questions</span></div><div class="reading-passage">' + escapeHtml(session.passage || '') + '</div></div><form class="panel-card panel-card--nested" data-form="ai-reading-answers"><h3>Answer Sheet</h3><div class="form-grid form-grid--single">' + (session.questions || []).map(function (question) { return renderReadingQuestion(question); }).join('') + '</div><div class="button-row"><button class="btn btn-primary" type="submit"' + (status === 'scoring' ? ' disabled' : '') + '>' + (status === 'scoring' ? 'Scoring...' : 'Submit answers') + '</button></div></form>' + (result ? renderReadingResult(result) : '') + '</div>';
  }

  function renderReadingQuestion(question) {
    return '<div class="reading-question"><div class="metric-row"><strong>Q' + escapeHtml(String(question.number || '')) + '</strong><span class="pill">' + escapeHtml(question.typeLabel || question.type || 'Question') + '</span></div><p>' + escapeHtml(question.prompt || '') + '</p>' + renderReadingQuestionInput(question) + '</div>';
  }

  function renderReadingQuestionInput(question) {
    const options = Array.isArray(question.options) ? question.options.filter(Boolean) : [];
    if (!options.length) {
      return '<input class="input" name="answer-' + escapeAttr(String(question.number || '')) + '" placeholder="Type your answer">';
    }
    return '<div class="choice-list">' + options.map(function (option) {
      return '<label class="choice-option"><input type="radio" name="answer-' + escapeAttr(String(question.number || '')) + '" value="' + escapeAttr(option) + '"><span>' + escapeHtml(option) + '</span></label>';
    }).join('') + '</div>';
  }

  function renderReadingResult(result) {
    return '<div class="panel-card panel-card--nested"><div class="card-head"><div><h3>Reading Score</h3><p>Immediate objective result from the generated answer key.</p></div><span class="pill">Band ' + escapeHtml(String(result.bandScore || '--')) + '</span></div><div class="metrics-grid metrics-grid--compact">' + renderMetricsCard('Raw score', String(result.rawScore || 0), 'Correct answers') + renderMetricsCard('Incorrect', String(result.incorrectCount || 0), 'Questions missed') + renderMetricsCard('Total', String(result.totalQuestions || 0), 'Questions in this test') + '</div><div class="flow-stack">' + (result.questionResults || []).map(function (item) {
      return '<div class="result-row"><div class="metric-row"><strong>Q' + escapeHtml(String(item.number || '')) + '</strong><span class="pill ' + (item.isCorrect ? 'pill-success' : 'pill-danger') + '">' + (item.isCorrect ? 'Correct' : 'Review') + '</span></div><p><strong>Your answer:</strong> ' + escapeHtml(String(item.userAnswer || '--')) + '</p><p><strong>Correct answer:</strong> ' + escapeHtml(String(item.canonicalAnswer || '--')) + '</p><p>' + escapeHtml(String(item.explanation || '')) + '</p></div>';
    }).join('') + '</div></div>';
  }

  function renderWritingPanel() {
    const writing = state.aiWriting;
    return (
      '<section class="panel-card flow-panel">' +
        '<div class="card-head"><div><h3>Writing Evaluation Studio</h3><p>Submit Task 1 or Task 2 responses for Gemini-backed IELTS-style scoring and corrections.</p></div><span class="pill">Backend live</span></div>' +
        '<form data-form="ai-writing-evaluate"><div class="form-grid"><div><label class="field-label">Task type</label><select class="input" name="taskType"><option value="Task 1">Task 1</option><option value="Task 2" selected>Task 2</option></select></div><div><label class="field-label">Target band</label><input class="input" name="targetBand" type="number" min="4" max="9" step="0.5" value="' + escapeAttr(String(state.user.goalBand || 7)) + '"></div></div><div class="form-grid form-grid--single"><div><label class="field-label">Prompt</label><textarea class="textarea" name="prompt" rows="4" placeholder="Paste the IELTS writing question here."></textarea></div><div><label class="field-label">Essay</label><textarea class="textarea" name="essay" rows="12" placeholder="Write or paste the candidate answer here."></textarea></div></div><div class="button-row"><button class="btn btn-primary" type="submit"' + (writing.status === 'evaluating' ? ' disabled' : '') + '>' + (writing.status === 'evaluating' ? 'Evaluating...' : 'Evaluate writing') + '</button></div></form>' +
        (writing.error ? '<div class="auth-error">' + escapeHtml(writing.error) + '</div>' : '') +
        (writing.result ? renderWritingResult(writing.result) : '<div class="empty-card">No writing evaluation yet. Submit a response to receive a band estimate, breakdown, improvements, and a corrected sample.</div>') +
      '</section>'
    );
  }

  function renderWritingResult(result) {
    const breakdown = result.breakdown || {};
    return '<div class="panel-card panel-card--nested"><div class="card-head"><div><h3>Writing Result</h3><p>' + escapeHtml(result.summary || '') + '</p></div><span class="pill">Band ' + escapeHtml(String(result.overallBand || '--')) + '</span></div><div class="metrics-grid metrics-grid--compact">' + renderMetricsCard('Task response', formatBand(breakdown.taskResponse), 'Relevance and development') + renderMetricsCard('Coherence', formatBand(breakdown.coherence), 'Organisation and flow') + renderMetricsCard('Lexical resource', formatBand(breakdown.lexicalResource), 'Vocabulary range') + '</div><div class="metrics-grid metrics-grid--compact">' + renderMetricsCard('Grammar', formatBand(breakdown.grammar), 'Accuracy and range') + renderMetricsCard('Target band', escapeHtml(String(result.targetBand || state.user.goalBand || '--')), 'Requested score') + renderMetricsCard('Task', escapeHtml(result.taskType || 'Task'), 'Essay mode') + '</div><div class="two-column"><div class="panel-card panel-card--nested"><h3>Improvements</h3><ul class="feedback-list">' + (result.improvements || []).map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul></div><div class="panel-card panel-card--nested"><h3>Corrected Sample</h3><div class="writing-sample">' + escapeHtml(result.correctedSample || '') + '</div></div></div></div>';
  }

  function renderMockExamPanel() {
    const exam = state.mockExam;
    const session = exam.session;
    return '<section class="panel-card flow-panel"><div class="card-head"><div><h3>Full Mock Exam</h3><p>Start a four-part session, track section readiness, and save or complete sections through the backend exam APIs.</p></div><span class="pill">Session-based</span></div>' + (!session ? '<div class="button-row"><button class="btn btn-primary" type="button" data-action="start-mock-exam"' + (exam.status === 'starting' ? ' disabled' : '') + '>' + (exam.status === 'starting' ? 'Starting...' : 'Start mock exam') + '</button></div>' : renderMockExamSession(session)) + (exam.error ? '<div class="auth-error">' + escapeHtml(exam.error) + '</div>' : '') + '</section>';
  }

  function renderMockExamSession(session) {
    const currentKey = getMockExamCurrentSectionKey();
    return '<div class="flow-stack"><div class="metrics-grid metrics-grid--compact">' + renderMetricsCard('Session', escapeHtml(session.sessionId || '--'), 'Mock exam identifier') + renderMetricsCard('Target band', escapeHtml(String(session.targetBand || state.user.goalBand || '--')), 'Requested score target') + renderMetricsCard('Status', escapeHtml(session.status || 'active'), 'Overall session state') + '</div><div class="flow-stack">' + (session.sections || []).map(function (section) {
      return '<div class="result-row"><div class="metric-row"><div><strong>' + capitalize(section.key || 'section') + '</strong><div class="muted-label">' + escapeHtml(String(section.durationMinutes || 0)) + ' minutes</div></div><span class="pill ' + getSectionPillClass(section.status) + '">' + escapeHtml(section.status || 'locked') + '</span></div><div class="button-row"><button class="btn btn-secondary" type="button" data-action="open-mock-section" data-section="' + escapeAttr(section.key || '') + '"' + (section.status === 'locked' ? ' disabled' : '') + '>Open section</button><button class="btn btn-ghost" type="button" data-action="save-mock-section" data-section="' + escapeAttr(section.key || '') + '"' + ((section.status === 'locked' || section.status === 'completed') ? ' disabled' : '') + '>Save checkpoint</button><button class="btn btn-primary" type="button" data-action="complete-mock-section" data-section="' + escapeAttr(section.key || '') + '"' + ((section.status === 'locked' || section.status === 'completed') ? ' disabled' : '') + '>Complete section</button></div></div>';
    }).join('') + '</div><div class="panel-card panel-card--nested"><h3>Current ready section</h3><p>' + escapeHtml(capitalize(currentKey || 'listening')) + ' is the next actionable stage for this mock exam.</p></div></div>';
  }

  function renderProfile() {
    const settings = state.settings || loadSettings();
    return (
      '<div class="profile-grid">' +
        '<form class="profile-card profile-card--span-2" data-form="profile"><h3>Profile</h3><div class="form-grid"><div><label class="field-label" for="profile-name">Full name</label><input class="input" id="profile-name" name="name" value="' + escapeAttr(state.user.name) + '"></div><div><label class="field-label" for="profile-email">Email</label><input class="input" id="profile-email" value="' + escapeAttr(state.user.email) + '" disabled></div><div><label class="field-label" for="profile-goal-band">Target band</label><input class="input" id="profile-goal-band" name="goalBand" type="number" min="4" max="9" step="0.5" value="' + escapeAttr(String(state.user.goalBand)) + '"></div><div><label class="field-label" for="profile-study-goal">Daily study goal</label><input class="input" id="profile-study-goal" name="studyGoalMinutes" type="number" min="10" max="240" step="5" value="' + escapeAttr(String(state.user.studyGoalMinutes)) + '"></div></div><div class="button-row"><button class="btn btn-primary" type="submit"' + (state.profileStatus === 'saving' ? ' disabled' : '') + '>' + (state.profileStatus === 'saving' ? 'Saving...' : 'Save profile') + '</button><span class="pill">' + escapeHtml(state.user.plan) + ' plan</span></div>' + (state.profileError ? '<div class="auth-error">' + escapeHtml(state.profileError) + '</div>' : '') + (state.profileMessage ? '<div class="auth-success">' + escapeHtml(state.profileMessage) + '</div>' : '') + '</form>' +
        '<form class="profile-card" data-form="profile"><h3>Study Preferences</h3><div class="form-grid form-grid--single"><div><label class="field-label" for="profile-focus-sound">Focus sound</label><select class="input" id="profile-focus-sound" name="focusSound">' + FOCUS_SOUNDS.map(function (sound) { return '<option value="' + escapeAttr(sound) + '"' + (settings.focusSound === sound ? ' selected' : '') + '>' + escapeHtml(sound) + '</option>'; }).join('') + '</select></div><div><label class="field-label" for="profile-theme">Theme</label><select class="input" id="profile-theme" name="theme"><option value="light"' + (settings.theme === 'light' ? ' selected' : '') + '>Light</option><option value="dark"' + (settings.theme === 'dark' ? ' selected' : '') + '>Dark</option></select></div><div><label class="field-label" for="profile-timezone">Timezone</label><input class="input" id="profile-timezone" name="timezone" value="' + escapeAttr(settings.timezone || 'UTC') + '"></div><label class="checkbox-row"><input type="checkbox" name="dailyReminder"' + (settings.dailyReminder ? ' checked' : '') + '><span>Enable daily reminder</span></label></div><div class="settings-row"><div><strong>Reminder status</strong><div class="muted-label">Saved in backend settings</div></div><span class="toggle ' + (settings.dailyReminder ? 'is-active' : 'is-off') + '"></span></div><div class="button-row"><button class="btn btn-secondary" type="submit"' + (state.profileStatus === 'saving' ? ' disabled' : '') + '>Save preferences</button></div></form>' +
        '<div class="profile-card"><h3>Account Status</h3><div class="metric-row"><span>Email verification</span><strong>' + (state.user.emailVerified ? 'Verified' : 'Pending') + '</strong></div><div class="metric-row"><span>Role</span><strong>' + escapeHtml(state.user.role) + '</strong></div><div class="metric-row"><span>Joined</span><strong>' + escapeHtml(new Date((state.user.joinedAt || Math.floor(Date.now() / 1000)) * 1000).toLocaleDateString()) + '</strong></div>' + (state.user.role === 'admin' ? '<div class="panel-footer"><a class="btn btn-secondary" href="' + escapeAttr(BASE_PATH + 'admin/') + '">Open admin portal</a></div>' : '') + '</div>' +
        '<div class="profile-card"><h3>Plan &amp; Subscription</h3><div class="metric-row"><span>Current plan</span><strong>' + escapeHtml(state.user.plan) + '</strong></div><div class="metric-row"><span>Access level</span><strong>' + (state.user.plan === 'Pro' ? 'Full access' : 'Standard access') + '</strong></div><div class="metric-row"><span>AI features</span><strong>' + (state.user.plan === 'Pro' ? 'Enabled' : 'Limited') + '</strong></div><div class="metric-row"><span>Mock tests</span><strong>' + (state.user.plan === 'Pro' ? 'Unlimited' : '2 free included') + '</strong></div>' + (state.user.plan !== 'Pro' ? '<div class="panel-footer"><button type="button" class="btn btn-primary" data-action="show-plans">View plans &amp; upgrade</button></div>' : '<div class="panel-footer"><button type="button" class="btn btn-secondary" data-action="show-plans">Manage subscription</button></div>') + '</div>' +
      '</div>'
    );
  }

  function renderPracticeCard(skill, title, description, band, status) {
    return '<article class="practice-card" data-accent="' + skill + '"><div class="card-head"><div class="skill-badge accent-' + getAccent(skill) + '">' + icon(skill, 'skill-icon') + '</div><span class="card-subtle">Band</span></div><h3>' + escapeHtml(title) + '</h3><p>' + escapeHtml(description) + '</p><div class="card-footer"><span class="band-value">' + escapeHtml(band) + '</span><span class="status-pill">' + escapeHtml(status) + '</span></div><div class="button-row"><button class="btn btn-secondary" type="button" data-route="' + skill + '">Open section</button></div></article>';
  }

  function renderModeCard(title, text, iconName, skill) {
    return '<article class="mode-card"><div class="mode-head"><div class="mode-badge accent-teal">' + icon(iconName, 'mode-icon') + '</div><span class="micro-kicker">Spec-driven flow</span></div><h3>' + escapeHtml(title) + '</h3><p>' + escapeHtml(text) + '</p><div class="button-row"><button class="btn btn-primary" type="button" data-action="start-practice" data-skill="' + skill + '">Start</button></div></article>';
  }

  function renderMetricsCard(title, value, text) {
    return '<div class="metrics-card"><span class="muted-label">' + escapeHtml(title) + '</span><div class="metrics-value">' + escapeHtml(value) + '</div><p>' + escapeHtml(text) + '</p></div>';
  }

  function renderStatCard(label, value, helper, accent, iconName) {
    return '<div class="stat-card"><div class="stat-top"><div class="stat-icon-wrap accent-' + accent + '">' + icon(iconName, 'stat-icon') + '</div></div><div><div class="stat-value">' + escapeHtml(value) + '</div><div class="stat-label">' + escapeHtml(label) + '</div><div class="muted-label">' + escapeHtml(helper) + '</div></div></div>';
  }

  function renderGlassCard(title, text) {
    return '<article class="glass-card"><h3>' + escapeHtml(title) + '</h3><p>' + escapeHtml(text) + '</p></article>';
  }

  function renderPlans() {
    if (state.plansStatus === 'loading') {
      return '<div class="empty-card">Loading plans...</div>';
    }
    if (state.plansStatus === 'error') {
      return '<div class="auth-error">' + escapeHtml(state.plansError) + '</div>';
    }
    const plans = state.plansData || [];
    if (!plans.length) {
      return '<div class="empty-card">No plans available. Ask your administrator to configure plans in the admin portal.</div>';
    }
    const selectedPlan = plans.find(function (plan) {
      return String(plan.id || '') === String(state.selectedPlanId || '');
    }) || null;

    return (
      '<section class="profile-card plans-board profile-card--span-2">' +
        '<h3>Plans &amp; Pricing</h3>' +
        '<p class="muted-label" style="margin-bottom:12px">Choose the plan that fits your study goals.</p>' +
        '<div class="plan-options">' +
          plans.map(function (plan) {
            const isCurrent = (plan.name || '').toLowerCase() === (state.user.plan || '').toLowerCase();
            const isSelected = String(plan.id || '') === String(state.selectedPlanId || '');
            const isFree = Number(plan.price || 0) === 0;
            return (
              '<button type="button" class="plan-option' + (isSelected ? ' is-selected' : '') + '" data-action="select-plan" data-plan-id="' + escapeAttr(plan.id || '') + '">' +
                '<div class="plan-option__top"><strong>' + escapeHtml(plan.name || 'Plan') + '</strong>' + (isCurrent ? '<span class="pill pill-success">Current</span>' : '') + '</div>' +
                '<div class="plan-option__price">' + (isFree ? 'Free forever' : '$' + escapeHtml(String(plan.price)) + ' / ' + escapeHtml(plan.interval || 'month')) + '</div>' +
                '<ul class="metric-list">' + (plan.features || []).map(function (f) { return '<li>' + escapeHtml(f) + '</li>'; }).join('') + '</ul>' +
              '</button>'
            );
          }).join('') +
        '</div>' +
        (selectedPlan ? renderPaymentMethods(selectedPlan) : '<div class="empty-card" style="margin-top:14px">Select a plan to continue to payment.</div>') +
      '</section>'
    );
  }

  function renderPaymentMethods(plan) {
    const isFree = Number(plan.price || 0) === 0;
    if (isFree) {
      return '<div class="panel-card panel-card--nested" style="margin-top:14px"><h3>Selected Plan: ' + escapeHtml(plan.name || 'Free') + '</h3><p>This plan is free. No payment is required.</p></div>';
    }

    const cardActive = state.selectedPaymentMethod === 'card';
    const paypalActive = state.selectedPaymentMethod === 'paypal';
    return '<div class="panel-card panel-card--nested" style="margin-top:14px">' +
      '<h3>Payment Method</h3>' +
      '<p>Selected plan: <strong>' + escapeHtml(plan.name || 'Pro') + '</strong> at <strong>$' + escapeHtml(String(plan.price || '0')) + '/' + escapeHtml(plan.interval || 'month') + '</strong></p>' +
      '<div class="payment-methods">' +
        '<button type="button" class="btn ' + (cardActive ? 'btn-primary' : 'btn-secondary') + '" data-action="choose-payment-method" data-method="card">Pay with card</button>' +
        '<button type="button" class="btn ' + (paypalActive ? 'btn-primary' : 'btn-secondary') + '" data-action="choose-payment-method" data-method="paypal">Pay with PayPal</button>' +
      '</div>' +
      ((cardActive || paypalActive)
        ? '<div class="panel-footer"><div class="paypal-btn-host" data-paypal-btn="1" data-plan-id="' + escapeAttr(plan.id || '') + '" data-paypal-method="' + (cardActive ? 'card' : 'paypal') + '"></div></div>'
        : '') +
    '</div>';
  }

  var _paypalSdkLoaded = false;

  function mountPayPalButtons() {
    var clientId = (state.platformSettings && state.platformSettings.paypalClientId) || '';
    if (!clientId) return; // PayPal not configured

    var containers = document.querySelectorAll('[data-paypal-btn="1"]');
    if (!containers.length) return;

    function _attachButtons() {
      if (!window.paypal) return;
      containers.forEach(function (container) {
        var planId = container.getAttribute('data-plan-id');
        var method = container.getAttribute('data-paypal-method') || 'paypal';
        var fundingSource = method === 'card'
          ? window.paypal.FUNDING.CARD
          : window.paypal.FUNDING.PAYPAL;
        if (!planId || container.childElementCount > 0) return; // already mounted
        var buttons = window.paypal.Buttons({
          fundingSource: fundingSource,
          style: {
            layout: 'vertical',
            color: method === 'card' ? 'black' : 'gold',
            shape: 'rect',
            label: method === 'card' ? 'pay' : 'paypal'
          },
          createOrder: function () {
            return platform.createPayPalOrder({ planId: planId })
              .then(function (res) { return res.orderId; });
          },
          onApprove: function (data) {
            return platform.capturePayPalOrder({ orderId: data.orderID, planId: planId })
              .then(function (res) {
                if (res && res.user) {
                  saveUser(res.user);
                  state.user = res.user;
                  addActivity('Plan upgraded', 'You are now on the ' + (res.user.plan || 'Pro') + ' plan.');
                }
                state.view = 'profile';
                render();
              });
          },
          onError: function (err) {
            alert('PayPal error: ' + (err && err.message ? err.message : 'Payment could not be completed.'));
          }
        });

        if (buttons && buttons.isEligible && !buttons.isEligible()) {
          container.innerHTML = '<div class="auth-error" style="margin-top:0">This payment method is not available for your PayPal sandbox account.</div>';
          return;
        }

        buttons.render(container);
      });
    }

    if (_paypalSdkLoaded || window.paypal) {
      _attachButtons();
      return;
    }

    var script  = document.createElement('script');
    script.src  = 'https://www.paypal.com/sdk/js?client-id=' + encodeURIComponent(clientId) + '&currency=USD&components=buttons&enable-funding=card';
    script.onload = function () {
      _paypalSdkLoaded = true;
      _attachButtons();
    };
    document.head.appendChild(script);
  }

  function renderActivityList() {
    const activities = getActivities().slice(0, 5);

    if (!activities.length) {
      return '<div class="activity-empty">No activity yet. Start a practice flow or open a library resource.</div>';
    }
    return '<div class="activity-list">' + activities.map(function (item) {
      return '<div class="activity-item"><div class="activity-copy"><strong>' + escapeHtml(item.title) + '</strong><div class="activity-detail">' + escapeHtml(item.detail) + '</div></div><div class="activity-meta"><span class="activity-time">' + escapeHtml(formatRelative(item.at)) + '</span></div></div>';
    }).join('') + '</div>';
  }

  function renderSkillProgressRows() {
    return ['writing', 'reading', 'listening', 'speaking'].map(function (skill) {
      const status = state.user.progress.skills[skill];
      return '<div class="metric-row"><div><strong>' + capitalize(skill) + '</strong><div class="muted-label">' + escapeHtml(status.status) + '</div></div><strong>' + escapeHtml(formatBand(status.band)) + '</strong></div>';
    }).join('');
  }

  function getResourcePreview(skill) {
    const items = getLibraryItems(skill).slice(0, 4);
    if (!items.length) {
      return '<div class="empty-card">No repo-backed resources are currently available for this section.</div>';
    }
    return items.map(function (item) {
      return '<article class="resource-card"><div class="resource-head"><div class="resource-badge accent-' + getAccent(item.section) + '">' + icon(item.section, 'resource-icon') + '</div><span class="resource-meta">' + escapeHtml(item.sectionLabel) + '</span></div><h3>' + escapeHtml(item.label) + '</h3><p>' + escapeHtml(item.meta) + '</p><div class="resource-footer"><button type="button" class="btn btn-secondary" data-route="library" data-category="' + item.section + '">Open in library</button></div></article>';
    }).join('');
  }

  function getSkillConfig(skill, metrics) {
    const map = {
      writing: {
        title: 'Writing Studio',
        cta: 'writing session',
        summary: 'The spec calls for real IELTS Task 1 and Task 2 simulations, timed sessions, AI scoring, grammar corrections, stronger vocabulary suggestions, and model answers.',
        evaluationIntro: 'Frontend placeholders are now structured around the same categories described in the Word spec.',
        evaluation: ['Task Achievement / Task Response', 'Coherence & Cohesion', 'Lexical Resource', 'Grammatical Range & Accuracy'],
        features: ['Timed Task 1 / Task 2 experience surfaces.', 'Band score prediction cards in the UI.', 'Correction and model-answer panels ready for API results.', 'Existing writing materials and samples available in the library.'],
        cards: [
          { title: 'Task 1', text: 'Charts, diagrams, and academic data prompts with short-form timers.', kicker: 'Academic flow', icon: 'writing', accent: 'violet' },
          { title: 'Task 2', text: 'Essay prompts with long-form structure guidance and scoring panels.', kicker: 'Essay mode', icon: 'dashboard', accent: 'teal' },
          { title: 'AI Analysis', text: 'Reserved UI for grammar flags, vocabulary upgrades, and rewritten sentences.', kicker: 'Post-test review', icon: 'spark', accent: 'orange' },
          { title: 'Repo content', text: metrics.writingMaterials + ' materials and ' + metrics.writingSamples + ' sample answers are already wired in.', kicker: 'Current assets', icon: 'library', accent: 'gold' }
        ]
      },
      reading: {
        title: 'Reading Practice',
        cta: 'reading drill',
        summary: 'Reading is framed around the spec requirements: 3 passages, 40 questions, and a 60-minute timer with result analysis after submission.',
        evaluationIntro: 'The frontend now has clear slots for the reading-specific outputs that would come from a test engine.',
        evaluation: ['Correct answers review', 'Score estimate', 'Band score prediction', 'Question-type breakdown for weak areas'],
        features: ['Multiple choice, TFNG, matching headings, sentence completion, and diagram labeling called out in the UI.', 'Timer-oriented screen structure.', 'Existing PDFs can serve as source material in the library.', 'Dashboard entry point links directly to the reading experience.'],
        cards: [
          { title: '3-passages flow', text: 'The new layout positions reading as a timed exam module rather than a raw document list.', kicker: 'Exam framing', icon: 'reading', accent: 'teal' },
          { title: 'Result analysis', text: 'Answer review and band-estimate panels can receive backend scoring later.', kicker: 'Scoring shell', icon: 'trend', accent: 'violet' },
          { title: 'Question types', text: 'The product copy now matches the question taxonomy from the spec.', kicker: 'Coverage', icon: 'target', accent: 'orange' },
          { title: 'Repo content', text: metrics.readingTests + ' PDF papers are currently available to anchor the library view.', kicker: 'Current assets', icon: 'library', accent: 'gold' }
        ]
      },
      listening: {
        title: 'Listening Practice',
        cta: 'listening session',
        summary: 'Listening supports both fresh AI-generated tests and the existing Cambridge audio library already stored in the repo.',
        evaluationIntro: 'This section now combines the shared-hosting PHP backend for AI tests with direct playback of the original listening library files.',
        evaluation: ['Generated answer key stored on the server', 'Listening band estimate from objective scoring', 'Generated audio streamed from PHP storage when available', 'Existing library audio available as a stable fallback'],
        features: ['No hardcoded templates are required for the AI listening test flow.', 'The original listening library remains directly playable from this section.', 'Scoring is objective and driven by accepted answer variants.', 'The implementation is designed to run on shared hosting with PHP and writable storage.'],
        cards: [
          { title: 'Generated audio', text: 'The transcript can be turned into stored WAV audio through TTS after the test session is created.', kicker: 'Dynamic media', icon: 'listening', accent: 'teal' },
          { title: 'Objective grading', text: 'Answers are compared against accepted variants stored in the generated session.', kicker: 'Reliable scoring', icon: 'target', accent: 'orange' },
          { title: 'Band conversion', text: 'Raw listening score is mapped to IELTS band immediately after submission.', kicker: 'Instant result', icon: 'trend', accent: 'violet' },
          { title: 'Existing library', text: 'Cambridge repo audio remains available for direct playback even if AI TTS is temporarily unavailable.', kicker: 'Stable fallback', icon: 'library', accent: 'gold' }
        ]
      },
      speaking: {
        title: 'Speaking Lab',
        cta: 'speaking session',
        summary: 'Speaking can now accept a recorded answer, transcribe it with Gemini, and return IELTS-style feedback for fluency, vocabulary, grammar, and pronunciation.',
        evaluationIntro: 'The frontend now includes an upload path for spoken answers, and the shared-hosting PHP backend handles transcription plus scoring.',
        evaluation: ['Fluency review', 'Vocabulary feedback', 'Grammar review', 'Pronunciation / accent correction area'],
        features: ['Spoken answers can be uploaded from phone or desktop microphone recordings.', 'Gemini transcribes the response before the scoring pass runs.', 'Band estimate and improvement tips come back in structured JSON.', 'The stack stays compatible with shared hosting because uploads go through PHP.'],
        cards: [
          { title: 'Speech upload', text: 'Users can send recorded answers from the browser using normal multipart upload.', kicker: 'Input path', icon: 'speaking', accent: 'orange' },
          { title: 'Gemini transcription', text: 'The uploaded audio is converted to text before examiner-style scoring is produced.', kicker: 'Speech to text', icon: 'spark', accent: 'violet' },
          { title: 'Feedback breakdown', text: 'Post-test panels map to fluency, vocabulary, grammar, and pronunciation.', kicker: 'Detailed review', icon: 'target', accent: 'teal' },
          { title: 'Hosting model', text: 'This speaking evaluation flow is implemented for shared hosting with PHP, cURL, and file uploads.', kicker: 'Deployment fit', icon: 'library', accent: 'gold' }
        ]
      }
    };
    return map[skill];
  }

  function getViewEyebrow() {
    const map = {
      dashboard: 'Dashboard overview',
      practice: 'Product practice modes',
      writing: 'Writing evaluation flow',
      reading: 'Reading simulation flow',
      listening: 'Listening simulation flow',
      speaking: 'Speaking simulation flow',
      library: 'Repo-backed resource library',
      plans: 'Plan and pricing',
      progress: 'Progress tracking',
      profile: 'Account and settings',
      admin: 'Platform administration'
    };
    return map[state.view] || 'IELTSLab';
  }

  function getViewTitle() {
    const map = {
      dashboard: 'IELTSLab dashboard',
      practice: 'Choose a practice mode',
      writing: 'Writing section',
      reading: 'Reading section',
      listening: 'Listening section',
      speaking: 'Speaking section',
      library: 'Content library',
      plans: 'Plan and pricing',
      progress: 'Progress and performance',
      profile: 'Profile and preferences',
      admin: 'Admin dashboard'
    };
    return map[state.view] || 'IELTSLab';
  }

  function getViewDescription(metrics) {
    const map = {
      dashboard: 'A softer product dashboard inspired by your screenshot, layered on top of the current IELTS repo.',
      practice: 'Spec-driven practice cards for mock exams, speaking AI, and writing review with room for future backend logic.',
      writing: 'Task 1 / Task 2 writing product surfaces backed by ' + metrics.writingMaterials + ' materials and ' + metrics.writingSamples + ' sample answers.',
      reading: 'Reading now reads like a simulation product rather than a PDF drawer.',
      listening: 'Listening can now generate fresh AI audio, questions, and scoring through shared-hosting-safe PHP endpoints.',
      speaking: 'Speaking can now upload a spoken answer for transcription and IELTS-style AI evaluation.',
      library: 'Search, filter, and preview repo resources with a cleaner split-panel layout.',
      plans: 'Compare available plans, choose your preferred option, and complete payment via card or PayPal.',
      progress: 'Local prototype progress tracking aligned to the feature list in the Word spec.',
      profile: 'Profile, plan, target band, and live backend-backed settings in one place.',
      admin: 'View users, analytics summary, content metadata, and outgoing verification links from the backend.'
    };
    return map[state.view] || '';
  }

  function getCatalogMetrics() {
    const catalog = state.catalog || { listening: { audio: [], materials: [], audioByBook: {} }, reading: [], writing: { materials: [], samples: [] } };
    return {
      totalResources: (catalog.listening.audio || []).length + (catalog.listening.materials || []).length + (catalog.reading || []).length + (catalog.writing.materials || []).length + (catalog.writing.samples || []).length,
      listeningBooks: Object.keys(catalog.listening.audioByBook || {}).length,
      listeningMaterials: (catalog.listening.materials || []).length,
      readingTests: (catalog.reading || []).length,
      writingMaterials: (catalog.writing.materials || []).length,
      writingSamples: (catalog.writing.samples || []).length
    };
  }

  function getLibraryItems(forcedCategory) {
    const category = forcedCategory || state.libraryCategory;
    const catalog = state.catalog;
    if (!catalog) return [];

    const items = [];
    function push(section, path, meta) {
      items.push({ section: section, sectionLabel: capitalize(section), path: path, label: getFileName(path), meta: meta });
    }

    if (category === 'all' || category === 'listening') {
      Object.keys(catalog.listening.audioByBook || {}).forEach(function (book) {
        catalog.listening.audioByBook[book].forEach(function (path) {
          push('listening', path, book + ' · Audio file');
        });
      });
      (catalog.listening.materials || []).forEach(function (path) {
        push('listening', path, 'Support material');
      });
    }

    if (category === 'all' || category === 'reading') {
      (catalog.reading || []).forEach(function (path) {
        push('reading', path, 'Reading paper');
      });
    }

    if (category === 'all' || category === 'writing') {
      (catalog.writing.materials || []).forEach(function (path) {
        push('writing', path, 'Writing material');
      });
      (catalog.writing.samples || []).forEach(function (path) {
        push('writing', path, 'Writing sample');
      });
    }

    if (category === 'all' || category === 'speaking') {
      (catalog.speaking || []).forEach(function (path) {
        push('speaking', path, 'Speaking support paper');
      });
    }

    const seen = new Set();
    const deduped = items.filter(function (item) {
      if (seen.has(item.path)) return false;
      seen.add(item.path);
      return true;
    });

    const query = state.librarySearch.trim().toLowerCase();
    return deduped.filter(function (item) {
      if (!query) return true;
      return item.label.toLowerCase().includes(query) || item.meta.toLowerCase().includes(query);
    }).sort(function (a, b) {
      return a.label.localeCompare(b.label);
    });
  }

  function ensureSelectedPath() {
    const items = getLibraryItems();
    if (!items.length) {
      state.selectedPath = '';
      return;
    }
    if (!items.some(function (item) { return item.path === state.selectedPath; })) {
      state.selectedPath = items[0].path;
    }
  }

  function startPractice(skill) {
    if (skill === 'writing' && !state.writingIntroOpen) {
      state.introReturnView = state.view || 'dashboard';
      state.view = 'writing';
      state.writingIntroOpen = true;
      render();
      return;
    }
    if (skill === 'reading' && !state.readingIntroOpen) {
      state.introReturnView = state.view || 'dashboard';
      state.view = 'reading';
      state.readingIntroOpen = true;
      render();
      return;
    }
    if (skill === 'listening' && !state.listeningIntroOpen) {
      state.introReturnView = state.view || 'dashboard';
      state.view = 'listening';
      state.listeningIntroOpen = true;
      render();
      return;
    }
    if (skill === 'speaking' && !state.speakingIntroOpen) {
      state.introReturnView = state.view || 'dashboard';
      state.view = 'speaking';
      state.speakingIntroOpen = true;
      render();
      return;
    }

    if (!state.user.progress.skills[skill]) {
      state.view = 'practice';
      render();
      return;
    }

    state.user.progress.sessions += 1;
    state.user.progress.minutesToday = Math.min(state.user.studyGoalMinutes, state.user.progress.minutesToday + 10);
    state.user.progress.streak = Math.max(1, state.user.progress.streak);
    state.user.progress.skills[skill].status = 'In progress';
    saveUser(state.user);
    persistCurrentUserState();
    addActivity('Started ' + capitalize(skill) + ' practice', 'Session ' + state.user.progress.sessions + ' is now in progress.');
    if (skill === 'writing') { state.writingIntroOpen = false; }
    if (skill === 'reading') { state.readingIntroOpen = false; }
    if (skill === 'listening') { state.listeningIntroOpen = false; }
    if (skill === 'speaking') { state.speakingIntroOpen = false; }
    state.view = skill;
    render();
    if (skill === 'writing') {
      focusWritingEditor();
    }
  }

  function focusWritingEditor() {
    window.requestAnimationFrame(function () {
      var target = document.querySelector('textarea[name="essay"]') || document.querySelector('textarea[name="prompt"]');
      if (!target) return;
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      target.focus();
    });
  }

  function saveUser(user) {
    state.user = user;
    state.settings = Object.assign(loadSettings(), (user && user.settings) || {});
    applyTheme(state.settings.theme);
    if (focusAudio.isPlaying() && focusAudio.getActiveSound() !== state.settings.focusSound) {
      startFocusSound(state.settings.focusSound);
    }
  }

  function loadSettings() {
    return {
      focusSound: 'Rain',
      theme: 'light',
      dailyReminder: true,
      timezone: 'UTC'
    };
  }

  function addActivity(title, detail) {
    const items = getActivities();
    items.unshift({ title: title, detail: detail, at: Date.now() });
    localStorage.setItem(ACTIVITY_KEY, JSON.stringify(items.slice(0, 10)));
  }

  function getActivities() {
    try {
      const raw = localStorage.getItem(ACTIVITY_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (err) {
      return [];
    }
  }

  function countActiveSkills(skills) {
    return Object.keys(skills).filter(function (key) {
      return skills[key].status !== 'Not started';
    }).length;
  }

  function capitalize(value) {
    return value.charAt(0).toUpperCase() + value.slice(1);
  }

  function formatBand(value) {
    return value == null ? '--' : String(value);
  }

  function renderFocusSoundStatus() {
    if (state.focusAudioStatus === 'unsupported') {
      return 'Ambient sound is not supported in this browser.';
    }
    if (state.focusAudioError) {
      return state.focusAudioError;
    }
    if (focusAudio.isPlaying()) {
      return state.settings.focusSound + ' is playing.';
    }
    return 'Select a sound or press play to start ambient audio.';
  }

  function setFocusSound(sound, autoPlay) {
    state.settings.focusSound = sound || 'Rain';
    state.focusAudioError = '';
    if (state.user) {
      state.user.settings = Object.assign({}, state.user.settings || {}, state.settings);
      saveUser(state.user);
      persistCurrentUserState();
    }
    if (autoPlay) {
      startFocusSound(state.settings.focusSound);
      return;
    }
    render();
  }

  function startFocusSound(sound) {
    try {
      focusAudio.play(sound || state.settings.focusSound || 'Rain');
      state.focusAudioStatus = 'playing';
      state.focusAudioError = '';
      render();
    } catch (error) {
      state.focusAudioStatus = 'error';
      state.focusAudioError = error && error.message ? error.message : 'Unable to start the focus sound.';
      render();
    }
  }

  function stopFocusSound() {
    focusAudio.stop();
    state.focusAudioStatus = focusAudio.isSupported() ? 'idle' : 'unsupported';
    state.focusAudioError = '';
    render();
  }

  function initialReadingState() {
    return {
      status: 'idle',
      error: '',
      session: null,
      result: null
    };
  }

  function initialWritingState() {
    return {
      status: 'idle',
      error: '',
      result: null
    };
  }

  function initialMockExamState() {
    return {
      status: 'idle',
      error: '',
      session: null
    };
  }

  function collectSequentialAnswers(form, questions) {
    const answers = {};
    (questions || []).forEach(function (question) {
      const key = String(question.number || '');
      answers[key] = String(new FormData(form).get('answer-' + key) || '').trim();
    });
    return answers;
  }

  function getMockExamCurrentSectionKey() {
    const sections = (state.mockExam.session && state.mockExam.session.sections) || [];
    const ready = sections.find(function (section) {
      return section.status === 'ready' || section.status === 'in_progress';
    });
    return ready ? ready.key : ((sections[0] && sections[0].key) || 'listening');
  }

  function getSectionPillClass(status) {
    if (status === 'completed') return 'pill-success';
    if (status === 'ready' || status === 'in_progress') return 'pill-warning';
    return 'pill-neutral';
  }

  function buildMockSectionAnswers(sectionKey) {
    if (sectionKey === 'listening') {
      return {
        generatedSessionId: state.aiListening && state.aiListening.session ? state.aiListening.session.sessionId : null,
        bandScore: state.aiListening && state.aiListening.result ? state.aiListening.result.bandScore : null
      };
    }
    if (sectionKey === 'reading') {
      return {
        generatedSessionId: state.aiReading.session ? state.aiReading.session.sessionId : null,
        bandScore: state.aiReading.result ? state.aiReading.result.bandScore : null
      };
    }
    if (sectionKey === 'writing') {
      return {
        attemptId: state.aiWriting.result ? state.aiWriting.result.attemptId : null,
        bandScore: state.aiWriting.result ? state.aiWriting.result.overallBand : null
      };
    }
    if (sectionKey === 'speaking') {
      return {
        attemptId: state.aiSpeaking && state.aiSpeaking.result ? state.aiSpeaking.result.attemptId : null,
        bandScore: state.aiSpeaking && state.aiSpeaking.result ? state.aiSpeaking.result.overallBand : null
      };
    }
    return {};
  }

  function startMockExam() {
    if (!platform) return;
    state.mockExam.status = 'starting';
    state.mockExam.error = '';
    render();

    platform.startMockExam({ targetBand: String(state.user.goalBand || 6.5) })
      .then(function (response) {
        state.mockExam.status = 'ready';
        state.mockExam.session = response.session;
        addActivity('Started full mock exam', 'Session ' + response.session.sessionId + ' is active.');
        render();
      })
      .catch(function (err) {
        state.mockExam.status = 'error';
        state.mockExam.error = err && err.message ? err.message : 'Failed to start the mock exam.';
        render();
      });
  }

  function updateMockExamSection(sectionKey, action) {
    if (!platform || !state.mockExam.session || !sectionKey) return;
    state.mockExam.status = 'saving';
    state.mockExam.error = '';
    render();

    platform.updateMockExam({
      sessionId: state.mockExam.session.sessionId,
      section: sectionKey,
      action: action,
      answers: buildMockSectionAnswers(sectionKey)
    }).then(function (response) {
      state.mockExam.status = 'ready';
      state.mockExam.session = response.session;
      addActivity(action === 'complete' ? 'Completed mock exam section' : 'Saved mock exam checkpoint', capitalize(sectionKey) + ' synced to the exam session.');
      render();
    }).catch(function (err) {
      state.mockExam.status = 'error';
      state.mockExam.error = err && err.message ? err.message : 'Failed to update the mock exam.';
      render();
    });
  }

  function formatRelative(timestamp) {
    const minutes = Math.max(1, Math.round((Date.now() - timestamp) / 60000));
    if (minutes < 60) return minutes + ' min' + (minutes === 1 ? '' : 's') + ' ago';
    const hours = Math.round(minutes / 60);
    if (hours < 24) return hours + ' hr' + (hours === 1 ? '' : 's') + ' ago';
    const days = Math.round(hours / 24);
    return days + ' day' + (days === 1 ? '' : 's') + ' ago';
  }

  function getFileName(path) {
    return String(path || '').split('/').pop() || path;
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/'/g, '&#39;');
  }

  function getAccent(section) {
    const map = { writing: 'violet', reading: 'teal', listening: 'violet', speaking: 'orange' };
    return map[section] || 'teal';
  }

  function renderBrand() {
    const settings = state.platformSettings || {};
    const platformName = String(settings.platformName || 'IELTSLab');
    const logoUrl = resolvePublicAssetPath(settings.logoUrl || '');
    const brandLabel = platformName === 'IELTSLab' ? 'IELTS<em>Lab</em>' : escapeHtml(platformName);
    const brandMark = logoUrl ? '<span class="brand-mark brand-mark--image"><img src="' + escapeAttr(logoUrl) + '" alt="' + escapeAttr(platformName) + ' logo"></span>' : '<span class="brand-mark"><span></span><span></span><span></span><span></span></span>';
    return '<div class="brand">' + brandMark + '<strong>' + brandLabel + '</strong></div>';
  }

  function getNavItems() {
    return NAV_ITEMS;
  }

  async function hydrateSessionUser() {
    if (!platform || !platform.isAvailable()) {
      return null;
    }

    try {
      const response = await platform.getMe();
      if (response.user) {
        saveUser(response.user);
      }
      return response.user || null;
    } catch (err) {
      return null;
    }
  }

  async function hydratePlatformSettings() {
    if (!platform || !platform.isAvailable() || typeof platform.getPlatformSettings !== 'function') {
      return null;
    }

    try {
      const response = await platform.getPlatformSettings();
      return response.settings || null;
    } catch (err) {
      return null;
    }
  }

  function persistCurrentUserState() {
    if (!platform || !state.user) {
      return Promise.resolve(null);
    }

    return platform.updateProfile({
      name: state.user.name,
      goalBand: state.user.goalBand,
      studyGoalMinutes: state.user.studyGoalMinutes,
      settings: state.settings,
      progress: state.user.progress
    }).then(function (response) {
      saveUser(response.user);
      return response.user;
    }).catch(function () {
      return null;
    });
  }

  function applyTheme(theme) {
    const resolvedTheme = theme === 'dark' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', resolvedTheme);
  }

  function setTheme(theme, options) {
    const resolvedTheme = theme === 'dark' ? 'dark' : 'light';
    const config = Object.assign({ persist: true, logActivity: false }, options || {});
    state.settings = Object.assign({}, state.settings, { theme: resolvedTheme });
    if (state.user) {
      state.user.settings = Object.assign({}, state.user.settings || {}, state.settings);
      saveUser(state.user);
    }
    applyTheme(resolvedTheme);
    if (config.logActivity) {
      addActivity('Theme updated', 'Switched to ' + capitalize(resolvedTheme) + ' mode.');
    }
    render();
    if (config.persist) {
      persistCurrentUserState();
    }
  }

  function toggleTheme() {
    const nextTheme = state.settings.theme === 'dark' ? 'light' : 'dark';
    setTheme(nextTheme, { persist: true, logActivity: true });
  }

  function icon(name, className) {
    const cls = className ? ' class="' + className + '"' : '';
    const common = ' viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"';
    const icons = {
      dashboard: '<svg' + cls + common + '><rect x="3" y="4" width="7" height="7" rx="2"></rect><rect x="14" y="4" width="7" height="4" rx="2"></rect><rect x="14" y="11" width="7" height="9" rx="2"></rect><rect x="3" y="14" width="7" height="6" rx="2"></rect></svg>',
      practice: '<svg' + cls + common + '><path d="M13 2 3 14h7l-1 8 10-12h-7l1-8Z"></path></svg>',
      writing: '<svg' + cls + common + '><path d="M12 20h9"></path><path d="m16.5 3.5 4 4L7 21l-4 1 1-4Z"></path></svg>',
      reading: '<svg' + cls + common + '><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"></path></svg>',
      listening: '<svg' + cls + common + '><path d="M3 14v-4a9 9 0 1 1 18 0v4"></path><path d="M21 14v4a2 2 0 0 1-2 2h-1"></path><path d="M3 14v4a2 2 0 0 0 2 2h1"></path><rect x="6" y="13" width="4" height="8" rx="2"></rect><rect x="14" y="13" width="4" height="8" rx="2"></rect></svg>',
      speaking: '<svg' + cls + common + '><path d="M12 18a4 4 0 0 0 4-4V8a4 4 0 1 0-8 0v6a4 4 0 0 0 4 4Z"></path><path d="M19 10v4a7 7 0 0 1-14 0v-4"></path><path d="M12 21v-3"></path></svg>',
      library: '<svg' + cls + common + '><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"></path><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z"></path><path d="M9 7h6"></path><path d="M9 11h8"></path></svg>',
      progress: '<svg' + cls + common + '><path d="M4 19h16"></path><path d="M7 16V8"></path><path d="M12 16V4"></path><path d="M17 16v-6"></path></svg>',
      profile: '<svg' + cls + common + '><path d="M20 21a8 8 0 1 0-16 0"></path><circle cx="12" cy="7" r="4"></circle></svg>',
      settings: '<svg' + cls + common + '><path d="M21.7 14.3a1 1 0 0 0 0-1.4l-2.6-2.6a5 5 0 0 1-6.6-6.6L9.9 6.3a1 1 0 0 0 0 1.4l1.4 1.4-6.9 6.9a2 2 0 0 0 0 2.8l.8.8a2 2 0 0 0 2.8 0l6.9-6.9 1.4 1.4a1 1 0 0 0 1.4 0z"></path><path d="m7.5 16.5 1.5 1.5"></path></svg>',
      sun: '<svg' + cls + common + '><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2.5"></path><path d="M12 19.5V22"></path><path d="m4.93 4.93 1.77 1.77"></path><path d="m17.3 17.3 1.77 1.77"></path><path d="M2 12h2.5"></path><path d="M19.5 12H22"></path><path d="m4.93 19.07 1.77-1.77"></path><path d="m17.3 6.7 1.77-1.77"></path></svg>',
      moon: '<svg' + cls + common + '><path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z"></path></svg>',
      check: '<svg' + cls + common + '><path d="m5 12 4.2 4.2L19 6.5"></path></svg>',
      logout: '<svg' + cls + common + '><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><path d="M16 17l5-5-5-5"></path><path d="M21 12H9"></path></svg>',
      spark: '<svg' + cls + common + '><path d="m12 3 1.9 4.7L18.6 9l-4.7 1.9L12 15.6l-1.9-4.7L5.4 9l4.7-1.3Z"></path><path d="M19 3v4"></path><path d="M21 5h-4"></path></svg>',
      target: '<svg' + cls + common + '><circle cx="12" cy="12" r="8"></circle><circle cx="12" cy="12" r="3"></circle></svg>',
      flame: '<svg' + cls + common + '><path d="M12 2s4 4 4 8a4 4 0 1 1-8 0c0-2.5 1.3-4.5 4-8Z"></path></svg>',
      clock: '<svg' + cls + common + '><circle cx="12" cy="12" r="9"></circle><path d="M12 7v6l4 2"></path></svg>',
      trend: '<svg' + cls + common + '><path d="M3 17 9 11l4 4 8-8"></path><path d="M14 7h7v7"></path></svg>'
    };
    return icons[name] || icons.dashboard;
  }

  function createFocusAudioEngine() {
    const Context = window.AudioContext || window.webkitAudioContext;
    let audioContext = null;
    let masterGain = null;
    let cleanup = null;
    let activeSound = '';

    function ensureContext() {
      if (!Context) {
        throw new Error('This browser does not support Web Audio focus sounds.');
      }
      if (!audioContext) {
        audioContext = new Context();
        masterGain = audioContext.createGain();
        masterGain.gain.value = 0.18;
        masterGain.connect(audioContext.destination);
      }
      if (audioContext.state === 'suspended') {
        audioContext.resume();
      }
      return audioContext;
    }

    function buildBuffer(ctx, color) {
      const length = ctx.sampleRate * 2;
      const buffer = ctx.createBuffer(1, length, ctx.sampleRate);
      const output = buffer.getChannelData(0);
      let lastOut = 0;
      for (let i = 0; i < length; i += 1) {
        const white = Math.random() * 2 - 1;
        if (color === 'brown') {
          lastOut = (lastOut + 0.02 * white) / 1.02;
          output[i] = lastOut * 3.5;
        } else {
          output[i] = white;
        }
      }
      return buffer;
    }

    function createLoopingNoise(ctx, color) {
      const source = ctx.createBufferSource();
      source.buffer = buildBuffer(ctx, color);
      source.loop = true;
      return source;
    }

    function modulateGain(ctx, gainNode, minValue, maxValue, rate) {
      const lfo = ctx.createOscillator();
      const depth = ctx.createGain();
      lfo.type = 'sine';
      lfo.frequency.value = rate;
      depth.gain.value = (maxValue - minValue) / 2;
      gainNode.gain.value = minValue + depth.gain.value;
      lfo.connect(depth);
      depth.connect(gainNode.gain);
      lfo.start();
      return lfo;
    }

    function playRain(ctx) {
      const source = createLoopingNoise(ctx, 'white');
      const highpass = ctx.createBiquadFilter();
      const lowpass = ctx.createBiquadFilter();
      const gainNode = ctx.createGain();
      highpass.type = 'highpass';
      highpass.frequency.value = 900;
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 6800;
      gainNode.gain.value = 0.08;
      source.connect(highpass);
      highpass.connect(lowpass);
      lowpass.connect(gainNode);
      gainNode.connect(masterGain);
      const lfo = modulateGain(ctx, gainNode, 0.05, 0.11, 0.18);
      source.start();
      return function () {
        lfo.stop();
        source.stop();
        source.disconnect();
        highpass.disconnect();
        lowpass.disconnect();
        gainNode.disconnect();
      };
    }

    function playOcean(ctx) {
      const source = createLoopingNoise(ctx, 'brown');
      const lowpass = ctx.createBiquadFilter();
      const gainNode = ctx.createGain();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 500;
      gainNode.gain.value = 0.08;
      source.connect(lowpass);
      lowpass.connect(gainNode);
      gainNode.connect(masterGain);
      const lfo = modulateGain(ctx, gainNode, 0.04, 0.13, 0.08);
      source.start();
      return function () {
        lfo.stop();
        source.stop();
        source.disconnect();
        lowpass.disconnect();
        gainNode.disconnect();
      };
    }

    function playBrownNoise(ctx) {
      const source = createLoopingNoise(ctx, 'brown');
      const lowpass = ctx.createBiquadFilter();
      const gainNode = ctx.createGain();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 700;
      gainNode.gain.value = 0.14;
      source.connect(lowpass);
      lowpass.connect(gainNode);
      gainNode.connect(masterGain);
      source.start();
      return function () {
        source.stop();
        source.disconnect();
        lowpass.disconnect();
        gainNode.disconnect();
      };
    }

    function playLibrarySilence(ctx) {
      const source = createLoopingNoise(ctx, 'brown');
      const lowpass = ctx.createBiquadFilter();
      const highpass = ctx.createBiquadFilter();
      const gainNode = ctx.createGain();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 180;
      highpass.type = 'highpass';
      highpass.frequency.value = 50;
      gainNode.gain.value = 0.035;
      source.connect(lowpass);
      lowpass.connect(highpass);
      highpass.connect(gainNode);
      gainNode.connect(masterGain);
      source.start();
      return function () {
        source.stop();
        source.disconnect();
        lowpass.disconnect();
        highpass.disconnect();
        gainNode.disconnect();
      };
    }

    function scheduleRepeating(callback, minDelay, maxDelay) {
      let timer = null;
      let cancelled = false;
      function loop() {
        if (cancelled) {
          return;
        }
        callback();
        const nextDelay = minDelay + Math.random() * (maxDelay - minDelay);
        timer = window.setTimeout(loop, nextDelay);
      }
      loop();
      return function () {
        cancelled = true;
        if (timer !== null) {
          window.clearTimeout(timer);
        }
      };
    }

    function playForest(ctx) {
      const source = createLoopingNoise(ctx, 'brown');
      const lowpass = ctx.createBiquadFilter();
      const gainNode = ctx.createGain();
      lowpass.type = 'lowpass';
      lowpass.frequency.value = 420;
      gainNode.gain.value = 0.045;
      source.connect(lowpass);
      lowpass.connect(gainNode);
      gainNode.connect(masterGain);
      source.start();

      const stopBirds = scheduleRepeating(function () {
        const oscillator = ctx.createOscillator();
        const chirpGain = ctx.createGain();
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(1400 + Math.random() * 800, ctx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(2200 + Math.random() * 1400, ctx.currentTime + 0.12);
        chirpGain.gain.setValueAtTime(0.0001, ctx.currentTime);
        chirpGain.gain.exponentialRampToValueAtTime(0.015, ctx.currentTime + 0.03);
        chirpGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.2);
        oscillator.connect(chirpGain);
        chirpGain.connect(masterGain);
        oscillator.start();
        oscillator.stop(ctx.currentTime + 0.22);
        oscillator.onended = function () {
          oscillator.disconnect();
          chirpGain.disconnect();
        };
      }, 1800, 4200);

      return function () {
        stopBirds();
        source.stop();
        source.disconnect();
        lowpass.disconnect();
        gainNode.disconnect();
      };
    }

    function playFireplace(ctx) {
      const source = createLoopingNoise(ctx, 'brown');
      const bandpass = ctx.createBiquadFilter();
      const gainNode = ctx.createGain();
      bandpass.type = 'bandpass';
      bandpass.frequency.value = 520;
      bandpass.Q.value = 0.7;
      gainNode.gain.value = 0.05;
      source.connect(bandpass);
      bandpass.connect(gainNode);
      gainNode.connect(masterGain);
      source.start();

      const stopCrackles = scheduleRepeating(function () {
        const burst = ctx.createBufferSource();
        const burstGain = ctx.createGain();
        const burstFilter = ctx.createBiquadFilter();
        burst.buffer = buildBuffer(ctx, 'white');
        burstFilter.type = 'highpass';
        burstFilter.frequency.value = 1200 + Math.random() * 1000;
        burstGain.gain.setValueAtTime(0.0001, ctx.currentTime);
        burstGain.gain.exponentialRampToValueAtTime(0.04, ctx.currentTime + 0.01);
        burstGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.09);
        burst.connect(burstFilter);
        burstFilter.connect(burstGain);
        burstGain.connect(masterGain);
        burst.start();
        burst.stop(ctx.currentTime + 0.1);
        burst.onended = function () {
          burst.disconnect();
          burstFilter.disconnect();
          burstGain.disconnect();
        };
      }, 220, 680);

      return function () {
        stopCrackles();
        source.stop();
        source.disconnect();
        bandpass.disconnect();
        gainNode.disconnect();
      };
    }

    function playNightCrickets(ctx) {
      const stopChirps = scheduleRepeating(function () {
        const oscillator = ctx.createOscillator();
        const chirpGain = ctx.createGain();
        oscillator.type = 'square';
        oscillator.frequency.setValueAtTime(3600 + Math.random() * 800, ctx.currentTime);
        chirpGain.gain.setValueAtTime(0.0001, ctx.currentTime);
        chirpGain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.01);
        chirpGain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.06);
        oscillator.connect(chirpGain);
        chirpGain.connect(masterGain);
        oscillator.start();
        oscillator.stop(ctx.currentTime + 0.065);
        oscillator.onended = function () {
          oscillator.disconnect();
          chirpGain.disconnect();
        };
      }, 120, 280);

      return function () {
        stopChirps();
      };
    }

    return {
      isSupported: function () {
        return !!Context;
      },
      isPlaying: function () {
        return typeof cleanup === 'function';
      },
      getActiveSound: function () {
        return activeSound;
      },
      play: function (sound) {
        const ctx = ensureContext();
        if (typeof cleanup === 'function') {
          cleanup();
          cleanup = null;
        }
        activeSound = sound;
        if (sound === 'Ocean') {
          cleanup = playOcean(ctx);
          return;
        }
        if (sound === 'Brown Noise') {
          cleanup = playBrownNoise(ctx);
          return;
        }
        if (sound === 'Library Silence') {
          cleanup = playLibrarySilence(ctx);
          return;
        }
        if (sound === 'Forest') {
          cleanup = playForest(ctx);
          return;
        }
        if (sound === 'Fireplace') {
          cleanup = playFireplace(ctx);
          return;
        }
        if (sound === 'Night Crickets') {
          cleanup = playNightCrickets(ctx);
          return;
        }
        cleanup = playRain(ctx);
      },
      stop: function () {
        if (typeof cleanup === 'function') {
          cleanup();
          cleanup = null;
        }
      }
    };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
