(function () {
  function initialState() {
    return {
      status: 'idle',
      error: '',
      result: null,
      part: 'Part 2',
      targetBand: '',
      prompt: '',
      recorderStatus: 'idle',
      mediaRecorder: null,
      mediaStream: null,
      recordedChunks: [],
      recordedBlob: null,
      recordedAudioUrl: '',
      recordedMimeType: '',
      supportsRecording: !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia && window.MediaRecorder)
    };
  }

  function evaluateSpeech(form, state) {
    var formData = new FormData(form);
    if (state && state.recordedBlob) {
      formData.set('audio', state.recordedBlob, getRecordingFileName(state));
    }

    return fetch('api/evaluate-speaking.php', {
      method: 'POST',
      body: formData
    }).then(function (response) {
      return response.text().then(function (text) {
        var data;
        try {
          data = text ? JSON.parse(text) : null;
        } catch (err) {
          data = {
            success: false,
            error: 'The server returned a non-JSON response (' + response.status + '). ' + compactServerText(text)
          };
        }

        if (!data) {
          data = {
            success: false,
            error: 'The server returned an empty response (' + response.status + ').'
          };
        }

        if (!response.ok || !data.success) {
          throw new Error(data.error || 'Speaking evaluation failed.');
        }
        return data;
      });
    });
  }

  function startRecording(state) {
    if (!state.supportsRecording) {
      return Promise.reject(new Error('This browser does not support in-page audio recording. Use the upload field instead.'));
    }

    if (state.mediaRecorder && state.mediaRecorder.state === 'recording') {
      return Promise.resolve(state);
    }

    return navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
      resetRecording(state, false);
      var mimeType = getSupportedMimeType();
      var mediaRecorder = mimeType ? new MediaRecorder(stream, { mimeType: mimeType }) : new MediaRecorder(stream);

      state.mediaStream = stream;
      state.mediaRecorder = mediaRecorder;
      state.recordedChunks = [];
      state.recordedBlob = null;
      state.recordedMimeType = mimeType || mediaRecorder.mimeType || 'audio/webm';
      if (state.recordedAudioUrl) {
        URL.revokeObjectURL(state.recordedAudioUrl);
        state.recordedAudioUrl = '';
      }

      mediaRecorder.addEventListener('dataavailable', function (event) {
        if (event.data && event.data.size > 0) {
          state.recordedChunks.push(event.data);
        }
      });

      mediaRecorder.addEventListener('stop', function () {
        if (!state.recordedChunks.length) {
          state.recorderStatus = 'idle';
          stopStream(state.mediaStream);
          state.mediaStream = null;
          state.mediaRecorder = null;
          return;
        }

        state.recordedBlob = new Blob(state.recordedChunks, { type: state.recordedMimeType || 'audio/webm' });
        state.recordedAudioUrl = URL.createObjectURL(state.recordedBlob);
        state.recorderStatus = 'ready';
        stopStream(state.mediaStream);
        state.mediaStream = null;
        state.mediaRecorder = null;
      });

      mediaRecorder.start();
      state.recorderStatus = 'recording';
      return state;
    });
  }

  function stopRecording(state) {
    if (!state.mediaRecorder || state.mediaRecorder.state !== 'recording') {
      return Promise.resolve(state);
    }

    return new Promise(function (resolve) {
      var recorder = state.mediaRecorder;
      recorder.addEventListener('stop', function handleStop() {
        recorder.removeEventListener('stop', handleStop);
        resolve(state);
      });
      recorder.stop();
      state.recorderStatus = 'processing';
    });
  }

  function clearRecording(state) {
    resetRecording(state, true);
    state.error = '';
    return state;
  }

  function syncSelectedFile(input, state) {
    if (!input || !input.files || !input.files[0]) {
      return;
    }

    // Update the filename display label
    var nameEl = document.getElementById('speaking-audio-name');
    if (nameEl) { nameEl.textContent = input.files[0].name; }

    resetRecording(state, true);
    state.recordedBlob = input.files[0];
    state.recordedMimeType = input.files[0].type || 'audio/webm';
    state.recordedAudioUrl = URL.createObjectURL(input.files[0]);
    state.recorderStatus = 'ready';
  }

  function hasAudioReady(state) {
    return !!(state && state.recordedBlob);
  }

  function renderPanel(state, options) {
    var goalBand = options && options.goalBand ? String(options.goalBand) : '7.0';
    var selectedPart = state.part || 'Part 2';
    var selectedTargetBand = state.targetBand || goalBand;
    var promptValue = state.prompt || '';
    var statusMarkup = state.error ? '<div class="auth-error">' + escapeHtml(state.error) + '</div>' : '';
    var resultMarkup = state.result ? renderResult(state.result) : '<p class="card-subtle">Upload a spoken response and the AI will transcribe it, estimate the speaking band, and return targeted feedback.</p>';
    var recorderMarkup = renderRecorder(state);

    return (
      '<section class="ai-test-shell">' +
        '<div class="panel-card ai-builder-card">' +
          '<div class="card-head"><div><h3>AI Speaking Evaluation</h3><p>Record the learner\'s answer in the browser or upload audio, then send it to Gemini for transcription and IELTS-style scoring.</p></div><span class="pill">Speech to text + analysis</span></div>' +
          '<form data-form="ai-speaking-evaluate" class="ai-form-grid" enctype="multipart/form-data">' +
            '<div><label class="field-label" for="speaking-part">Speaking part</label><select class="input" id="speaking-part" name="part"><option value="Part 1"' + (selectedPart === 'Part 1' ? ' selected' : '') + '>Part 1</option><option value="Part 2"' + (selectedPart === 'Part 2' ? ' selected' : '') + '>Part 2</option><option value="Part 3"' + (selectedPart === 'Part 3' ? ' selected' : '') + '>Part 3</option></select></div>' +
            '<div><label class="field-label" for="speaking-target-band">Target band</label><select class="input" id="speaking-target-band" name="targetBand"><option value="5.5"' + (selectedTargetBand === '5.5' ? ' selected' : '') + '>5.5</option><option value="6"' + (selectedTargetBand === '6' ? ' selected' : '') + '>6.0</option><option value="6.5"' + (selectedTargetBand === '6.5' ? ' selected' : '') + '>6.5</option><option value="7"' + (selectedTargetBand === '7' || selectedTargetBand === '7.0' ? ' selected' : '') + '>7.0</option><option value="7.5"' + (selectedTargetBand === '7.5' ? ' selected' : '') + '>7.5</option><option value="8"' + (selectedTargetBand === '8' || selectedTargetBand === '8.0' ? ' selected' : '') + '>8.0</option></select></div>' +
            '<div class="ai-form-span"><label class="field-label" for="speaking-prompt">Prompt</label><textarea class="textarea" id="speaking-prompt" name="prompt" rows="3" placeholder="Example: Describe a place you would like to visit and explain why.">' + escapeHtml(promptValue) + '</textarea></div>' +
            '<div class="ai-form-span">' + recorderMarkup + '<label class="field-label">Upload fallback</label><div class="file-upload-row"><label class="btn btn-secondary file-upload-btn" for="speaking-audio">&#128266; Choose audio file</label><input class="file-upload-input" id="speaking-audio" name="audio" type="file" accept="audio/*" capture="user"><span class="file-upload-name" id="speaking-audio-name">No file chosen</span></div><div class="auth-note">Use browser recording when supported. The file input remains as a fallback for older browsers and mobile devices.</div></div>' +
            '<div class="button-row ai-form-span"><button class="btn btn-primary" type="submit" ' + ((state.status === 'evaluating' || !hasAudioReady(state)) ? 'disabled' : '') + '>' + (state.status === 'evaluating' ? 'Evaluating speech...' : 'Evaluate spoken answer') + '</button></div>' +
          '</form>' +
          statusMarkup +
        '</div>' +
        '<div class="panel-card ai-score-card">' + resultMarkup + '</div>' +
      '</section>'
    );
  }

  function renderResult(result) {
    var breakdown = result.breakdown || {};
    var suggestions = Array.isArray(result.improvements) ? result.improvements : [];

    return (
      '<div class="card-head"><div><h3>Speaking review</h3><p>The uploaded recording was transcribed and reviewed against IELTS speaking criteria.</p></div><span class="chip">Band ' + escapeHtml(String(result.overallBand || '--')) + '</span></div>' +
      '<div class="ai-meta-grid">' +
        metricCard('Fluency', breakdown.fluency) +
        metricCard('Vocabulary', breakdown.vocabulary) +
        metricCard('Grammar', breakdown.grammar) +
      '</div>' +
      '<div class="ai-meta-grid ai-meta-grid--two">' +
        metricCard('Pronunciation', breakdown.pronunciation) +
        metricCard('Target band', result.targetBand) +
      '</div>' +
      '<div class="section-heading">Transcript</div>' +
      '<div class="ai-review-item"><div class="card-subtle">' + escapeHtml(result.transcript || 'No transcript returned.') + '</div></div>' +
      '<div class="section-heading">Feedback</div>' +
      '<div class="ai-review-item"><p>' + escapeHtml(result.summary || 'No summary returned.') + '</p></div>' +
      '<div class="section-heading">How to improve</div>' +
      '<ul class="mini-list">' + suggestions.map(function (item) { return '<li>' + escapeHtml(item) + '</li>'; }).join('') + '</ul>' +
      (result.correctedSample ? '<div class="section-heading">Improved answer sample</div><div class="ai-review-item"><p>' + escapeHtml(result.correctedSample) + '</p></div>' : '')
    );
  }

  function metricCard(label, value) {
    return '<div class="ai-mini-card"><span class="muted-label">' + escapeHtml(label) + '</span><strong>' + escapeHtml(String(value || '--')) + '</strong></div>';
  }

  function renderRecorder(state) {
    var unsupported = !state.supportsRecording;
    var statusLabel = {
      idle: 'Not recorded yet',
      recording: 'Recording in progress...',
      processing: 'Finalizing audio...',
      ready: 'Recording ready for evaluation'
    }[state.recorderStatus] || 'Ready';

    return (
      '<div class="audio-card speaking-recorder-card">' +
        '<div class="card-head"><div><strong>Browser microphone</strong><div class="resource-meta">Record directly in the page, then send the audio to Gemini for transcription.</div></div><span class="pill">' + escapeHtml(statusLabel) + '</span></div>' +
        '<div class="button-row">' +
          '<button class="btn btn-secondary" type="button" data-action="start-speaking-recording" ' + ((unsupported || state.recorderStatus === 'recording' || state.status === 'evaluating') ? 'disabled' : '') + '>Start recording</button>' +
          '<button class="btn btn-ghost" type="button" data-action="stop-speaking-recording" ' + ((state.recorderStatus !== 'recording' || state.status === 'evaluating') ? 'disabled' : '') + '>Stop recording</button>' +
          '<button class="btn btn-ghost" type="button" data-action="clear-speaking-recording" ' + (!hasAudioReady(state) ? 'disabled' : '') + '>Clear audio</button>' +
        '</div>' +
        (unsupported ? '<div class="card-subtle">This browser does not support live recording here. Use the upload fallback below.</div>' : '') +
        (state.recordedAudioUrl ? '<audio class="preview-audio" controls preload="metadata" src="' + escapeAttr(state.recordedAudioUrl) + '"></audio>' : '') +
      '</div>'
    );
  }

  function getSupportedMimeType() {
    var candidates = ['audio/webm;codecs=opus', 'audio/webm', 'audio/mp4', 'audio/ogg;codecs=opus'];
    for (var index = 0; index < candidates.length; index += 1) {
      if (window.MediaRecorder && MediaRecorder.isTypeSupported && MediaRecorder.isTypeSupported(candidates[index])) {
        return candidates[index];
      }
    }
    return '';
  }

  function getRecordingFileName(state) {
    var mimeType = state.recordedMimeType || 'audio/webm';
    if (mimeType.indexOf('mp4') !== -1) return 'speaking-response.mp4';
    if (mimeType.indexOf('ogg') !== -1) return 'speaking-response.ogg';
    return 'speaking-response.webm';
  }

  function stopStream(stream) {
    if (!stream || !stream.getTracks) return;
    stream.getTracks().forEach(function (track) {
      track.stop();
    });
  }

  function resetRecording(state, stopTracks) {
    if (stopTracks) {
      stopStream(state.mediaStream);
    }
    if (state.recordedAudioUrl) {
      URL.revokeObjectURL(state.recordedAudioUrl);
    }
    state.mediaRecorder = null;
    state.mediaStream = null;
    state.recordedChunks = [];
    state.recordedBlob = null;
    state.recordedAudioUrl = '';
    state.recordedMimeType = '';
    state.recorderStatus = 'idle';
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/'/g, '&#39;');
  }

  function compactServerText(text) {
    return String(text || '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 220) || 'No response body was returned.';
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  window.IELTSLabSpeakingAI = {
    initialState: initialState,
    evaluateSpeech: evaluateSpeech,
    startRecording: startRecording,
    stopRecording: stopRecording,
    clearRecording: clearRecording,
    syncSelectedFile: syncSelectedFile,
    renderPanel: renderPanel
  };
})();
