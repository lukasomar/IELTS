(function () {
  function initialState() {
    return {
      status: 'idle',
      error: '',
      session: null,
      result: null,
      audioStatus: 'idle',
      audioError: ''
    };
  }

  function generateTest(payload) {
    return postJson('api/generate-listening-test.php', payload);
  }

  function scoreTest(sessionId, answers) {
    return postJson('api/score-listening-test.php', {
      sessionId: sessionId,
      answers: answers
    });
  }

  function generateAudio(sessionId) {
    return postJson('api/generate-listening-audio.php', {
      sessionId: sessionId
    });
  }

  function postJson(url, payload) {
    return fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(payload)
    }).then(function (response) {
      return response.text().then(function (text) {
        var data;
        try {
          data = text ? JSON.parse(text) : null;
        } catch (err) {
          data = {
            success: false,
            error: 'The server returned a non-JSON response (' + response.status + '). ' + compactServerText(text)
          };
        }

        if (!data) {
          data = {
            success: false,
            error: 'The server returned an empty response (' + response.status + ').'
          };
        }

        if (!response.ok || !data.success) {
          throw new Error(data.error || 'Request failed.');
        }
        return data;
      });
    });
  }

  function compactServerText(text) {
    return String(text || '')
      .replace(/\s+/g, ' ')
      .trim()
      .slice(0, 220) || 'No response body was returned.';
  }

  function collectAnswers(form) {
    var formData = new FormData(form);
    var answers = {};
    formData.forEach(function (value, key) {
      if (key.indexOf('q-') === 0) {
        answers[key.replace('q-', '')] = String(value || '').trim();
      }
    });
    return answers;
  }

  function renderPanel(state) {
    var session = state.session;
    var result = state.result;
    var statusMarkup = state.error ? '<div class="auth-error">' + escapeHtml(state.error) + '</div>' : '';
    var audioMarkup = state.audioError ? '<div class="auth-error">' + escapeHtml(state.audioError) + '</div>' : '';
    var summaryMarkup = session ? renderSessionSummary(session) : '<p class="card-subtle">No listening test has been generated yet. Generate a fresh AI listening set when the learner enters this section.</p>';
    var resultMarkup = result ? renderResult(result) : '';

    return (
      '<section class="ai-test-shell">' +
        '<div class="panel-card ai-builder-card">' +
          '<div class="card-head"><div><h3>AI Listening Generator</h3><p>Create a new listening test with AI-generated transcript, questions, answer key, and Gemini-powered audio.</p></div><span class="pill">Shared hosting ready</span></div>' +
          '<form data-form="ai-listening-generate" class="ai-form-grid">' +
            '<div><label class="field-label" for="ai-target-band">Target band</label><select class="input" id="ai-target-band" name="targetBand"><option value="5.5">5.5</option><option value="6" selected>6.0</option><option value="6.5">6.5</option><option value="7">7.0</option><option value="7.5">7.5</option><option value="8">8.0</option></select></div>' +
            '<div><label class="field-label" for="ai-question-count">Question count</label><select class="input" id="ai-question-count" name="questionCount"><option value="8">8</option><option value="10" selected>10</option><option value="12">12</option></select></div>' +
            '<div><label class="field-label" for="ai-accent-mix">Accent mix</label><select class="input" id="ai-accent-mix" name="accentMix"><option value="mixed" selected>Mixed</option><option value="british">British</option><option value="australian">Australian</option><option value="north-american">North American</option></select></div>' +
            '<div><label class="field-label" for="ai-context-theme">Theme</label><input class="input" id="ai-context-theme" name="theme" placeholder="University orientation, housing, travel, research"></div>' +
            '<div class="ai-form-span"><label class="field-label" for="ai-notes">Generation notes</label><textarea class="textarea" id="ai-notes" name="notes" rows="3" placeholder="Optional constraints for the AI. Example: Include numbers, dates, room names, and spelling traps."></textarea></div>' +
            '<div class="button-row ai-form-span">' +
              '<button class="btn btn-primary" type="submit" ' + (state.status === 'generating' ? 'disabled' : '') + '>' + (state.status === 'generating' ? 'Generating test...' : 'Generate AI listening test') + '</button>' +
              '<button class="btn btn-ghost" type="button" data-action="reset-listening-test" ' + (!session ? 'disabled' : '') + '>Clear session</button>' +
            '</div>' +
          '</form>' +
          statusMarkup +
          audioMarkup +
        '</div>' +
        '<div class="ai-listening-grid">' +
          '<div class="panel-card ai-session-card">' + summaryMarkup + '</div>' +
          '<div class="panel-card ai-score-card">' + resultMarkup + (!result ? '<h3>Score output</h3><p class="card-subtle">When answers are submitted, this panel returns the raw score, IELTS band conversion, and item-by-item review.</p>' : '') + '</div>' +
        '</div>' +
        (session ? renderQuestionForm(state) : '') +
      '</section>'
    );
  }

  function renderSessionSummary(session) {
    var hasAudio = !!session.audioUrl;
    var audioControls = hasAudio
      ? '<audio class="preview-audio" controls preload="metadata" src="' + escapeAttr(session.audioUrl || '') + '"></audio>'
      : '<div class="button-row"><button class="btn btn-secondary" type="button" data-action="generate-listening-audio">' + (session.audioStatus === 'generating' ? 'Generating audio...' : 'Generate audio') + '</button></div><div class="resource-meta">Audio is generated separately and stored after it completes.</div>';

    var sectionItems = (session.sections || []).map(function (section) {
      return '<li>Section ' + escapeHtml(String(section.sectionNumber)) + ': ' + escapeHtml(section.title) + ' (' + escapeHtml(section.questionStart + '-' + section.questionEnd) + ')</li>';
    }).join('');

    return (
      '<div class="card-head"><div><h3>' + escapeHtml(session.testTitle || 'AI listening test') + '</h3><p>' + escapeHtml(session.instructions || 'Play the audio once, answer the questions, then submit for scoring.') + '</p></div><span class="pill">' + escapeHtml(String(session.questionCount || 0)) + ' questions</span></div>' +
      '<div class="audio-card">' +
        '<div><strong>Generated audio</strong><div class="resource-meta">Audio is produced by Gemini TTS and streamed from the PHP backend.</div></div>' +
        audioControls +
      '</div>' +
      '<div class="ai-meta-grid">' +
        '<div class="ai-mini-card"><span class="muted-label">Target band</span><strong>' + escapeHtml(String(session.targetBand || '--')) + '</strong></div>' +
        '<div class="ai-mini-card"><span class="muted-label">Accent mix</span><strong>' + escapeHtml(session.accentMix || 'mixed') + '</strong></div>' +
        '<div class="ai-mini-card"><span class="muted-label">Theme</span><strong>' + escapeHtml(session.theme || 'General IELTS') + '</strong></div>' +
      '</div>' +
      '<div class="section-heading">Section map</div>' +
      '<ul class="mini-list">' + sectionItems + '</ul>'
    );
  }

  function renderQuestionForm(state) {
    var session = state.session;
    return (
      '<form data-form="ai-listening-answers" class="panel-card ai-questions-card">' +
        '<div class="card-head"><div><h3>Answer Sheet</h3><p>Fill in the answers below and submit for automatic scoring.</p></div><span class="pill">Session ' + escapeHtml(session.sessionId) + '</span></div>' +
        '<div class="ai-question-list">' + (session.questions || []).map(renderQuestion).join('') + '</div>' +
        '<div class="button-row"><button class="btn btn-primary" type="submit" ' + (state.status === 'scoring' ? 'disabled' : '') + '>' + (state.status === 'scoring' ? 'Scoring answers...' : 'Score answers') + '</button></div>' +
      '</form>'
    );
  }

  function renderQuestion(question) {
    var prompt = '<div class="ai-question-header"><span class="pill">Q' + escapeHtml(String(question.number)) + '</span><strong>' + escapeHtml(question.typeLabel || question.type || 'Question') + '</strong></div>';
    var body = '<p>' + escapeHtml(question.prompt) + '</p>';
    var inputMarkup = '';

    if (question.type === 'multiple_choice' && Array.isArray(question.options)) {
      inputMarkup = '<div class="ai-option-list">' + question.options.map(function (option, index) {
        var optionValue = typeof option === 'string' ? option : option.value;
        var optionLabel = typeof option === 'string' ? option : option.label;
        var id = 'q-' + question.number + '-opt-' + index;
        return '<label class="ai-option" for="' + escapeAttr(id) + '"><input id="' + escapeAttr(id) + '" type="radio" name="q-' + escapeAttr(String(question.number)) + '" value="' + escapeAttr(optionValue) + '"><span>' + escapeHtml(optionLabel) + '</span></label>';
      }).join('') + '</div>';
    } else {
      inputMarkup = '<input class="input" name="q-' + escapeAttr(String(question.number)) + '" placeholder="Type your answer">';
    }

    return '<article class="ai-question-card">' + prompt + body + inputMarkup + '</article>';
  }

  function renderResult(result) {
    return (
      '<div class="card-head"><div><h3>Listening score</h3><p>Objective scoring is based on the generated answer key stored on the server.</p></div><span class="chip">Band ' + escapeHtml(String(result.bandScore)) + '</span></div>' +
      '<div class="ai-meta-grid">' +
        '<div class="ai-mini-card"><span class="muted-label">Raw score</span><strong>' + escapeHtml(String(result.rawScore)) + '/' + escapeHtml(String(result.totalQuestions)) + '</strong></div>' +
        '<div class="ai-mini-card"><span class="muted-label">Correct</span><strong>' + escapeHtml(String(result.correctCount)) + '</strong></div>' +
        '<div class="ai-mini-card"><span class="muted-label">Incorrect</span><strong>' + escapeHtml(String(result.incorrectCount)) + '</strong></div>' +
      '</div>' +
      '<div class="section-heading">Review</div>' +
      '<div class="ai-review-list">' + (result.questionResults || []).map(function (item) {
        return '<div class="ai-review-item ' + (item.isCorrect ? 'is-correct' : 'is-wrong') + '"><div class="ai-review-top"><strong>Q' + escapeHtml(String(item.number)) + '</strong><span class="pill">' + (item.isCorrect ? 'Correct' : 'Review') + '</span></div><p>' + escapeHtml(item.prompt) + '</p><div class="resource-meta">Your answer: ' + escapeHtml(item.userAnswer || 'No answer') + ' | Correct answer: ' + escapeHtml(item.canonicalAnswer || '--') + '</div><div class="card-subtle">' + escapeHtml(item.explanation || 'The answer key matched the generated transcript.') + '</div></div>';
      }).join('') + '</div>'
    );
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function escapeAttr(value) {
    return escapeHtml(value).replace(/'/g, '&#39;');
  }

  window.IELTSLabListeningAI = {
    initialState: initialState,
    generateTest: generateTest,
    generateAudio: generateAudio,
    scoreTest: scoreTest,
    collectAnswers: collectAnswers,
    renderPanel: renderPanel
  };
})();
